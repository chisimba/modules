/**
 *  $Id: AudioPlayerTest.java,v 1.1 2007/03/20 14:37:07 adrian Exp $
 *
 *  Copyright (C) GNU/GPL AVOIR 2007
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.realtime.voice.javasound;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.util.logging.Logger;

import javax.sound.sampled.AudioFormat;

import org.junit.Test;

import avoir.realtime.javasound.AMAudioFormat;
import avoir.realtime.javasound.AudioPlayer;
import avoir.realtime.voice.audio.AudioTestCase;

/**
 * Unit test of the AudioPlayer class.
 */
public class AudioPlayerTest extends AudioTestCase {

    private static Logger logger = Logger.getLogger(AudioPlayerTest.class
	    .getName());

    /**
     * Tests the basic playback of a previously captured audio file.
     * 
     * @throws Exception If an error occurs during the audio playback.
     */
    @Test
    public void testPlay_GSM() throws Exception {
	if (jmfInstalled) {
	    File audioFile = new File(dataFolder, "audio-capture_5s.gsm");
	    BufferedInputStream input = new BufferedInputStream(
		    new FileInputStream(audioFile));
	    AudioFormat format = AMAudioFormat
		    .getLineAudioFormat(AMAudioFormat.FORMAT_CODE_GSM);
	    AudioPlayer player = new AudioPlayer(format, input);
	    player.start();
	    //player runs in its own thread so we need to sleep to let audio play 
	    Thread.sleep(1000);
	    player.stop(); //this currently doesn't stop player as entire file is buffered at once
	    Thread.sleep(5000);
	}
    }

}
