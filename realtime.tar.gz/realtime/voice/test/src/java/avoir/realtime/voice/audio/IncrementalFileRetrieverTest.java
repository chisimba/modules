/**
 *  $Id: IncrementalFileRetrieverTest.java,v 1.2 2007/03/08 14:22:22 adrian Exp $
 *
 *  Copyright (C) GNU/GPL AVOIR 2007
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.realtime.voice.audio;

import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.logging.Logger;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import avoir.test.utils.TestProperties;
import avoir.test.utils.TestUtils;
import avoir.util.FileUtils;

/**
 * Test case for the IncrementalFileRetriever. 
 * 
 * @author adrian
 */
public class IncrementalFileRetrieverTest {

    private static Logger logger = Logger
            .getLogger(IncrementalFileRetrieverTest.class.getName());

    private String modulesURL;

    private String voiceURL;

    private File voiceFolder;

    private File dataFolder;

    private File destinationFolder;

    /**
     * The HTTP address of the file locator service.
     */
    private URL fileLocator = null;

    /**
     * The HTTP address of the folder containing the audio to be played.
     */
    private String audioLocation = null;
    
    /**
     * The local folder representing the above audioLocation.
     */
    private File audioFolder;

    @Before
    public void setup() throws IOException {
        modulesURL = TestProperties.getInstance().getRequiredProperty(
                "modules.url");
        voiceURL = modulesURL + "realtime/resources/voice/";
        String modulesPath = TestProperties.getInstance().getRequiredProperty(
                "modules.path");
        voiceFolder = new File(modulesPath + "realtime/resources/voice/");
        assertTrue(voiceFolder.exists());
        audioFolder = new File(voiceFolder, ServicesConstants.SERVER_AUDIO_PATH);
        assertTrue(audioFolder.exists());

        fileLocator = new URL(voiceURL + ServicesConstants.SERVICE_FILE_LOCATOR);
        audioLocation = voiceURL + ServicesConstants.SERVER_AUDIO_PATH;

        dataFolder = TestUtils.getVoiceTestDataFolder();
        destinationFolder = new File(dataFolder, "temp/");
        destinationFolder.mkdirs();
    }

    @After
    public void cleanup() throws IOException {
        FileUtils.deleteDirectory(destinationFolder);
    }

    private void copyFileToWebServer(File fileToCopy, long lastModified) throws IOException, InterruptedException {
        FileUtils.copyFileToDirectory(fileToCopy, audioFolder);
        File uploadedFile = new File(audioFolder, fileToCopy.getName());
        //mark file for deletion when test exits
        FileUtils.forceDeleteOnExit(uploadedFile);
        uploadedFile.setLastModified(lastModified);
    }

    /**
     * Tests getting the text of a URL representing a file on the 
     * HTTP server.
     * 
     * @throws IOException If an error occurs getting the text.
     * @throws InterruptedException 
     */
    @Test
    public void testDownloadingFiles() throws IOException, InterruptedException {
        //copy files from local test data folder to a place on http server
        long currentTime = System.currentTimeMillis();
        //modify times to test_0 is seen as most recent so uploading will start with it
        copyFileToWebServer(new File(dataFolder, "test_0.gsm"), currentTime);
        copyFileToWebServer(new File(dataFolder, "test_1.gsm"), currentTime-5000);
        copyFileToWebServer(new File(dataFolder, "test_2.gsm"), currentTime-10000);

        IncrementalFileRetriever fileRetriever = new IncrementalFileRetriever(destinationFolder,audioLocation, fileLocator);
        Thread retrieverThread = new Thread(fileRetriever);
        retrieverThread.start();
        Thread.sleep(5000);
        fileRetriever.stop();

        //now check that files were downloaded correctly
        File audioFile0 = new File(destinationFolder, "test_0.gsm");
        assertTrue(audioFile0.exists());
        File audioFile1 = new File(destinationFolder, "test_1.gsm");
        assertTrue(audioFile1.exists());
        File audioFile2 = new File(destinationFolder, "test_2.gsm");
        assertTrue(audioFile2.exists());
    }
}
