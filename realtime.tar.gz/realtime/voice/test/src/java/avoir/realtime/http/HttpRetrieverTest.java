/**
 *  $Id: HttpRetrieverTest.java,v 1.2 2007/03/01 15:49:08 adrian Exp $
 *
 *  Copyright (C) GNU/GPL AVOIR 2007
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.realtime.http;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.logging.Logger;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import avoir.test.utils.TestProperties;
import avoir.test.utils.TestUtils;
import avoir.util.FileUtils;

/**
 * Test case for the HttpRetriever.
 * 
 * @author adrian
 */
public class HttpRetrieverTest {
    
    private static Logger logger = Logger.getLogger(HttpRetrieverTest.class
            .getName());
    
    private String modulesURL;
    private String realtimeModuleURL;
    private File realtimeFolder;
    private File dataFolder;
    private File destinationFolder;
    
    @Before
    public void setup() throws FileNotFoundException {
        modulesURL = TestProperties.getInstance().getRequiredProperty("modules.url");
        realtimeModuleURL = modulesURL + "realtime/";
        String modulesPath = TestProperties.getInstance().getRequiredProperty("modules.path");
        realtimeFolder = new File(modulesPath + "realtime");
        assertTrue(realtimeFolder.exists());
        dataFolder = TestUtils.getVoiceTestDataFolder();
        destinationFolder = new File(dataFolder, "temp/");
        destinationFolder.mkdirs();
    }
    
    @After
    public void cleanup() throws IOException {
        FileUtils.deleteDirectory(destinationFolder);
    }
    /**
     * Tests getting the text of a URL representing a file on the 
     * HTTP server.
     * 
     * @throws IOException If an error occurs getting the text.
     */
    @Test
    public void testGetText() throws IOException {
        File fileToUpload = new File(dataFolder, "upload.txt");
        assertTrue("Couldn't find file " + fileToUpload.getAbsolutePath(),fileToUpload.exists());
        //copy file from local test data folder to a place on http server 
        FileUtils.copyFileToDirectory(fileToUpload, realtimeFolder);
        
        File uploadedFile = new File(realtimeFolder, fileToUpload.getName());
        //mark file for deletion when test exits
        FileUtils.forceDeleteOnExit(uploadedFile);
        
        URL urlToRetrieve = new URL(realtimeModuleURL + fileToUpload.getName());
        //now try an http get of the file we uploaded
        String retrieved = HttpRetriever.getText(urlToRetrieve);
        assertNotNull(retrieved);
        
        //make sure the contents match the original file's
        String expected = FileUtils.readFileToString(fileToUpload);
        assertEquals(expected, retrieved);
    }
    
    /**
     * Tries to get the text of a URL that does not exist on the HTTP server.
     * 
     * @throws MalformedURLException If an error occurs creating the URL.
     */
    @Test
    public void testGetText_NonExistentURL() throws MalformedURLException {
        URL nonExistent = new URL(modulesURL + "nonExistent.html");
        try {
            HttpRetriever.getText(nonExistent);
        } catch (IOException e) {
            //expected
        }
    }

    /**
     * Tests getting the text of a URL representing a folder on the 
     * HTTP server.
     * 
     * @throws IOException If an error occurs getting the text.
     */
    @Test
    public void testGetText_Folder() throws IOException {
        URL folderURL = new URL(realtimeModuleURL);
        //web servers still return some text like a folder listing, so this 
        //should work
        HttpRetriever.getText(folderURL);
    }

    /**
     * Tests downloading a file over HTTP
     * 
     * @throws IOException If an error occurs during the download.
     */
    @Test
    public void testDownloadFile() throws IOException {
        File fileToUpload = new File(dataFolder, "test_0.gsm");
        FileUtils.copyFileToDirectory(fileToUpload, realtimeFolder);
        
        File uploadedFile = new File(realtimeFolder, fileToUpload.getName());
        //mark file for deletion when test exits
        FileUtils.forceDeleteOnExit(uploadedFile);
        
        URL fileURL = new URL(realtimeModuleURL + fileToUpload.getName());
        File destinationFile = new File(destinationFolder, "delete-me.gsm");
        assertFalse(destinationFile.getAbsolutePath() + " should not exist before test", destinationFile.exists());
        
        //download file from http server to local file
        HttpRetriever.downloadFile(fileURL, destinationFile);
        assertTrue(destinationFile.getAbsolutePath() + " should now exist", destinationFile.exists());
        assertEquals(fileToUpload.length(), destinationFile.length());
    }
    
    @Test
    public void testDownloadFileToFolder() throws IOException {
        File fileToUpload = new File(dataFolder, "test_0.gsm");
        FileUtils.copyFileToDirectory(fileToUpload, realtimeFolder);
        
        File uploadedFile = new File(realtimeFolder, fileToUpload.getName());
        //mark file for deletion when test exits
        FileUtils.forceDeleteOnExit(uploadedFile);
        
        URL fileURL = new URL(realtimeModuleURL + fileToUpload.getName());
        File destinationFile = new File(destinationFolder, fileToUpload.getName());
        assertFalse(destinationFile.getAbsolutePath() + " should not exist before test", destinationFile.exists());
        
        //download file from http server to local file
        HttpRetriever.downloadFileToFolder(fileURL, destinationFolder);
        assertTrue(destinationFile.getAbsolutePath() + " should now exist", destinationFile.exists());
        assertEquals(fileToUpload.length(), destinationFile.length());
    }
}


