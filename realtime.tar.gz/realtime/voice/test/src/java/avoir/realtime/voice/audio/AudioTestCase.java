/**
 *  $Id: AudioTestCase.java,v 1.1 2007/02/26 14:58:02 adrian Exp $
 *
 *  Copyright (C) GNU/GPL AVOIR 2007
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.realtime.voice.audio;

import static org.junit.Assert.assertNotNull;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.logging.Logger;

import org.junit.Before;

import avoir.test.utils.TestProperties;
import avoir.test.utils.TestUtils;

/**
 * Base test case for tests which test JMF audio functionality.
 * 
 * @author adrian
 */
public abstract class AudioTestCase {
    
    private static Logger logger = Logger.getLogger(AudioTestCase.class.getName());
    
    /**
     * Folder holding the data used by this test.
     */
    protected File dataFolder;
    
    /**
     * By default we assume JMF is not installed and therefore skip the tests which 
     * won't run without it.
     */
    protected boolean jmfInstalled = false;
    
    /**
     * Gets the location of the test data folder which can be used for 
     * temporarily writing files by the various test methods. 
     *  
     * @throws FileNotFoundException If the test data folder cannot be found.
     */
    @Before
    public void prepareTestData() throws FileNotFoundException { 
        dataFolder = TestUtils.getVoiceTestDataFolder();
        assertNotNull(dataFolder);
        jmfInstalled = TestProperties.getInstance().getBooleanProperty("jmf.installed").booleanValue();
        if (!jmfInstalled) {
            logger.warning("JMF not installed according to test.properties, " +
                        "skipping tests...");
        }
    }
    
}
