/**
 *   $Id: AudioCaptureTest.java,v 1.1 2007/03/20 14:37:07 adrian Exp $
 * 
 *  Copyright (C) GNU/GPL AVOIR 2007
 * 
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.realtime.voice.javasound;

import static org.junit.Assert.assertTrue;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.logging.Logger;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;

import org.apache.commons.io.FileUtils;
import org.junit.Test;

import avoir.realtime.javasound.AMAudioFormat;
import avoir.realtime.javasound.AudioCapture;
import avoir.realtime.javasound.Synchronizer;
import avoir.realtime.voice.audio.AudioTestCase;

/**
 * Unit test of the AudioCapture class.
 */
public class AudioCaptureTest extends AudioTestCase {
    
    private static Logger logger = Logger.getLogger(AudioCaptureTest.class
	    .getName());

    /**
     * Tests the basic capturing of audio.
     * 
     * @throws Exception If an error occurs during the audio capture.
     */
    @Test
    public void testCapture_GSM() throws Exception {
	if (jmfInstalled) {
	AudioFormat format = AMAudioFormat.getLineAudioFormat(AMAudioFormat.FORMAT_CODE_GSM);
	AudioCapture capture = new AudioCapture(format);
	capture.open();
	capture.start();
	AudioInputStream audioInput = capture.getAudioInputStream();
	
	File outputFile = new File(dataFolder, "audio-capture.gsm");
	FileUtils.forceDeleteOnExit(outputFile); //mark generated file for deletion
	
	OutputStream audioOutput = new BufferedOutputStream(new FileOutputStream(outputFile));
	//150ms buffer size for synchronizer
	Synchronizer synchronizer = new Synchronizer(audioInput, audioOutput, (int) AMAudioFormat.ms2Bytes(150, audioInput.getFormat()));
	synchronizer.start(); //starts the capture
	Thread.sleep(5000);
	synchronizer.stop(true); //stops the capture immediately.
	capture.close();
	assertTrue(outputFile.exists()); //check that audio was really captured to file
	}
    }

}
