/**
 *  $Id: IncrementalAudioCapturer.java,v 1.12 2007/04/05 13:35:57 mohamed Exp $
 *
 *  Copyright (C) GNU/GPL AVOIR 2007
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.realtime.voice.audio;

import java.io.File;
import java.io.IOException;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.media.CaptureDeviceInfo;
import javax.media.CaptureDeviceManager;
import javax.media.DataSink;
import javax.media.Format;
import javax.media.Manager;
import javax.media.MediaLocator;
import javax.media.Processor;
import javax.media.ProcessorModel;
import javax.media.format.AudioFormat;
import javax.media.protocol.DataSource;
import javax.media.protocol.FileTypeDescriptor;

import avoir.realtime.http.UploadThread;

/**
 * Audio Capturer that splits the captured audio into a set of files with 
 * incremental file names and uploads them to an HTTP server.
 * 
 * @author adrian
 */
public class IncrementalAudioCapturer implements Runnable {

    /**
     * Default value for file name prefix.
     */
    public static final String DEFAULT_FILE_NAME_PREFIX = "test";

    /**
     * Default value for file name separator (i.e. to separate the prefix from
     * the counter value for a file).
     */
    public static final String DEFAULT_FILE_NAME_SEPARATOR = "_";

    //  TODO: make configurable
    public static int DEFAULT_CLIP_TIME = 5000; //milliseconds

    private static Logger logger = Logger
            .getLogger(IncrementalAudioCapturer.class.getName());

    private boolean continueCapture = false;

    private boolean running = true;

    //java.lang.String encoding, double sampleRate, int sampleSizeInBits, int channels, int endian, int signed
    //TODO: make configurable
    //private Format audioFormat = new AudioFormat(AudioFormat.GSM, 8000.0, 16, 1, AudioFormat.LITTLE_ENDIAN, AudioFormat.SIGNED);
    private Format audioFormat = new AudioFormat(AudioFormat.GSM);

    private FileTypeDescriptor outputType = new FileTypeDescriptor(
            FileTypeDescriptor.GSM);

    private Processor processor = null;

    //TODO: make configurable, also sort out cleaning this up
    private File localDirectory = new File("/tmp/");

    //id of person broadcasting
    private String fileNamePrefix = DEFAULT_FILE_NAME_PREFIX;

    private String fileNameSeparator = DEFAULT_FILE_NAME_SEPARATOR;

    private int fileNameCounter = 0; //what file to start with

    private String uploadLocation = null;

    private DataSink filewriter = null;

    private AudioObserver observer;

    private DataSource captureOutputSource;

    /**
     * Constructs a new instance of this class, using the passed strings 
     * as the file name prefix and file name separator. Audio captured will 
     * be uploaded to the passed location.
     * 
     * @param uploadLocation Location where audio should be uploaded to.
     * @param fileNamePrefix Prefix of files created by this object.
     * @param fileNameSeparator Separator used in file names (i.e. between prefix 
     * and file number).
     * @param observer Observer object interested in status changes. 
     */
    public IncrementalAudioCapturer(String uploadLocation,
            String fileNamePrefix, String fileNameSeparator,
            AudioObserver observer) {
        this.uploadLocation = uploadLocation;
        this.fileNamePrefix = fileNamePrefix;
        this.fileNameSeparator = fileNameSeparator;
        this.observer = observer;

        CaptureDeviceInfo audioCaptureDevice = getAudioCaptureDevice();
        MediaLocator captureDeviceLocator = audioCaptureDevice.getLocator();
        Format[] audioOutputFormat = new Format[] { audioFormat };
        try {
            DataSource captureDataSource = Manager
                    .createDataSource(captureDeviceLocator);
            ProcessorModel captureModel = new ProcessorModel(captureDataSource,
                    audioOutputFormat, outputType);
            processor = Manager.createRealizedProcessor(captureModel);
            captureOutputSource = processor.getDataOutput();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        Thread captureThread = new Thread(this);
        captureThread.start();
    }

    /**
     * Constructs a new instance of this class, using default values for 
     * file name prefix and separator. Audio captured will 
     * be uploaded to the passed location.
     * 
     * @param uploadLocation Location where audio should be uploaded to.
     * @param observer Observer object interested in status changes. 
     */
    public IncrementalAudioCapturer(String uploadLocation,
            AudioObserver observer) {
        this(uploadLocation, DEFAULT_FILE_NAME_PREFIX,
                DEFAULT_FILE_NAME_SEPARATOR, observer);
    }

    //TODO: move into a util class?
    public CaptureDeviceInfo getAudioCaptureDevice() {
        Vector devices = CaptureDeviceManager.getDeviceList(null);
        if (devices.size() > 0) {
            logger.fine("Capture devices: " + devices.size());
            return (CaptureDeviceInfo) devices.elementAt(0);
        } else {
            throw new RuntimeException("Unable to find any capture devices");
        }
    }

    /**
     * Starts capturing audio to a file with the passed name
     * 
     * @param filePath Full path and name of file to capture audio to.
     * @throws AudioCaptureException If an error occurs starting the audio capture. 
     */
    public void startAudioCapture(String filePath) throws AudioCaptureException {
        try {
            MediaLocator destination = new MediaLocator("file://" + filePath);
            // create a datasink to do the file
            filewriter = Manager.createDataSink(captureOutputSource,
                    destination);
            filewriter.open();
            filewriter.start();
            processor.start();
        } catch (Exception e) {
            throw new AudioCaptureException("Error starting audio capture", e);
        }
    }

    /**
     * Stops the capture and transmission of audio.
     */
    private void stopTransmission(boolean closeProcessor) {
        if (processor != null) {
            processor.stop();
            if (closeProcessor) {
                processor.close();
                processor = null;
            }
        }
        if (filewriter != null) {
            try {
                filewriter.stop();
                filewriter.close();
                filewriter = null;
            } catch (IOException e) {
                logger.log(Level.WARNING, "Error closing filewriter", e);
            }
        }
        logger.fine("Audio capturer closed");
    }

    /**
     * Stops capturing audio.
     */
    public void stopCapture() {
        this.continueCapture = false;
        logger.fine("Stopping audio capture");
    }

    /**
     * Starts capturing audio.
     */
    public void startCapture() {
        this.continueCapture = true;
        logger.fine("(Re)starting audio capture");
    }

    /**
     * Stops this thread. 
     */
    public void stop() {
        this.running = false;
        this.stopCapture();
        this.stopTransmission(true);
    }

    /* (non-Javadoc)
     * @see java.lang.Runnable#run()
     */
    public void run() {
        while (running) {
            while (continueCapture) {
                String outputFileName = fileNamePrefix + fileNameSeparator
                        + fileNameCounter + ".gsm";
                File outputFile = new File(localDirectory, outputFileName);
                try {
                    this.startAudioCapture(outputFile.getAbsolutePath());
                    logger.fine("Transmission started for " + outputFileName
                            + " for " + DEFAULT_CLIP_TIME + " milliseconds...");
                    try {
                        Thread.sleep(DEFAULT_CLIP_TIME);
                    } catch (InterruptedException e) {
                        logger.log(Level.WARNING, "Capturer interrupted", e);
                    }

                    stopTransmission(false);
                    logger.fine("Transmission ended for " + outputFileName);
                    UploadThread uploadThread = new UploadThread(outputFile,
                            uploadLocation);
                    uploadThread.setName(fileNamePrefix);
                    uploadThread.start();
                    observer.updateStatus("Uploading "
                            + outputFile.getAbsolutePath() + " to "
                            + uploadLocation);
                    fileNameCounter++;
                } catch (AudioCaptureException e) {
                    //TODO:we could also stop running, but then we need to handle
                    //threads better in applet
                    continueCapture = false;
                    logger.log(Level.SEVERE, "Error capturing audio", e
                            .getCause());
                    observer.updateStatus("Error capturing audio: "
                            + e.getCause().getMessage());
                    observer.captureComplete();
                }
            }
            try {
                Thread.sleep(DEFAULT_CLIP_TIME);
                //logger.finest("Capture thread running...");
            } catch (InterruptedException e) {
                logger.log(Level.WARNING, "Capturer interrupted", e);
            }
        }
    }

    public File getLocalDirectory() {
        return localDirectory;
    }

    public void setLocalDirectory(File localDirectory) {
        this.localDirectory = localDirectory;
    }

    public String getUploadLocation() {
        return uploadLocation;
    }

    public void setUploadLocation(String uploadURL) {
        this.uploadLocation = uploadURL;
    }

    public String getFileNamePrefix() {
        return fileNamePrefix;
    }

    public void setFileNamePrefix(String baseFileName) {
        this.fileNamePrefix = baseFileName;
    }

    public int getFileNameCounter() {
        return fileNameCounter;
    }

    public void setFileNameCounter(int counter) {
        this.fileNameCounter = counter;
    }

    public String getFileNameSeparator() {
        return fileNameSeparator;
    }

    public void setFileNameSeparator(String fileNameSeparator) {
        this.fileNameSeparator = fileNameSeparator;
    }

}
