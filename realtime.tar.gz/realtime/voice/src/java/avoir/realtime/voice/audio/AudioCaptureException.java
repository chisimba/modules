/**
 *  $Id: AudioCaptureException.java,v 1.1 2007/02/21 16:05:45 adrian Exp $
 *
 *  Copyright (C) GNU/GPL AVOIR 2007
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.realtime.voice.audio;

/**
 * Exception class that represents error conditions that may occur when trying to 
 * capture audio.
 * 
 * @author adrian
 */
public class AudioCaptureException extends Exception {

    private static final long serialVersionUID = -5882057036978878527L;

    /**
     * Constructs a new AudioCaptureException with null as its detail message.
     *
     */
    public AudioCaptureException() {
    }

    /**
     * Constructs a new AudioCaptureException with the specified detail message.
     * 
     * @param message
     */
    public AudioCaptureException(String message) {
	super(message);
    }

    /**
     * Constructs a new AudioCaptureException with the specified detail message 
     * and cause.
     * 
     * @param message
     * @param cause
     */
    public AudioCaptureException(String message, Throwable cause) {
	super(message, cause);
    }

    /**
     * Constructs a new AudioCaptureException with the specified cause and a detail 
     * message of (cause==null ? null : cause.toString()) (which typically contains 
     * the class and detail message of cause).
     * 
     * @param cause
     */
    public AudioCaptureException(Throwable cause) {
	super(cause);
    }

}
