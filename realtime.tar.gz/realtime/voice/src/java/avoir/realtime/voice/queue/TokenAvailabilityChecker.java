/**
 * $Id: TokenAvailabilityChecker.java,v 1.1 2007/04/02 15:40:23 adrian Exp $
 * 
 * Copyright (C) GNU/GPL AVOIR 2007
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 51
 * Franklin St, Fifth Floor, Boston, MA 02110-1301 USA
 */
package avoir.realtime.voice.queue;

import java.io.IOException;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;

import avoir.realtime.http.HttpRetriever;
import static avoir.realtime.voice.audio.ServicesConstants.FALSE;
import static avoir.realtime.voice.audio.ServicesConstants.TRUE;

/**
 * Runnable class that periodically checks whether the token has become available for a certain user.
 * 
 * @author mohamed
 */
public class TokenAvailabilityChecker implements Runnable {

    private static Logger logger = Logger
            .getLogger(TokenAvailabilityChecker.class.getName());

    /**
     * Boolean variable to control whether this should continue running.
     */
    private boolean running;

    /**
     * Observer class to receive feedback when the token has become available.
     */
    private TokenObserver observer;

    /**
     * Base url of the realtime controller.
     */
    private String realtimeControllerURL;

    /**
     * Default time to wait inbetween calls to check whether token has become available.
     */
    private static final int DEFAULT_WAIT_TIME = 5000;

    /**
     * Time to wait inbetween calls to check whether token has become available.
     */
    private int waitTime;

    /**
     * Constructs a new instance of this class, using the passed string as the
     * domain or site root url and tokenturn observer.
     * 
     * @param baseURL domain or the base URI.
     */
    public TokenAvailabilityChecker(String baseURL, TokenObserver observer) {
        this(baseURL, DEFAULT_WAIT_TIME, observer);
    }

    /**
     * Constructs a new instance of this class, using the passed strings as the
     * domain or site root url.
     * 
     * @param baseURL domain or the base URI.
     * @param time Time (in milliseconds) to wait inbetween calls to server to check token availability.
     */
    public TokenAvailabilityChecker(String baseURL, int time,
            TokenObserver observer) {
        realtimeControllerURL = baseURL;
        waitTime = time;
        this.observer = observer;
        Thread tokenCheckerThread = new Thread(this);
        tokenCheckerThread.start();
    }

    public void stop() {
        this.running = false;
    }

    public void run() {
        running = true;
        while (running) {
            try {
                Thread.sleep(waitTime);
            } catch (InterruptedException e) {
                logger.log(Level.SEVERE,
                        "Error thread interrupted while checking for token", e);
            }
            if (running) {
                try {
                    String returnedValue = HttpRetriever.getText(new URL(
                            realtimeControllerURL + "&action=checkturn"));
                    if (running) {
                        if (TRUE.equals(returnedValue)) {
                            logger.finest("It is your turn");
                            running = false;
                            observer.gotToken();
                        } else if (FALSE.equals(returnedValue)) {
                            logger.finest("waiting for token");
                            running = true;
                        } else {
                            logger
                                    .severe("Unexpected return value while checking for token: "
                                            + returnedValue);
                            running = false;
                        }
                    }
                } catch (IOException e) {
                    logger.log(Level.SEVERE, "Error checking for token", e);
                }
            }
        }
    }
}
