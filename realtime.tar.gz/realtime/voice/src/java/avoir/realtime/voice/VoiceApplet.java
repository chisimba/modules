/**
 * $Id: VoiceApplet.java,v 1.21 2007-06-20 09:43:01 mohamed Exp $
 * 
 * Copyright (C) GNU/GPL AVOIR 2007
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 51
 * Franklin St, Fifth Floor, Boston, MA 02110-1301 USA
 */
package avoir.realtime.voice;

import static avoir.realtime.voice.audio.ServicesConstants.FAILURE;
import static avoir.realtime.voice.audio.ServicesConstants.SUCCESS;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JSlider;
import javax.swing.JTextField;
import javax.swing.ListModel;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import avoir.realtime.User;
import avoir.realtime.UserLevel;
import avoir.realtime.UserListModel;
import avoir.realtime.applet.RealtimeApplet;
import avoir.realtime.http.HttpRetriever;
import avoir.realtime.voice.audio.AudioObserver;
import avoir.realtime.voice.audio.IncrementalAudioCapturer;
import avoir.realtime.voice.audio.IncrementalAudioPlayer;
import avoir.realtime.voice.audio.ServicesConstants;
import avoir.realtime.voice.queue.TokenAvailabilityChecker;
import avoir.realtime.voice.queue.TokenChecker;
import avoir.realtime.voice.queue.TokenObserver;
import avoir.realtime.voice.queue.VoiceQueueMonitor;
import avoir.realtime.voice.queue.VoiceQueueObserver;
import avoir.swing.JListPopupListener;
import avoir.util.AppletUtils;
import avoir.util.ImageUtil;
import avoir.util.ExtensionFilter;

/**
 * Realtime tools voice applet which provides a means to capture and upload
 * audio and also to stream audio.
 */
public class VoiceApplet extends RealtimeApplet implements ActionListener,
        ChangeListener, AudioObserver, TokenObserver, VoiceQueueObserver {

    private static final long serialVersionUID = 2923212710175093721L;

    private static Logger logger = Logger
            .getLogger(VoiceApplet.class.getName());

    /**
     * Applet paramater for the local directory to use for reading/writing
     * files.
     */
    private static final String PARAM_LOCAL_DIRECTORY = "localdirectory";

    /**
     * Action command for capturing and transmitting audio.
     */
    private static final String COMMAND_START_TRANSMITTING = "start_transmitting";

    /**
     * Action command for stopping capture and transmission of audio.
     */
    private static final String COMMAND_STOP_TRANSMITTING = "stop_transmitting";

    /**
     * Action command for requesting token.
     */
    private static final String COMMAND_REQUEST_TOKEN = "request_token";

    /**
     * Action command for releasing token.
     */
    private static final String COMMAND_RELEASE_TOKEN = "release_token";

    /**
     * Action command for receiving audio and playing it back.
     */
    private static final String COMMAND_START_RECEIVING = "stop_receiving";

    /**
     * Action command to stop receiving and playing audio.
     */
    private static final String COMMAND_STOP_RECEIVING = "start_receiving";

    /**
     * Action command to start conversation.
     */
    private static final String COMMAND_START_CONVERSATION = "start_conversation";

    /**
     * Action command to stop conversation.
     */
    private static final String COMMAND_STOP_CONVERSATION = "stop_conversation";

    /**
     * Action command to join conversation.
     */
    private static final String COMMAND_JOIN_CONVERSATION = "join_conversation";

    /**
     * Action command to leave conversation.
     */
    private static final String COMMAND_LEAVE_CONVERSATION = "leave_conversation";

    /**
     * Action command to assign a token.
     */
    private static final String COMMAND_ASSIGN_TOKEN = "assign_token";

    /**
     * Applet parameter for the location of the voice resource folder on the server.
     */
    private static final String PARAM_VOICE_URL = "voiceURL";

    /**
     * Applet parameter for the realtime controller URL.
     */
    private static final String PARAM_REALTIME_CONTROLLER_URL = "realtimeControllerURL";

    /**
     * Button to trigger receiving audio.
     */
    private JButton startReceivingButton = new JButton("Listen");

    /**
     * Button to stop receiving audio.
     */
    private JButton stopReceivingButton = new JButton("Stop");

    /**
     * Button to start capturing and transmitting audio.
     */
    private JButton startTransmittingButton = new JButton("Transmit");

    /**
     * Button to stop capturing and transmitting audio.
     */
    private JButton stopTransmittingButton = new JButton("Stop");

    /**
     * Button to request token.
     */
    private JButton requestTokenButton = null;

    /**
     * Button to start conversation
     */
    private JButton conversationButton = new JButton("Start Conversation");

    /**
     * Button to join conversation
     */
    private JButton joinConversationButton = new JButton("Join Conversation");

    /**
     * Field for status messages.
     */
    private JTextField status = new JTextField();

    /**
     * Volume/gain slider for playback.
     */
    private JSlider gainSlider = new JSlider(JSlider.HORIZONTAL, 0, 10,
            (int) (IncrementalAudioPlayer.DEFAULT_GAIN * 10));

    /**
     * Object that captures audio.
     */
    private IncrementalAudioCapturer audioCapturer;

    /**
     * Object that plays audio.
     */
    private IncrementalAudioPlayer player = null;

    /**
     * The location on the server where the audio to be played is.
     */
    private String audioLocation = null;

    /**
     * The URL of the file locator service.
     */
    private URL fileLocator = null;

    /**
     * The location of the voice server.
     */
    private String voiceServerBase;

    /**
     * Base url of the realtime controller.
     */
    private String realtimeControllerURL;

    /**
     * The address of the upload service.
     */
    private String uploadService;

    /**
     * Directory on client machine that can be used for writing files during
     * playback and capture.
     */
    private File localDirectory;

    /**
     * The Chisimba user who is running this applet.
     */
    private User user;

    /**
     * Image icon for when user has the token.
     */
    private ImageIcon hasTokenIcon;

    /**
     * Image icon for when user does not have the token.
     */
    private ImageIcon noTokenIcon;

    /**
     * GUI list for displaying the User's currently waiting for a token in the voice queue.
     */
    private JList voiceQueueList = new JList();

    /**
     * Checks whether the user still has the token.
     */
    private TokenChecker tokenChecker;

    /**
     * Checks whether the token has become available for the user.
     */
    private TokenAvailabilityChecker availableChecker;

    /**
     * Checks on the contents of the voice queue.
     */
    private VoiceQueueMonitor voiceQueueMonitor;

    /**
     * if seted true, audio files in tmp folder will be delted
     * after files has been uploaded
     */
    private String deleteFile;

    /**
     * Applet init method.
     */
    public void init() {
        super.init();
        user = getCurrentUser();
        
        deleteFile = getParameter("deleteFILE");
        
        realtimeControllerURL = AppletUtils.getRequiredParameter(this,
                PARAM_REALTIME_CONTROLLER_URL);
        voiceServerBase = AppletUtils.getRequiredParameter(this,
                PARAM_VOICE_URL);
        if (!voiceServerBase.endsWith("/")) {
            voiceServerBase = voiceServerBase + "/";
        }
        audioLocation = voiceServerBase + ServicesConstants.SERVER_AUDIO_PATH;
        uploadService = voiceServerBase
                + ServicesConstants.SERVICE_AUDIO_UPLOAD;
        try {
            fileLocator = new URL(voiceServerBase
                    + ServicesConstants.SERVICE_FILE_LOCATOR);
        } catch (MalformedURLException e) {
            throw new RuntimeException(e);
        }

        String localDirectoryString = getParameter(PARAM_LOCAL_DIRECTORY);
        if (localDirectoryString != null) {
            localDirectory = new File(localDirectoryString);
        } else { // not set in applet, set to system tmp dir
            localDirectory = new File(System.getProperty("java.io.tmpdir"));
        }
        if (!localDirectory.exists() || !localDirectory.isDirectory()
                || !localDirectory.canWrite()) {
            throw new RuntimeException("Check that the folder "
                    + localDirectory.getAbsolutePath()
                    + "exists and is writable");
        }

        try {
            SwingUtilities.invokeAndWait(new Runnable() {
                public void run() {
                    buildUI();
                }
            });
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error creating GUI", e);
        }
    }

    /**
     * Builds the user interface for this applet.
     */
    private void buildUI() {
        setLayout(new BorderLayout());
        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new GridLayout(0, 1));

        JPanel conversationPanel = new JPanel();
        conversationPanel.setBackground(backgroundColor);
        if (user.getLevel() == UserLevel.LECTURER) {
            // present lecturer with buttons for starting/stopping conversation
            conversationButton.setActionCommand(COMMAND_START_CONVERSATION);
            conversationButton.addActionListener(this);
            conversationPanel.add(conversationButton);

            // present lecturer with voice queue list and means of assigning users tokens
            voiceQueueList
                    .setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            JScrollPane voiceQueueListPane = new JScrollPane(voiceQueueList);
            voiceQueueListPane.setPreferredSize(new Dimension(100, 400));

            //create popup menu to allow lecturer to assign token to user
            JPopupMenu voiceQueueMenu = new JPopupMenu();
            JMenuItem assignTokenItem = new JMenuItem("Assign token");
            assignTokenItem.setActionCommand(COMMAND_ASSIGN_TOKEN);
            assignTokenItem.addActionListener(this);
            voiceQueueMenu.add(assignTokenItem);

            MouseListener popupListener = new JListPopupListener(
                    voiceQueueList, voiceQueueMenu);
            voiceQueueList.addMouseListener(popupListener);

            JPanel voiceQueuePanel = new JPanel();
            voiceQueuePanel.setLayout(new BorderLayout());
            voiceQueuePanel.setBackground(backgroundColor);

            JLabel voiceQueueLabel = new JLabel("Voice Queue");
            voiceQueuePanel.add(voiceQueueLabel, BorderLayout.NORTH);
            voiceQueuePanel.add(voiceQueueListPane, BorderLayout.CENTER);
            add(voiceQueuePanel, BorderLayout.WEST);
        } else {
            // all other users are shown buttons to join/leave a conversations
            joinConversationButton.setActionCommand(COMMAND_JOIN_CONVERSATION);
            joinConversationButton.addActionListener(this);
            conversationPanel.add(joinConversationButton);
        }
        centerPanel.add(conversationPanel);

        try {
            hasTokenIcon = ImageUtil.createImageIcon(this,
                    "/icons/yestoken.gif");
            noTokenIcon = ImageUtil.createImageIcon(this, "/icons/notoken.gif");
        } catch (FileNotFoundException e) {
            logger.log(Level.SEVERE, "Error loading image icons", e);
        }

        JPanel transmissionPanel = new JPanel();
        transmissionPanel.setBackground(backgroundColor);
        transmissionPanel.setLayout(new FlowLayout());

        requestTokenButton = new JButton(noTokenIcon);
        requestTokenButton.setToolTipText("Request Token");
        requestTokenButton.setContentAreaFilled(false);

        requestTokenButton.setPreferredSize(new Dimension(noTokenIcon
                .getIconWidth(), noTokenIcon.getIconHeight()));

        requestTokenButton.setActionCommand(COMMAND_REQUEST_TOKEN);
        requestTokenButton.addActionListener(this);
        transmissionPanel.add(requestTokenButton);

        startTransmittingButton.setActionCommand(COMMAND_START_TRANSMITTING);
        startTransmittingButton.addActionListener(this);
        transmissionPanel.add(startTransmittingButton);

        stopTransmittingButton.setActionCommand(COMMAND_STOP_TRANSMITTING);
        stopTransmittingButton.addActionListener(this);
        transmissionPanel.add(stopTransmittingButton);

        centerPanel.add(transmissionPanel);

        JPanel playbackPanel = new JPanel();
        playbackPanel.setLayout(new FlowLayout());
        playbackPanel.setBackground(backgroundColor);

        startReceivingButton.setActionCommand(COMMAND_START_RECEIVING);
        startReceivingButton.addActionListener(this);
        playbackPanel.add(startReceivingButton);

        stopReceivingButton.setActionCommand(COMMAND_STOP_RECEIVING);
        stopReceivingButton.addActionListener(this);
        playbackPanel.add(stopReceivingButton);

        JLabel gainLabel = new JLabel("Volume:");
        playbackPanel.add(gainLabel);
        gainSlider.setBackground(backgroundColor);
        gainSlider.addChangeListener(this);
        gainSlider.setMajorTickSpacing(1);
        gainSlider.setPreferredSize(new Dimension(50, 30));
        gainSlider.setToolTipText("Adjust playback volume");
        playbackPanel.add(gainSlider);

        centerPanel.add(playbackPanel);
        add(centerPanel, BorderLayout.CENTER);
        status.setBackground(backgroundColor);
        status.setEditable(false);
        add(status, BorderLayout.SOUTH);

        disableButtons();
    }

    /**
     * Applet start method.
     */
    public void start() {
        // all actions are event driven, so nothing to do here
    }

    /**
     * Applet stop method.
     */
    public void stop() {
        stopTransmitting();
        stopReceiving();
        setToken(false);
        disableButtons();
        stopThreads();
    }

    /**
     * Applet destroy method.
     */
    public void destroy() {
        stop();
    }

    public void stopThreads() {
        if (tokenChecker != null) {
            tokenChecker.stop();
        }
        if (availableChecker != null) {
            availableChecker.stop();
        }
        if (voiceQueueMonitor != null) {
            voiceQueueMonitor.stop();
        }
    }

    /**
     * Stops capture and transmission of audio and resets GUI controls
     * accordingly.
     */
    private void stopTransmitting() {
        if (audioCapturer != null) {
            audioCapturer.stop();
            deleteFilesOnClient();
        }
        stopTransmittingButton.setEnabled(false);
        startReceivingButton.setEnabled(true);
        status.setText("Audio transmission stopped");
    }

    /**
     * Starts capture and transmission of audio and sets GUI controls
     * accordingly.
     */
    private void startTransmitting() {
        audioCapturer = new IncrementalAudioCapturer(uploadService, user
                .getFullName(), "_", this);
        audioCapturer.setLocalDirectory(localDirectory);
        audioCapturer.startCapture();
        stopTransmittingButton.setEnabled(true);
        startTransmittingButton.setEnabled(false);
        startReceivingButton.setEnabled(false);
        status.setText("Transmitting audio");
    }

    /**
     * Stops reception and playback of audio.
     */
    private void stopReceiving() {
        if (player != null) {
            player.stopPlaying();
            deleteFilesOnClient();
        }
    }

    /**
     * Starts reception and playback of audio and sets GUI controls accordingly.
     */
    private void startReceiving() {
        startReceivingButton.setEnabled(false); // prevent connecting twice
        player = new IncrementalAudioPlayer(localDirectory, audioLocation,
                fileLocator, this);
        player.startPlaying();

        startTransmittingButton.setEnabled(false);
        stopReceivingButton.setEnabled(true); // allow disconnecting
    }

    /**
     * Informs server that lecturer would like to start a conversation.
     */
    private void startConversation() {
        status.setText("Starting conversation...");
        try {
            String returnedValue = HttpRetriever.getText(new URL(
                    realtimeControllerURL + "&action=startconversation"));
            if (SUCCESS.equals(returnedValue)) {
                updateStatus("Conversation succesfully started");
                toggleStartStopConversationButton();
                startTransmittingButton.setEnabled(true);
                setToken(true);
                voiceQueueMonitor = new VoiceQueueMonitor(
                        realtimeControllerURL, this);
            } else if (FAILURE.equals(returnedValue)) {
                updateStatus("Could not start conversation");
            } else {
                logger
                        .severe("Unexpected return value while starting conversation: "
                                + returnedValue);
            }
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Error starting conversation", e);
        }
    }

    /**
     * Informs the server that the lecturer is stopping a conversation.
     */
    private void stopConversation() {
        status.setText("Stopping conversation...");
        try {
            String returnedValue = HttpRetriever.getText(new URL(
                    realtimeControllerURL + "&action=stopconversation"));
            if (SUCCESS.equals(returnedValue)) {
                updateStatus("Conversation succesfully stopped");
                toggleStartStopConversationButton();
                stop();
            } else if (FAILURE.equals(returnedValue)) {
                updateStatus("Could not stop conversation");
            } else {
                logger
                        .severe("Unexpected return value while stopping conversation: "
                                + returnedValue);
            }
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Error stopping conversation", e);
        }
    }

    /**
     * Informs server that a user wants to join a conversation.
     */
    private void joinConversation() {
        status.setText("Joining conversation...");
        try {
            String returnedValue = HttpRetriever.getText(new URL(
                    realtimeControllerURL + "&action=joinconversation"));
            if (SUCCESS.equals(returnedValue)) {
                updateStatus("You have joined the conversation");
                toggleJoinLeaveConversationButton();
                startReceivingButton.setEnabled(true);
                requestTokenButton.setEnabled(true);
            } else if (FAILURE.equals(returnedValue)) {
                updateStatus("Could not join conversation");
            } else {
                logger
                        .severe("Unexpected return value while joining conversation: "
                                + returnedValue);
            }
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Error joining conversation", e);
        }
    }

    /**
     * Informs server that user wants to leave a conversation.
     */
    private void leaveConversation() {
        status.setText("Leaving conversation...");
        try {
            String returnedValue = HttpRetriever.getText(new URL(
                    realtimeControllerURL + "&action=leaveconversation"));
            if (SUCCESS.equals(returnedValue)) {
                updateStatus("You left the conversation");
                toggleJoinLeaveConversationButton();
                stop();
            } else if (FAILURE.equals(returnedValue)) {
                updateStatus("Error leaving conversation");
            } else {
                logger
                        .severe("Unexpected return value while leaving conversation: "
                                + returnedValue);
            }
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Error leaving conversation", e);
        }
    }

    /**
     * ActionListener method - the core of deciding what functionality this applet performs by responding 
     * to various GUI events.
     * 
     * @param event ActionEvent performed.
     */
    public void actionPerformed(ActionEvent event) {
        String command = event.getActionCommand();
        if (COMMAND_START_TRANSMITTING.equals(command)) {
            startTransmitting();
        } else if (COMMAND_STOP_TRANSMITTING.equals(command)) {
            stopTransmitting();
        } else if (COMMAND_REQUEST_TOKEN.equals(command)) {
            requestToken();
        } else if (COMMAND_RELEASE_TOKEN.equals(command)) {
            releaseToken();
        } else if (COMMAND_START_RECEIVING.equals(command)) {
            startReceiving();
        } else if (COMMAND_STOP_RECEIVING.equals(command)) {
            stopReceiving();
        } else if (COMMAND_START_CONVERSATION.equals(command)) {
            startConversation();
        } else if (COMMAND_STOP_CONVERSATION.equals(command)) {
            stopConversation();
        } else if (COMMAND_JOIN_CONVERSATION.equals(command)) {
            joinConversation();
        } else if (COMMAND_LEAVE_CONVERSATION.equals(command)) {
            leaveConversation();
        } else if (COMMAND_ASSIGN_TOKEN.equals(command)) {
            assignTokenToUser();
        } else {
            logger.warning("Unrecognised action command: " + command);
        }
    }

    /**
     * Player observer method. Called when the player changes its status.
     * 
     * @param newStatus Status string.
     */
    public void updateStatus(String newStatus) {
        status.setText(newStatus);
    }

    /**
     * Audio observer method. Called when the player is finished.
     */
    public void playingComplete() {
        startReceivingButton.setEnabled(true);
        stopReceivingButton.setEnabled(false);
    }

    /**
     * Audio observer method. Called when the capturer is finished.
     */
    public void captureComplete() {
        startReceivingButton.setEnabled(true);
        stopReceivingButton.setEnabled(false);
        startTransmittingButton.setEnabled(true);
        stopTransmittingButton.setEnabled(false);
    }

    /**
     * ChangeListener implementation. Responds to changes in value of gain (i.e.
     * volume) slider.
     * 
     * @event The ChangeEvent.
     */
    public void stateChanged(ChangeEvent event) {
        JSlider source = (JSlider) event.getSource();
        if (!source.getValueIsAdjusting()) {
            float newGain = (int) source.getValue() / 10.0f;
            if (player != null) {
                player.setGain(newGain);
            }
        }
    }

    /**
     * Toggles the stop/start conversation button depending on its current state.
     */
    private void toggleStartStopConversationButton() {
        if (COMMAND_START_CONVERSATION.equals(conversationButton
                .getActionCommand())) {
            conversationButton.setActionCommand(COMMAND_STOP_CONVERSATION);
            conversationButton.setText("Stop Conversation");
        } else {
            conversationButton.setActionCommand(COMMAND_START_CONVERSATION);
            conversationButton.setText("Start Conversation");
        }
    }

    /**
     * Toggles the join/leave conversation button depending on its current state.
     */
    private void toggleJoinLeaveConversationButton() {
        if (COMMAND_JOIN_CONVERSATION.equals(joinConversationButton
                .getActionCommand())) {
            joinConversationButton.setActionCommand(COMMAND_LEAVE_CONVERSATION);
            joinConversationButton.setText("Leave Conversation");
        } else {
            joinConversationButton.setActionCommand(COMMAND_JOIN_CONVERSATION);
            joinConversationButton.setText("Join Conversation");
        }
    }

    /**
     * Informs the server that a user is requesting a voice token, assigns token to User if the token is
     * available.
     */
    private void requestToken() {
        status.setText("Requesting token...");
        try {
            String returnedValue = HttpRetriever.getText(new URL(
                    realtimeControllerURL + "&action=requesttoken"));
            if (SUCCESS.equals(returnedValue)) {
                updateStatus("Token successfully requested.");
                setToken(true);
            } else if (FAILURE.equals(returnedValue)) {
                availableChecker = new TokenAvailabilityChecker(
                        realtimeControllerURL, this);
                requestTokenButton.setEnabled(false);
                updateStatus("Token not available, in queue");
            } else {
                logger
                        .severe("Unexpected return value while requesting token: "
                                + returnedValue);
            }
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Error requesting token", e);
        }
    }

    /**
     * Sets whether the User running this applet has the token or not.
     * 
     * @param hasToken true if the user has the token, false otherwise.
     */
    private void setToken(boolean hasToken) {
        requestTokenButton.setEnabled(true);
        if (hasToken) { // we have acquired the token, update gui and start thread to monitor token
            requestTokenButton.setIcon(hasTokenIcon);
            requestTokenButton.setActionCommand(COMMAND_RELEASE_TOKEN);
            requestTokenButton.setToolTipText("Release Token");
            startTransmittingButton.setEnabled(true);
            tokenChecker = new TokenChecker(realtimeControllerURL, this);
        } else { // we no longer have token, update gui, stop thread monitoring token
            if (tokenChecker != null) {
                tokenChecker.stop();
            }
            requestTokenButton.setIcon(noTokenIcon);
            requestTokenButton.setActionCommand(COMMAND_REQUEST_TOKEN);
            requestTokenButton.setToolTipText("Request Token");
            stopTransmitting();
            startTransmittingButton.setEnabled(false);
        }
    }

    /**
     * Disables GUI buttons controlling functionality of tokens, player and receiver.
     */
    private void disableButtons() {
        requestTokenButton.setEnabled(false);
        startReceivingButton.setEnabled(false);
        stopReceivingButton.setEnabled(false);
        startTransmittingButton.setEnabled(false);
        stopTransmittingButton.setEnabled(false);
    }

    /**
     * Inform server that User has released token.
     */
    private void releaseToken() {
        status.setText("Releasing token...");
        try {
            String returnedValue = HttpRetriever.getText(new URL(
                    realtimeControllerURL + "&action=releasetoken"));
            if (SUCCESS.equals(returnedValue)) {
                updateStatus("Token Released");
                setToken(false);
            } else if (FAILURE.equals(returnedValue)) {
                updateStatus("Could not release token");
            } else {
                logger.severe("Unexpected return value while releasing token: "
                        + returnedValue);
            }
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Error releasing token", e);
        }
    }

    /**
     * Observer method that is called when token monitor thread detects that User has lost token.
     */
    public void lostToken() {
        setToken(false);
        updateStatus("Token has been taken by another user");
    }

    /**
     * Observer method that is called when the User gets the token.
     */
    public void gotToken() {
        setToken(true);
        updateStatus("You have the token");
    }

    /**
     * Informs the server that the lecturer is assigning the token to a particular user.
     */
    private void assignTokenToUser() {
        User selectedUser = (User) voiceQueueList.getSelectedValue();
        try {
            String returnedValue = HttpRetriever.getText(new URL(
                    realtimeControllerURL + "&action=assigntoken&id="
                            + selectedUser.getUserId()));
            if (SUCCESS.equals(returnedValue)) {
                updateStatus("Token assigned to " + selectedUser.getFullName());
                setToken(false);
            } else {
                updateStatus("Token not assigned to "
                        + selectedUser.getFullName());
                logger.finest("could not assign token to "
                        + selectedUser.getFullName());
            }
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Error assigning token", e);
        }
    }

    /**
     * Observer method that is called when the server sends the contents of the voice queue.
     */
    public void queueUpdated(List<User> users) {
        ListModel listModel = voiceQueueList.getModel();
        if (!(listModel instanceof UserListModel)) {
            //first time this method is being called, we haven't set model yet
            UserListModel usersModel = new UserListModel(users);
            voiceQueueList.setModel(usersModel);
        } else {
            List currentUserList = ((UserListModel) listModel).getUserList();
            if (!currentUserList.equals(users)) {
                //if list not equal, then something must have changed so we update model
                UserListModel usersModel = new UserListModel(users);
                voiceQueueList.setModel(usersModel);
            } else {
                logger.finest("List not changed, ignoring");
            }
        }
    }

    /**
     *  deletes audio files on client machine after 
     *  files has been uploaded to the server.
     *  assumes that audio files are on tmp folder.
     *  
     *  TODO: currently this method does not delete last file,
     *  becouse it is not been uploaded.
     *  needs observer which checks that the last file has been uploaded.
     */
    private void deleteFilesOnClient() {

        if (!deleteFile.equals("true")) {
            logger.finest("Delete: user opted not to delete files " + deleteFile );
        } else {
            localDirectory = new File(System.getProperty("java.io.tmpdir"));
            if (!localDirectory.canWrite()) {
                logger.finest("Delete: file is write protected");
            }

            if (!localDirectory.exists()) {
                logger.finest("Delete: file does not exist");
            }

            if (localDirectory.isDirectory()) {
                ExtensionFilter filter = new ExtensionFilter("gsm");
                String[] list = localDirectory.list(filter);
                for (int i = 0; i < list.length - 1; i++) {
                    File file = new File(localDirectory + "/" + list[i]);
                    if (file.exists()) {
                        file.delete();
                    } else {
                        logger.finest("Delete: file does not exist " + file.getName());
                    }
                }
            }
        }
    }
}
