/**
 *  $Id: ServicesConstants.java,v 1.5 2007/03/28 13:43:28 mohamed Exp $
 *
 *  Copyright (C) GNU/GPL AVOIR 2007
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.realtime.voice.audio;

/**
 * Interface holding the constant values for various service URL's.
 * 
 * @author adrian
 */
public interface ServicesConstants {

    /**
     * The path to the audio upload service.
     */
    public static final String SERVICE_AUDIO_UPLOAD = "HandleUpload.php";

    /**
     * The path to the most recent file locator service.
     */
    public static final String SERVICE_FILE_LOCATOR = "LatestAudioFile.php";

    /**
     * The path at which the uploaded audio is accessible at.
     */
    public static final String SERVER_AUDIO_PATH = "audio/";

    public static final String SUCCESS = "SUCCESS";

    public static final String FAILURE = "FAILURE";
    
    public static final String TRUE = "true";
    
    public static final String FALSE = "false";

}
