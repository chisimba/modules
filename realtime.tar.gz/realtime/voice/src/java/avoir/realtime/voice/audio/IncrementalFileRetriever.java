/**
 *  $Id: IncrementalFileRetriever.java,v 1.2 2007/04/05 13:35:57 mohamed Exp $
 *
 *  Copyright (C) GNU/GPL AVOIR 2007
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.realtime.voice.audio;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.Observable;
import java.util.logging.Level;
import java.util.logging.Logger;

import avoir.realtime.http.HttpRetriever;

/**
 * Object that retrieves files with "incremental" file names from an HTTP location.
 * 
 * @author adrian
 */
public class IncrementalFileRetriever extends Observable implements Runnable {

    private static Logger logger = Logger
            .getLogger(IncrementalFileRetriever.class.getName());

    /**
     * Default value for file name separator (i.e. to separate the prefix from
     * the counter value for a file).
     */
    public static final String DEFAULT_FILE_NAME_SEPARATOR = "_";

    /**
     * The default maximum number of attempts to try retrieve a file.
     */
    private static int DEFAULT_MAX_RETRY_ATTEMPTS = 10;

    /**
     * The default time to wait inbetween attempts to retrieve a file. 
     */
    public static final int DEFAULT_RETRY_WAIT_TIME = 5000;

    /**
     * The time to wait inbetween attempts to retrieve a file. 
     */
    private int retryWaitTime = DEFAULT_RETRY_WAIT_TIME;
    
    /**
     * The maximum number of attempts to try retrieve a file.
     */
    private int maxRetryAttempts = DEFAULT_MAX_RETRY_ATTEMPTS;

    /**
     * The number of attempts that have been made to retrieve a file.
     */
    private int attempts = 0;

    /**
     * The number of the current file to download.
     */
    private int fileNameCounter = -1;
    
    /**
     * The full HTTP address of where the files to be downloaded are located.
     */
    private String fileLocation;

    /**
     * The URL of the fileLocator service, used to determine the newest file on the 
     * server.
     */
    private URL fileLocator;

    /**
     * The local folder to download files to.
     */
    private File downloadFolder;

    /**
     * The separator in the file name between the prefix and file number.
     */
    private String fileNameSeparator = DEFAULT_FILE_NAME_SEPARATOR;

    /**
     * The file name prefix (i.e. the part before the separator and file number).
     */
    private String fileNamePrefix = null;

    /**
     * Variable to control the running of this as a thread.
     */
    private boolean running = true;

    /**
     * Constructs a new instance.
     * 
     * @param downloadFolder The folder to download files to.
     * @param fileLocation The remote http folder containing the files to download.
     * @param fileLocator The URL of the file locator service.
     */
    public IncrementalFileRetriever(File downloadFolder, String fileLocation,
            URL fileLocator) {
        this.downloadFolder = downloadFolder;
        this.fileLocation = fileLocation;
        this.fileLocator = fileLocator;
    }

    /**
     * Gets the URL of the next file to download. The first time this is called it 
     * will use the file locator service to get the most recent file name. On 
     * subsequent calls it will return the next file, according to the file numbering 
     * system.
     * 
     * @return The URL of the next file to try download.
     * @throws IOException If the most recent file (on the first call) does not conform 
     * to the file naming convention and thus the file number cannot be determined.
     */
    private URL getNextFileURL() throws IOException {
        if (fileNamePrefix == null) { //first time we are trying to get a url
            String latestFile = HttpRetriever.getText(fileLocator);
            int separatorIndex = latestFile.indexOf(fileNameSeparator);
            int extensionIndex = latestFile.indexOf(".");
            if (separatorIndex <= 0 || extensionIndex <= 0) {
                throw new IOException(
                        "Could not determine latest file, received '"
                                + latestFile + "'");
            }
            fileNamePrefix = latestFile.substring(0, separatorIndex);
            fileNameCounter = Integer.parseInt(latestFile.substring(
                    separatorIndex + 1, extensionIndex));
        }
        return new URL(fileLocation + fileNamePrefix + fileNameSeparator
                + (fileNameCounter++) + ".gsm");
    }

    /**
     * Stops this object when running as a Thread.
     */
    public void stop() {
        this.running = false;
    }

    /**
     * Implementation of Runnable interface method.
     */
    public void run() {
        while (running) {
            while (attempts <= maxRetryAttempts && running) {
                try {
                    URL nextFileURL = getNextFileURL();
                    File temp = new File(nextFileURL.toString());
                    File downloadedFile = new File(downloadFolder, temp
                            .getName());
                    HttpRetriever
                            .downloadFile(nextFileURL, downloadedFile);

                    this.setChanged();
                    notifyObservers(downloadedFile);
                    attempts = 0; //successfully got a file, reset attempts for next one
                } catch (IOException e) {
                    logger.log(Level.WARNING, "Error retrieving file " + e.getMessage());
                    attempts++;
                    fileNameCounter--;
                    try { //wait a while before trying again
                        Thread.sleep(retryWaitTime);
                    } catch (InterruptedException e2) {
                        logger.log(Level.WARNING, "Sleep interrupted", e2);
                    }
                }
            }
            //TODO: if attempts > maxRetryAttempts we should probably stop this thread
        }
        logger.finest("Finished retrieving files");
    }
}
