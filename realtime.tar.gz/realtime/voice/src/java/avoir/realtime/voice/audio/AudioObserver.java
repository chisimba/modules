package avoir.realtime.voice.audio;

/**
 * Interface for objects interested in receiving state change notifications from 
 * an audio player or capturer. 
 * 
 * @author adrian
 */
public interface AudioObserver {

    /**
     * Called when there has been a change in status.
     * 
     * @param newStatus New status message.
     */
    public void updateStatus(String newStatus);
    
    /**
     * Called when observed object is finished playing.
     */
    public void playingComplete();

    /**
     * Called when observed object is finished capturing.
     */
    public void captureComplete();
    
    
    
}
