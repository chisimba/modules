/**
 *  $Id: IncrementalAudioPlayer.java,v 1.13 2007/04/05 13:35:57 mohamed Exp $
 *
 *  Copyright (C) GNU/GPL AVOIR 2007
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.realtime.voice.audio;

import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Observable;
import java.util.Observer;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.media.AudioDeviceUnavailableEvent;
import javax.media.ControllerErrorEvent;
import javax.media.ControllerEvent;
import javax.media.ControllerListener;
import javax.media.EndOfMediaEvent;
import javax.media.GainControl;
import javax.media.Manager;
import javax.media.Player;
import javax.media.StartEvent;

/**
 * Audio Player that plays audio uploaded by IncrementalAudioCapturer by downloading 
 * the audio files from an HTTP server and then using the JMF to play them. 
 * 
 * @author adrian
 */
public class IncrementalAudioPlayer implements ControllerListener, Observer {

    private static Logger logger = Logger
            .getLogger(IncrementalAudioPlayer.class.getName());

    /**
     * The default gain value.
     */
    public static final float DEFAULT_GAIN = 1.0f;

    /**
     * The default maximum number of attempts to try retrieve audio to play.
     */
    public static final int DEFAULT_MAX_RETRY_ATTEMPTS = 5;

    /**
     * The default time to wait inbetween attempts to retrieve audio to play. 
     */
    public static final int DEFAULT_RETRY_WAIT_TIME = 5000;

    /**
     * The maximum number of attempts to try retrieve audio to play.
     */
    private int maxRetryAttempts = DEFAULT_MAX_RETRY_ATTEMPTS;

    /**
     * The time to wait inbetween attempts to retrieve audio to play. 
     */
    private int retryWaitTime = DEFAULT_RETRY_WAIT_TIME;

    /**
     * The number of attempts that have been made to retrieve audio to play.
     */
    private int attempts = 0;

    /**
     * Observer object that will be notified of state changes.
     */
    private AudioObserver observer;

    /**
     * The current gain value.
     */
    private float gain = DEFAULT_GAIN;

    /**
     * The player currently playing audio.
     */
    private Player currentPlayer = null;

    /**
     * File retriever object;
     */
    private IncrementalFileRetriever retriever;

    /**
     * FileRetriever thread.
     */
    private Thread retrieverThread = null;

    /**
     * List of Player objects which are realized and ready to play. 
     */
    private List<Player> players = Collections
            .synchronizedList(new ArrayList<Player>());

    /**
     * Keeps track of whether this player is in the process of retrieving and/or 
     * playing audio.
     */
    private boolean playing = false;

    /**
     * Creates a new instance of this class, to play audio from the passed location 
     * and to send status changes to the passed observer.The other passed strings 
     * are used as the file name prefix and file name separator.
     *
     * @param destinationFolder Local folder where audio will be downloaded to while playing
     * @param audioLocation Location containing audio to be played.
     * @param fileLocator HTTP URL of audio file locator service.
     * @param observer Observer object interested in status changes. 
     */
    public IncrementalAudioPlayer(File destinationFolder, String audioLocation,
            URL fileLocator, AudioObserver observer) {
        this.retriever = new IncrementalFileRetriever(destinationFolder,
                audioLocation, fileLocator);
        retriever.addObserver(this); //inform retriever that we want to be notified when files are downloaded
        this.observer = observer; //observer that we will notify of playing changes 
    }

    /**
     * Stop retrieving and playing audio.
     */
    public void stopPlaying() {
        logger.finest("Stopping retrieving files and playing");
        observer.playingComplete();
        this.playing = false;
        retriever.stop();
        retrieverThread = null;
        stopPlayer(currentPlayer);
        currentPlayer = null;
        stopWaitingPlayers();
        attempts = 0;
    }

    /**
     * Stops removes any players held in list waiting to be used.
     */
    private void stopWaitingPlayers() {
        for (Player player : players) {
            stopPlayer(player);
        }
        players.clear();
    }

    /**
     * Stops a player.
     * 
     * @param player The player to stop.
     */
    private void stopPlayer(Player player) {
        observer.updateStatus("Stopping player " + player);
        if (player != null) {
            player.stop();
            player.deallocate();
            player.close();
            player = null;
        }
    }

    /**
     * Starts this Player retrieving audio and playing it back as it is received.
     */
    public void startPlaying() {
        this.playing = true;
        if (retrieverThread == null) { //start retrieving files, will be called back when they are ready
            retrieverThread = new Thread(retriever);
            retrieverThread.start();
        }
    }

    /**
     * ControllerListener implementation, called by JMF player objects.
     * 
     * @param event Event which occurred in player.
     */
    public void controllerUpdate(ControllerEvent event) {
        if (playing) { //we only care about events if we are in playing state.
            if (event instanceof EndOfMediaEvent) {
                handleEndOfMedia();
            } else if (event instanceof StartEvent) {
                //TODO: need some way of displaying current file being played
                //if we can't get this from player then we need to store
                //players in a sorted map against their file name
                //logger.finest("XXXX: " + ((StartEvent)event).getSource());
            } else if (event instanceof ControllerErrorEvent) {
                handleError(new RuntimeException("Controller error: "
                        + event.toString()));
            } else if (event instanceof AudioDeviceUnavailableEvent) {
                handleError(new RuntimeException("Audio device unavailable: "
                        + event.toString()));
            }
        }
    }

    /**
     * Handles what to do when an audio file is finished playing by finding the next 
     * available piece of audio and playing it.
     */
    private void handleEndOfMedia() {
        attempts = 0;
        //TODO: should delete file when done (either mark it for delete in update() method
        // or work out file name here and remove it....
        while (players.size() <= 0 && attempts < maxRetryAttempts) {
            observer.updateStatus("No players to play next audio, waiting... "
                    + attempts);
            try {
                Thread.sleep(retryWaitTime);
                attempts++;
            } catch (InterruptedException e) {
                logger.log(Level.WARNING, "Interrupted while waiting", e);
            }
        }
        if (attempts >= maxRetryAttempts) {
            handleError(new RuntimeException(
                    "Could not find any audio to play after " + attempts
                            + " attempts"));
        } else { //we have a player in list ready to play
            logger.finest("Found " + players.size()
                    + " available players, starting first one");
            Player nextPlayer = players.remove(0);
            nextPlayer.start();
            currentPlayer = nextPlayer;
        }
    }

    /**
     * If not already playing a File, starts playing the passed File, else creates a Player for this File and 
     * adds it to players list so Player can be started later when currently playing File is finished.
     * 
     * @param fileToPlay The file to play.
     */
    private void playFile(File fileToPlay) {
        logger.finest("Asked to play " + fileToPlay.getAbsolutePath());
        try {
            Player player = Manager.createRealizedPlayer(fileToPlay.toURL());
            player.addControllerListener(this);
            setPlayerGain(player);
            if (currentPlayer == null) { //not currently playing anything, can start right away
                player.start();
                currentPlayer = player;
                observer
                        .updateStatus("Playing " + fileToPlay.getAbsolutePath());
            } else { //playing something already, add to list for later use
                logger.finest("Adding player for "
                        + fileToPlay.getAbsolutePath() + " to list");
                players.add(player);
            }
        } catch (Exception e) {
            handleError(e);
        }
    }

    /**
     * Handles an unrecoverable error occurring in the player, logs the error and 
     * stops playing.
     * 
     * @param e The exception that occurred.
     */
    private void handleError(Exception e) {
        logger.log(Level.SEVERE, "Error creating player", e);
        observer.updateStatus("Error playing file: " + e.getMessage());
        stopPlaying();
    }

    /**
     * Observer interface implementation. Called by Observable object being observed -  in this case the 
     * IncrementalFileRetriever when a file has been downloaded. 
     * 
     * @param observable Object being observed.
     * @param result Object passed to notifyObservers() method.
     */
    public void update(Observable observable, Object result) {
        //this method is only called when a new file has been downloaded, so we try play it
        playFile((File) result);
    }

    /**
     * Set the value for gain to be used by this player. Maximum value is 1.0 and 
     * minimum is 0.0 (equivalent to mute).
     * 
     * @param newGain New value for gain.
     */
    public void setGain(float newGain) {
        this.gain = newGain;
    }

    /**
     * Sets the gain value on the passed JMF player to the value set in this
     * object. 
     * 
     * @param player Player to set to gain on. 
     */
    private void setPlayerGain(Player player) {
        if (player != null) {
            GainControl control = player.getGainControl();
            control.setLevel(this.gain);
            logger.finest("Set gain on player to: " + control.getLevel());
        }
    }

}
