/**
 *  $Id: UserListModel.java,v 1.1 2007/04/02 15:40:23 adrian Exp $
 * 
 *  Copyright (C) GNU/GPL AVOIR 2007
 * 
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

package avoir.realtime;

import java.util.List;

import javax.swing.AbstractListModel;

import avoir.realtime.User;

/**
 * ListModel to represent a list of Users.
 *  
 * @author adrian
 */
public class UserListModel extends AbstractListModel {

    private static final long serialVersionUID = -7049870874981387275L;
    
    /**
     * List of Users being modeled.
     */
    private List users;
    
    /**
     * Constructs a new ListModel to model the passed List of Users.
     * 
     * @param list List of Users to model.
     */
    public UserListModel(List<User> list){
       this.users =  list; 
    }

    /**
     * Returns the User at the specified index.
     * 
     * @param index Index of object to retrieve.
     * @return The object at the specified index.
     */
    public Object getElementAt(int index) {
        return users.get(index);
    }

    /**
     * Gets the size of the User list.
     * 
     * @return The size of the User list.
     */
    public int getSize() {
        return users.size();
    }

    /**
     * Gets the User list being modelled.
     *  
     * @return The User list.
     */
    public List getUserList() {
        return this.users;
    }

}
