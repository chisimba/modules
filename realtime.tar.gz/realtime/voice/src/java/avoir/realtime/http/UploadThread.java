/**
 *  $Id: UploadThread.java,v 1.1 2007/02/27 15:50:56 adrian Exp $
 *   
 *  Original code from JUpload project at http://jupload.sourceforge.net/   
 *  Modified to upload only one file.
 * 
 *  Copyright (C) GNU/GPL AVOIR 2007
 * 
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.realtime.http;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Thread that uploads a file via an HTTP post.. 
 */
public class UploadThread extends Thread {

    private static Logger logger = Logger.getLogger(UploadThread.class
	    .getName());

    /**
     * The output received from the server while performing the upload.
     */
    private StringBuffer serverOutput = new StringBuffer();

    /**
     * Will be set if an error occurs during the upload, otherwise will remain null.
     */
    private Exception exception = null;

    /**
     * The URL to upload to (should point to a correctly configured file upload service).
     */
    private String uploadURL = null;

    /**
     * The file to upload.
     */
    private File sourceFile = null;

    /**
     * Constructs a new instance which, when run, will upload the passed the file to the 
     * passed URL.
     * 
     * @param sourceFile The file to upload.
     * @param destinationUploadURL The full URL string of the upload service.
     */
    public UploadThread(File sourceFile, String destinationUploadURL) {
	this.uploadURL = destinationUploadURL;
	this.sourceFile = sourceFile;
    }

    public StringBuffer getServerOutput() {
	return serverOutput;
    }

    public Exception getException() {
	return exception;
    }

    private StringBuffer getRandomString() {
	StringBuffer randomBuffer = new StringBuffer(11);
	StringBuffer alphaNum = new StringBuffer();
	alphaNum.append("1234567890abcdefghijklmnopqrstuvwxyz");
	int num;
	for (int i = 0; i < 11; i++) {
	    num = (int) (Math.random() * (alphaNum.length() - 1));
	    randomBuffer.append(alphaNum.charAt(num));
	}
	return randomBuffer;
    }

    private void uploadFileStream(File file, DataOutputStream dataOut)
	    throws FileNotFoundException, IOException {
	byte[] byteBuff = null;
	FileInputStream fileInput = null;
	try {
	    int numBytes = 0;
	    byteBuff = new byte[1024];
	    fileInput = new FileInputStream(file);
	    while (-1 != (numBytes = fileInput.read(byteBuff))) {
		dataOut.write(byteBuff, 0, numBytes);
	    }
	} finally {
	    try {
		fileInput.close();
	    } catch (IOException e) {
		logger.log(Level.WARNING, "Error closing input stream", e);
	    }
	    byteBuff = null;
	}
    }

    /**
     * Appends the passed string to the ServerOutput buffer.
     * 
     * @param extraOutput String to be appended to the buffer.
     */
    private void appendServerOutput(String extraOutput) {
	if (0 < serverOutput.length() || !extraOutput.equals("")) {
	    serverOutput.append(extraOutput);
	}
    }

    /**
     * Creates the HTTP file header for the passed file and boundary.
     * 
     * @param file The file to be uploaded.
     * @param boundary The boundary string.
     * @return The HTTP header.
     */
    private StringBuffer createFileHeader(File file, StringBuffer boundary) {
	StringBuffer header = new StringBuffer();
	// Line 1.
	header.append(boundary.toString());
	header.append("\r\n");
	// Line 2.
	header.append("Content-Disposition: form-data; name=\"File");
	//sb.append(i);
	header.append("\"; filename=\"");
	header.append(file.toString());
	header.append("\"");
	header.append("\r\n");
	// Line 3 & Empty Line 4.
	header.append("Content-Type: application/octet-stream");
	header.append("\r\n");
	header.append("\r\n");
	return header;
    }

    /**
     * Creates the HTTP file trailer.
     * 
     * @param boundary The boundary string.
     * @return The HTTP trailer.
     */
    private StringBuffer createFileTrailer(StringBuffer boundary) {
	StringBuffer tail = new StringBuffer("\r\n");
	// Telling the Server we have Finished.
	tail.append(boundary.toString());
	tail.append("--\r\n");
	return tail;
    }

    //------------- THE HEART OF THE PROGRAME ------------------------------

    /**
     * Thread's run method which performs the actual file upload.
     */
    public void run() {
	File fileToUpload = sourceFile;
	long totalFilesLength = fileToUpload.length();
	Socket socket = null;
	DataOutputStream dataOut = null;
	BufferedReader dataIn = null;
	try {
	    URL url = new URL(uploadURL);
	    logger.fine("Uploading " + sourceFile.getAbsolutePath() + " to "
		    + uploadURL);

	    StringBuffer boundary = new StringBuffer();
	    boundary.append("-----------------------------");
	    boundary.append(getRandomString().toString());

	    long contentLength = totalFilesLength;
	    StringBuffer fileHeader = createFileHeader(fileToUpload, boundary);
	    StringBuffer fileTrailer = createFileTrailer(boundary);
	    contentLength += fileHeader.length();
	    contentLength += fileTrailer.length();
	    StringBuffer header = new StringBuffer();
	    // Line 1. Header: Request line
	    header.append("POST ");
	    header.append(url.getPath());
	    header.append(" HTTP/1.0\r\n");
	    // Header: General
	    //header.append("Host: ");
	    //header.append(url.getHost());
	    //header.append("\r\n");

	    // Line 2. Header: Entity
	    header.append("Content-type: multipart/form-data; boundary=");
	    header.append(boundary.substring(2, boundary.length()) + "\r\n");
	    // Line 3.
	    header.append("Content-length: ");
	    header.append(contentLength);
	    header.append("\r\n");
	    // Line 4. Blank line
	    header.append("\r\n");
	    // If port not specified then use default http port 80.
	    socket = new Socket(url.getHost(), (-1 == url.getPort()) ? 80 : url
		    .getPort());
	    dataOut = new DataOutputStream(new BufferedOutputStream(socket
		    .getOutputStream()));
	    dataIn = new BufferedReader(new InputStreamReader(socket
		    .getInputStream()));

	    // Send http request to server
	    dataOut.writeBytes(header.toString());
	    // Write to Server the head(4 Lines), a File and the tail.
	    dataOut.writeBytes(fileHeader.toString());
	    uploadFileStream(fileToUpload, dataOut);
	    dataOut.writeBytes(fileTrailer.toString());
	    dataOut.flush();
	    String line;
	    while ((line = dataIn.readLine()) != null) {
		//TODO: need to read first line back and see if this is ok, otherwise error
		this.appendServerOutput(line + "\n");
	    }
	    logger.finest("Server response:" + serverOutput.toString());
	} catch (Exception e) {
	    logger.log(Level.SEVERE, "Error during upload", e);
	    this.exception = e;
	} finally {
	    try {
		if (dataOut != null) {
		    dataOut.close();
		}
	    } catch (IOException e) {
		logger.log(Level.WARNING, "Error closing output stream", e);
	    }
	    dataOut = null;
	    try {
		if (dataIn != null) {
		    dataIn.close();
		}
	    } catch (Exception e) {
		logger.log(Level.WARNING, "Error closing input stream", e);
	    }
	    dataIn = null;
	    try {
		if (socket != null) {
		    socket.close();
		}
	    } catch (Exception e) {
		logger.log(Level.WARNING, "Error closing socket", e);
	    }
	    socket = null;
	    //sourceFile.delete();
	}
    }

    //------------- CLEAN UP -----------------------------------------------
    public void close() {
	exception = null;
	serverOutput = null;
    }
}
