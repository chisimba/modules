/**
 *   $Id: AudioCapture.java,v 1.1 2007/03/20 14:37:07 adrian Exp $
 * 
 *  Copyright (C) GNU/GPL AVOIR 2007
 * 
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.realtime.javasound;

import java.io.IOException;
import java.io.InputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineEvent;
import javax.sound.sampled.LineListener;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.TargetDataLine;

/**
 * Class that captures audio from the soundcard.
 */
public class AudioCapture implements LineListener {

    private static Logger logger = Logger.getLogger(AudioCapture.class
	    .getName());

    private AudioInputStream audioInputStream;

    private AudioFormat audioFormat;

    private long startTime;

    private int bufferSize;

    private TargetDataLine targetDataLine;

    /**
     * Constructs a new AudioCapture object to capture audio using the passed 
     * format, using the passed buffer size.
     * 
     * @param format Format of audio to capture.
     * @param bufferSize Size of recording buffer to use.
     */
    public AudioCapture(AudioFormat format, int bufferSize) {
	this.audioFormat = format;
	this.bufferSize = bufferSize;
    }

    /**
     * Constructs a new AudioCapture object to capture audio using the passed 
     * format, using the format's sample rate as the recording buffer size.
     * 
     * @param format Format of audio to capture.
     */
    public AudioCapture(AudioFormat format) {
	this(format, (int) format.getSampleRate());
	// 500ms (8000)
    }

    /**
     * LineListener method to react to line events.
     * 
     * @event LineEvent which occurred.
     */
    public void update(LineEvent event) {
	if (logger.isLoggable(Level.FINE)) {
	    if (event.getType().equals(LineEvent.Type.STOP)) {
		logger.fine("Record: Stop");
	    } else if (event.getType().equals(LineEvent.Type.START)) {
		logger.fine("Record: Start");
	    } else if (event.getType().equals(LineEvent.Type.OPEN)) {
		logger.fine("Record: Open");
	    } else if (event.getType().equals(LineEvent.Type.CLOSE)) {
		logger.fine("Record: Close");
	    }
	}
	if (event.getType().equals(LineEvent.Type.START)) {
	    startTime = System.currentTimeMillis();
	} else if (event.getType().equals(LineEvent.Type.STOP)
		|| event.getType().equals(LineEvent.Type.CLOSE)) {
	    startTime = 0;
	}
    }

    /**
     * Opens the sound hardware.
     * 
     * @throws LineUnavailableException If the line could not be obtained. 
     */
    public void open() throws LineUnavailableException {
	DataLine.Info info = new DataLine.Info(TargetDataLine.class,
		audioFormat);

	// get and open the target data line for capture.
	targetDataLine = (TargetDataLine) AudioSystem.getLine(info);
	targetDataLine.addLineListener(this);
	logger.fine("Got TargetDataLine " + targetDataLine.getClass());

	targetDataLine.open(audioFormat, bufferSize);
	logger.fine("Recording buffersize=" + targetDataLine.getBufferSize()
		+ " bytes.");

	audioInputStream = new AudioInputStream(new TargetDataLineIS(
		targetDataLine), targetDataLine.getFormat(),
		AudioSystem.NOT_SPECIFIED);
    }

    /**
     * Retrieves the audio input stream being used by this AudioCapture object.
     * 
     * @return The audio input stream.
     */
    public AudioInputStream getAudioInputStream() {
	return audioInputStream;
    }

    /**
     * Starts the audio capture. 
     */
    public void start() {
	targetDataLine.flush();
	targetDataLine.start();
    }

    /**
     * Closes the resources used. 
     */
    public void close() {
	if (audioInputStream != null) {
	    logger.fine("AudioCapture.close(): begin");
	}
	try {
	    audioInputStream.close();
	    // hmmm... the next lines cause a deadlock...
	    // but the above doesn't close the line !
	    // if (m_line!=null) {
	    // m_line.close();
	    // }
	} catch (IOException e) {
	    logger.log(Level.WARNING, "Error closing stream", e);
	}
	logger.fine("AudioCapture.close(): end");
    }

    /**
     * Gets how long this object has been capturing audio for.
     * 
     * @return How much audio has been capture (in milliseconds).
     */
    public long getTime() {
	if (startTime != 0) {
	    return System.currentTimeMillis() - startTime;
	} else {
	    return -1;
	}
    }

    // ////////////////////////////////////////////////////////////////////

    // Bug: the implementation of "new AudioInputStream(TargetDataLine)"
    // does
    // not forward close() to the line !
    // so this is a blunt copy of Sun's implementation !
    private class TargetDataLineIS extends InputStream {
	TargetDataLine line;

	TargetDataLineIS(TargetDataLine line) {
	    super();
	    this.line = line;
	}

	public int available() throws IOException {
	    return line.available();
	}

	public int read() throws IOException {
	    byte[] b = new byte[1];

	    int value = read(b, 0, 1);

	    if (value == -1) {
		return -1;
	    }
	    return (int) b[0];
	}

	public int read(byte[] b, int off, int len) throws IOException {
	    try {
		return line.read(b, off, len);
	    } catch (IllegalArgumentException e) {
		throw new IOException(e.getMessage());
	    }
	}

	public void close() throws IOException {
	    // SunBug: strangely enough, the line needs to be flushed and
	    // stopped to avoid a dead lock...
	    if (line.isActive()) {
		line.flush();
		line.stop();
	    }
	    line.close();
	}
    } // TargetDataLineIS

}
