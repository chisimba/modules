/**
 *  $Id: AudioPlayer.java,v 1.1 2007/03/20 14:37:07 adrian Exp $
 *
 *  Copyright (C) GNU/GPL AVOIR 2007
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.realtime.javasound;

import java.io.IOException;
import java.io.InputStream;
import java.util.logging.Logger;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.SourceDataLine;

/**
 * Class to play audio.
 */
public class AudioPlayer implements Runnable {

    private static Logger logger = Logger
	    .getLogger(AudioPlayer.class.getName());

    private AudioFormat audioFormat;

    private AudioInputStream audioInput;

    private boolean running = true;

    private SourceDataLine sourceLine;

    /**
     * Constructs a new AudioPlayer which will play audio in the passed
     * format from the passed InputStream.
     * 
     * @param audioFormat
     *                The format of the audio to play.
     * @param input
     *                The inputstream containing the audio.
     */
    public AudioPlayer(AudioFormat audioFormat, InputStream input) {
	this.audioFormat = audioFormat;
	this.audioInput = new AudioInputStream(input, audioFormat,
		AudioSystem.NOT_SPECIFIED);
    }

    /**
     * Opens the sound hardware and starts playing the audio in its own
     * Thread.
     * 
     * @throws LineUnavailableException
     *                 If the line could not be obtained.
     */
    public void start() throws LineUnavailableException {
	DataLine.Info info = new DataLine.Info(SourceDataLine.class,
		audioFormat);
	if (!AudioSystem.isLineSupported(info)) {
	    throw new LineUnavailableException("Line not supported " + info);
	}
	// Obtain and open the line.
	sourceLine = (SourceDataLine) AudioSystem.getLine(info);

	sourceLine.open(audioFormat);
	sourceLine.start();

	Thread thread = new Thread(this);
	thread.start();
    }

    /**
     * Called indirectly by start() (i.e. do NOT call this method directly).
     */
    public void run() {
	running = true;
	try {
	    while (running && audioInput.available() > 0) {
		// TODO: make buffer size configurable instead of reading
		// everything into memory
		byte[] audioBuffer = new byte[audioInput.available()];
		int numBytesRead = audioInput.read(audioBuffer, 0,
			audioBuffer.length);
		// if (numBytesRead == -1) break;
		logger.fine("Wrote bytes " + numBytesRead);
		sourceLine.write(audioBuffer, 0, numBytesRead);
	    }
	} catch (IOException e) {
	    throw new RuntimeException(e);
	} finally {
	    logger.fine("Stopping player");
	    sourceLine.drain();
	    sourceLine.stop();
	    sourceLine.close();
	}
    }

    /**
     * Stops player from playing.
     */
    public void stop() {
	this.running = false;
    }

}
