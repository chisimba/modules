/**
 *  $Id: JMFInstallerApplet.java,v 1.2 2007/03/28 10:34:12 adrian Exp $
 *
 *  Copyright (C) GNU/GPL AVOIR 2007
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.realtime;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import avoir.realtime.applet.RealtimeApplet;
import avoir.realtime.http.HttpRetriever;
import avoir.util.AppletUtils;

/**
 * Applet which installs the JMF on the client machine. Assumes the client has 
 * write rights to the JRE on their local machine. Currently only supports Linux.
 * 
 * @author adrian
 */
public class JMFInstallerApplet extends RealtimeApplet implements ActionListener,
        ItemListener {

    private static final long serialVersionUID = -2187873944270329672L;

    private static Logger logger = Logger.getLogger(JMFInstallerApplet.class
            .getName());

    /**
     * Action command for install.
     */
    private static final String COMMAND_INSTALL = "install";

    /**
     * Install button.
     */
    private JButton installButton = new JButton("Install");

    /**
     * Applet parameter for setting the HTTP location where the JMF can be downloaded from.
     */
    private static final String PARAM_DOWNLOAD_LOCATION = "downloadLocation";

    /**
     * The HTTP location where the JMF can be downloaded from. 
     */
    private String downloadLocation = null;

    /**
     * The JAVA_HOME folder on the user's computer.
     */
    private File javaHome = null;

    /**
     * Field for status messages.
     */
    private JTextField status = new JTextField();

    /**
     * The URL containing the JMF license.
     */
    private URL licenseURL;

    /**
     * Applet init method.
     */
    public void init() {
        super.init();
        downloadLocation = AppletUtils.getRequiredParameter(this,
                PARAM_DOWNLOAD_LOCATION);
        if (!downloadLocation.endsWith("/")) {
            downloadLocation += "/";
        }
        javaHome = new File(System.getProperty("java.home"));

        //TODO: for testing only, if you want files copied to some other location
        //javaHome = new File("/tmp/javahome/jre/");
        logger.info("Java home is: " + javaHome.getAbsolutePath());

        if (!javaHome.exists() || !javaHome.isDirectory()) {
            throw new RuntimeException(javaHome.getAbsolutePath()
                    + " does not exist");
        }

        try {
            licenseURL = new URL(downloadLocation
                    + "doc/readme.html#AGREEMENT");
        } catch (MalformedURLException e) {
            logger.log(Level.SEVERE, "Error creating license URL", e);
        }

        try {
            SwingUtilities.invokeAndWait(new Runnable() {
                public void run() {
                    buildUI();
                }
            });
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error creating GUI", e);
        }
    }

    /**
     * Builds the user interface for this applet.
     */
    private void buildUI() {
        this.setLayout(new GridLayout(0, 1));

        JPanel selectPanel = new JPanel();
        selectPanel.setBackground(backgroundColor);
        selectPanel.add(new JLabel("Select operating system:"));
        JRadioButton linuxButton = new JRadioButton("Linux");
        linuxButton.setBackground(backgroundColor);
        linuxButton.setSelected(true);
        ButtonGroup osGroup = new ButtonGroup();
        osGroup.add(linuxButton);
        selectPanel.add(linuxButton);
        add(selectPanel);

        JPanel licensePanel = new JPanel();
        licensePanel.setBackground(backgroundColor);
        JCheckBox licenseBox = new JCheckBox();
        licenseBox.setBackground(backgroundColor);
        licenseBox.addItemListener(this);
        licensePanel.add(licenseBox);
        JLabel licenseLabel = new JLabel("<html>I agree to the <a href=\""
                + licenseURL.toExternalForm()
                + "\">terms and conditions</a></html>");

        licenseLabel.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                getAppletContext().showDocument(licenseURL, "_blank");
            }
        });

        licensePanel.add(licenseLabel);
        add(licensePanel);

        JPanel installPanel = new JPanel();
        installPanel.setBackground(backgroundColor);
        installButton.setActionCommand(COMMAND_INSTALL);
        installButton.addActionListener(this);
        installButton.setEnabled(false);
        installPanel.add(installButton);
        add(installPanel);

        JPanel statusPanel = new JPanel();
        statusPanel.setBackground(backgroundColor);
        status.setBackground(backgroundColor);
        status.setEditable(false);
        status.setPreferredSize(new Dimension(this.getWidth(), 15));
        statusPanel.add(status);
        add(statusPanel);
    }

    /**
     * ActionListener implementation for the install button.
     * 
     * @param event The ActionEvent.
     */
    public void actionPerformed(ActionEvent event) {
        String command = event.getActionCommand();
        if (COMMAND_INSTALL.equals(command)) {
            install();
        }
    }

    /**
     * Downloads the JMF libraries and installs them under the JRE being used 
     * by the browser.
     */
    private void install() {
        status.setText("Installing files...");

        File endorsedFolder = new File(javaHome, "lib/endorsed");
        endorsedFolder.mkdir();
        try {
            URL fileURL = new URL(downloadLocation + "lib/" + "jmf.jar");
            HttpRetriever.downloadFileToFolder(fileURL, endorsedFolder);

            String[] filesToDownload = new String[] { "jmf.properties",
                    "jmf.properties.orig", "libjmcvid.so", "libjmdaud.so",
                    "libjmfjawt.so", "libjmg723.so", "libjmgsm.so",
                    "libjmh261.so", "libjmh263enc.so", "libjmjpeg.so",
                    "libjmmpa.so", "libjmmpegv.so", "libjmmpx.so",
                    "libjmutil.so", "libjmv4l.so", "libjmxlib.so",
                    "mediaplayer.jar", "multiplayer.jar" };
            File nativeLibFolder = new File(javaHome, "lib/i386");

            for (String fileName : filesToDownload) {
                fileURL = new URL(downloadLocation + "lib/" + fileName);
                HttpRetriever.downloadFileToFolder(fileURL, nativeLibFolder);
                status.setText("Installing " + fileURL);
            }
            status.setText("Install complete");
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Install error", e);
            status.setText("Install error: " + e.getMessage());
        }
    }

    /**
     * Itemlistener implementation. Reacts to the checkbox for the license terms 
     * being checked/unchecked.
     * 
     * @param event The ItemEvent.
     */
    public void itemStateChanged(ItemEvent event) {
        if (event.getStateChange() == ItemEvent.SELECTED) {
            installButton.setEnabled(true);
        } else {
            installButton.setEnabled(false);
        }
    }

}
