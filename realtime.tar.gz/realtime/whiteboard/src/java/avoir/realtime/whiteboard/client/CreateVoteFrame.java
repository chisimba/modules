/**
 * 	$Id: CreateVoteFrame.java,v 1.2 2007/01/15 09:57:49 adrian Exp $
 * 
 *  Copyright (C) GNU/GPL AVOIR 2007
 *  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.realtime.whiteboard.client;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.GridLayout;

/**
 * Class that creates the interface for creating a new poll
 */
@SuppressWarnings("serial")
public class CreateVoteFrame extends JPanel {
    private JLabel labelTitle,labelQuestion,labelSeconds;
    private JTextField textQuestion,textSeconds;
    private JButton buttonSubmit;
    private JLabel labelOptions;
    private JTextField textOptions;
    
    /**
     * Constructor
     */
    public CreateVoteFrame() {
        
        labelTitle = new JLabel("Create Vote: ");
        labelQuestion = new JLabel("Question: ");
        labelSeconds = new JLabel("Seconds: ");
        labelOptions = new JLabel("Options: ");
        textQuestion = new JTextField("");
        textSeconds = new JTextField("60");
        textOptions = new JTextField("");
        buttonSubmit = new JButton("Submit");
        
        this.setLayout(new GridLayout(5,2));
        this.add(labelTitle);
        this.add(new JLabel());
        this.add(labelQuestion);
        this.add(textQuestion);
        this.add(labelOptions);
        this.add(textOptions);
        this.add(labelSeconds);
        this.add(textSeconds);
        this.add(buttonSubmit);
    }
    
    /**
     * Returns a String representing the choices that appear before a voter in a poll
     * @return String options
     */
    public String getOptions() {
        return textOptions.getText();
    }
    
    /**
     * Returns the question asked in this poll
     * @return String question
     */
    public String getQuestion() {
        return textQuestion.getText();
    }
    
    /**
     * Returns the length of time that the users have to vote
     * @return int seconds remaining to vote
     */
    public Integer getSeconds() {
        return Integer.parseInt(textSeconds.getText());
    }
    
    /**
     * Returns the button used to submit information about the new poll
     * @return JButton submit button
     */
    public JButton getButton() {
        return buttonSubmit;
    }
}
