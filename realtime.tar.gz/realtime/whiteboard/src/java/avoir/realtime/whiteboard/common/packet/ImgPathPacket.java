package avoir.realtime.whiteboard.common.packet;

public class ImgPathPacket implements WBPacket {
    private String path;

    public ImgPathPacket(String path) {
        this.path = path;
    }

    public String getImagePath() {
        return path;
    }
}
