/**
 * 	$Id: CellRenderer.java,v 1.2 2007/01/15 09:57:49 adrian Exp $
 * 
 *  Copyright (C) GNU/GPL AVOIR 2007
 * 
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.realtime.whiteboard.client;

import java.awt.Color;
import java.awt.Component;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.ListCellRenderer;

/**
 * Class that allows the cells in a JList to be formatted with color
 */
@SuppressWarnings("serial")
public class CellRenderer extends JLabel implements ListCellRenderer {
    
    /**
     * Constructor
     */
    public CellRenderer() {
        setOpaque(true);
    }
    
    /**
     * Abstract method must be overridden
     * @param jlist The JList that this CellRenderer renders
     * @param jlItem The value returned by list.getModel().getElementAt(index).
     * @param index cell index
     * @param isSelected true if the specified cell is selected
     * @param focus true if the specified cell holds focus
     * @return Component
     */
    public Component getListCellRendererComponent(JList jlist, Object jlItem, int index, boolean isSelected, boolean focus) {
        setText(((JListItem) jlItem).getValue());
        setBackground(((JListItem) jlItem).getColor());
        if(isSelected) {
            setBorder(BorderFactory.createLineBorder(Color.blue,2));
        } else {
            setBorder(BorderFactory.createLineBorder(jlist.getBackground(), 2));
        }
        return this;
    }
}
