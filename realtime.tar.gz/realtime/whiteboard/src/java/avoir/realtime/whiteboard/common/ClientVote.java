/**
 * 	$Id: ClientVote.java,v 1.2 2007/01/15 10:01:56 adrian Exp $
 * 
 *  Copyright (C) GNU/GPL AVOIR 2007
 * 
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.realtime.whiteboard.common;

/**
 * Class that keeps track of the current voting session's progress
 */
public class ClientVote {
    private int num = 0;
    private int cap;
    
    /**
     * Constructor
     * @param cap The capacity of this poll (number of votes)
     */
    public ClientVote(int cap) {
        this.cap = cap;
    }
    
    /**
     * Updates the progress of the poll
     * @param num int votes cast
     */
    public void update(int num) {
        this.num = num;
    }
    
    /**
     * Returns the number of votes already submitted
     * @return int number of votes currently cast
     */
    public int getCurrent() {
        return num;
    }
    
    /**
     * Returns the voter capacity of the poll
     * @return int total votes expected
     */
    public int getCap() {
        return cap;
    }
    
    /**
     * Returns true if the number of votes cast is greater than or
     * equal to the number of voter polled
     * @return true if everyone has voted
     */
    public boolean isDone() {
        return num >= cap;
    }
}
