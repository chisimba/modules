/**
 * 	$Id: AddItemPacket.java,v 1.3 2007/05/11 13:50:30 davidwaf Exp $
 * 
 *  Copyright (C) GNU/GPL AVOIR 2007
 * 
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.realtime.whiteboard.common.packet;

import avoir.realtime.whiteboard.common.item.Item;

/**
 * Packet used to add drawing items to the whiteboard
 */
@SuppressWarnings("serial")
public class AddItemPacket implements WBPacket {
    Integer id;

    Item element;

    /**
     * Constructor
     * @param id ID of the whiteboard element
     * @param element The Item to be added to the whiteboard
     */
    public AddItemPacket(Integer id, Item element) {
        this.id = id;
        this.element = element;
    }

    /**
     * Returns the id of the item
     * @return Object id
     */
    public Integer getID() {
        return id;
    }

    /**
     * returns the item in the packet
     * @return Object element
     */
    public Item getElement() {
        return element;
    }
}