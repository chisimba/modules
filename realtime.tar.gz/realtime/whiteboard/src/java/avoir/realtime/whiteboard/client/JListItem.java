/**
 * 	$Id: JListItem.java,v 1.2 2007/01/15 09:57:49 adrian Exp $
 * 
 *  Copyright (C) GNU/GPL AVOIR 2007
 * 
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.realtime.whiteboard.client;

import java.awt.Color;

/**
 * Class used to hold a String and a background color for use in a JList
 */
public class JListItem{
    private Color color;
    private String string;
    
    /**
     * Constructor
     * @param s String
     * @param c Color
     */
    public JListItem(String s, Color c) {
        color = c;
        string = s;
    }
    
    /**
     * Returns the color of this cell
     * @return color
     */
    public Color getColor() {
        return color;
    }
    
    /**
     * Returns the value of this cell
     * @return Value
     */
    public String getValue() {
        return string;
    }
    
    /**
     * sets the background color of the cell
     * @param c Color
     */
    public void setColor(Color c) {
        color = c;
    }
}
