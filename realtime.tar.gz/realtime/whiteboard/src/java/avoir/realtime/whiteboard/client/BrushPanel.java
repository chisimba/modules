/**
 *  $Id: BrushPanel.java,v 1.13 2007/05/11 13:37:28 davidwaf Exp $
 * 
 *  Copyright (C) GNU/GPL AVOIR 2007
 *  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.realtime.whiteboard.client;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JToggleButton;
import javax.swing.JToolBar;
import javax.swing.SwingConstants;

import avoir.realtime.User;
import avoir.util.ImageUtil;

/**
 * Creates a brush selector for the Whiteboard interface.
 * The user clicks on icons to select a brush type.
 *
 * 11th Jan 2007: David Wafula changed this to toolbar class, then modified
 * the toolbuttons to toggle buttons
 */
@SuppressWarnings("serial")
public class BrushPanel extends JToolBar {

    private static Logger logger = Logger.getLogger(BrushPanel.class.getName());

    private JButton clearButton, undoButton;

    protected JToggleButton penButton;

    private JToggleButton frameRectButton, filledRectButton, lineButton,
            frameOvalButton, filledOvalButton, moveButton, textButton;

    private JButton changeToken;

    private ImageIcon iconYes, iconNo;

    private JToggleButton insertImageButton;

    private boolean iconState;

    private ButtonGroup bg = new ButtonGroup();

    private SocketList socketList;

    /**
     * Constructor
     */
    public BrushPanel(SocketList socketList) {
        this.setOrientation(JToolBar.VERTICAL);
        iconState = false;
        this.socketList = socketList;

        try {
            penButton = new JToggleButton(ImageUtil.createImageIcon(this,
                    "/icons/pentool.gif"));
            penButton.setBorderPainted(false);
            bg.add(penButton);
            lineButton = new JToggleButton(ImageUtil.createImageIcon(this,
                    "/icons/line.gif"));
            lineButton.setBorderPainted(false);
            bg.add(lineButton);
            frameRectButton = new JToggleButton(ImageUtil.createImageIcon(this,
                    "/icons/rectangle_nofill.gif"));
            bg.add(frameRectButton);
            frameRectButton.setToolTipText("Framed Rectangle");
            frameRectButton.setBorderPainted(false);
            filledRectButton = new JToggleButton(ImageUtil.createImageIcon(
                    this, "/icons/rectangle_fill.gif"));
            bg.add(filledRectButton);
            filledRectButton.setToolTipText("Filled Rectangle");
            filledRectButton.setBorderPainted(false);
            frameOvalButton = new JToggleButton(ImageUtil.createImageIcon(this,
                    "/icons/oval_nofill.gif"));
            bg.add(frameOvalButton);
            frameOvalButton.setToolTipText("Framed Oval");
            frameOvalButton.setBorderPainted(false);
            filledOvalButton = new JToggleButton(ImageUtil.createImageIcon(
                    this, "/icons/oval_fill.gif"));
            filledOvalButton.setToolTipText("Filled Oval Button");
            filledOvalButton.setBorderPainted(false);
            bg.add(filledOvalButton);
            moveButton = new javax.swing.JToggleButton(ImageUtil
                    .createImageIcon(this, "/icons/movearrow.gif"));
            moveButton.setBorderPainted(false);
            bg.add(moveButton);
            textButton = new javax.swing.JToggleButton(ImageUtil
                    .createImageIcon(this, "/icons/text.gif"));
            textButton.setBorderPainted(false);
            bg.add(textButton);
            clearButton = new JButton(ImageUtil.createImageIcon(this,
                    "/icons/delete.gif"));
            clearButton.setBorderPainted(false);
            clearButton.setToolTipText("Clear");
            undoButton = new JButton(ImageUtil.createImageIcon(this,
                    "/icons/undo.gif"));
            undoButton.setToolTipText("Undo");
            undoButton.setBorderPainted(false);

            insertImageButton = new JToggleButton("");
            insertImageButton.setBorderPainted(false);
            iconYes = ImageUtil.createImageIcon(this, "/icons/yestoken.gif");
            iconNo = ImageUtil.createImageIcon(this, "/icons/notoken.gif");
        } catch (FileNotFoundException e) {
            logger.log(Level.SEVERE, "Error creating image icons", e);
        }

        changeToken = new JButton(iconNo);
        changeToken.setBorderPainted(false);
        changeToken.setToolTipText("Change Token");
        penButton.setHorizontalAlignment(SwingConstants.LEFT);
        lineButton.setHorizontalAlignment(SwingConstants.LEFT);
        frameRectButton.setHorizontalAlignment(SwingConstants.LEFT);
        filledRectButton.setHorizontalAlignment(SwingConstants.LEFT);
        frameOvalButton.setHorizontalAlignment(SwingConstants.LEFT);
        filledOvalButton.setHorizontalAlignment(SwingConstants.LEFT);
        moveButton.setHorizontalAlignment(SwingConstants.LEFT);
        textButton.setHorizontalAlignment(SwingConstants.LEFT);
        clearButton.setHorizontalAlignment(SwingConstants.LEFT);
        undoButton.setHorizontalAlignment(SwingConstants.LEFT);
        changeToken.setHorizontalAlignment(SwingConstants.LEFT);

        this.add(penButton);
        this.add(lineButton);
        this.add(frameRectButton);
        this.add(filledRectButton);
        this.add(frameOvalButton);
        this.add(filledOvalButton);
        this.add(moveButton);
        this.add(textButton);
        this.add(clearButton);
        this.add(undoButton);
        this.add(changeToken);

    }

    /**
     * Method that adds action listeners to all of the buttons
     * @param al ActionListener
     */
    public void addActionListener(ActionListener al) {
        penButton.addActionListener(al);
        frameRectButton.addActionListener(al);
        filledRectButton.addActionListener(al);
        lineButton.addActionListener(al);
        frameOvalButton.addActionListener(al);
        filledOvalButton.addActionListener(al);
        moveButton.addActionListener(al);
        textButton.addActionListener(al);
        undoButton.addActionListener(al);
        clearButton.addActionListener(al);
        insertImageButton.addActionListener(al);
        changeToken.addActionListener(al);
    }

    /**
     *
     * Sets the icon that represents whether the user has a token or not
     * @param state boolean
     */
    public void setTokenIcon(boolean state) {
        iconState = state;
        if (state) {
            changeToken.setIcon(iconYes);
        } else {
            changeToken.setIcon(iconNo);
        }
        validate();
    }

    /**
     * Returns the value of the has token icon in the brush panel
     * @return true if the user has a token
     */
    public boolean getTokenIconValue() {
        return iconState;
    }

    /**
     * Handler for the button actions
     * @param ae ActionEvent
     * @param wb the Whiteboard object that generated the event
     */
    public void actionPerformed(ActionEvent ae, Whiteboard wb) {
        Object source = ae.getSource();
        if (source.equals(clearButton)) {
            wb.clear();
        }
        if (source.equals(penButton)) {
            wb.changeBrush(0);
        }
        if (source.equals(frameRectButton)) {
            wb.changeBrush(1);
        }
        if (source.equals(filledRectButton)) {
            wb.changeBrush(2);
        }
        if (source.equals(frameOvalButton)) {
            wb.changeBrush(3);
        }
        if (source.equals(filledOvalButton)) {
            wb.changeBrush(4);
        }
        if (source.equals(lineButton)) {
            wb.changeBrush(5);
        }
        if (source.equals(textButton)) {
            wb.changeBrush(6);
        }
        if (source.equals(moveButton)) {
            wb.changeBrush(7);
        }
        if (source.equals(undoButton)) {
            wb.undoAction();
        }
        if (source.equals(changeToken)) {
          
        }
        if (source.equals(insertImageButton)) {
            wb.changeBrush(8);
            if (wb.getUser().hasToken()) {
                wb.chooseImage();
            }
        }
    }
}
