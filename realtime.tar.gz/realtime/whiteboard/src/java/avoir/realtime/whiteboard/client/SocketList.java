/**
 *  $Id: SocketList.java,v 1.15 2007/05/18 10:07:34 davidwaf Exp $
 *
 *  Copyright (C) GNU/GPL AVOIR 2007
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.realtime.whiteboard.client;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Enumeration;
import java.util.Stack;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JList;
import javax.swing.JTextArea;

import avoir.realtime.User;
import avoir.realtime.whiteboard.common.ClipArt;
import avoir.realtime.whiteboard.common.UpdateEvent;
import avoir.realtime.whiteboard.common.item.Item;
import avoir.realtime.whiteboard.common.item.ItemList;
import avoir.realtime.whiteboard.common.packet.AckPacket;
import avoir.realtime.whiteboard.common.packet.ImgPathPacket;
import avoir.realtime.whiteboard.common.packet.AddItemPacket;
import avoir.realtime.whiteboard.common.packet.BrowserClosePacket;
import avoir.realtime.whiteboard.common.packet.BrowserUpdatePacket;
import avoir.realtime.whiteboard.common.packet.ChatPacket;
import avoir.realtime.whiteboard.common.packet.ClearPacket;
import avoir.realtime.whiteboard.common.packet.ClientPacket;
import avoir.realtime.whiteboard.common.packet.ImagePacket;
import avoir.realtime.whiteboard.common.packet.InitPacket;
import avoir.realtime.whiteboard.common.packet.ModifyItemPacket;
import avoir.realtime.whiteboard.common.packet.QuitPacket;
import avoir.realtime.whiteboard.common.packet.ReplaceItemPacket;
import avoir.realtime.whiteboard.common.packet.TokenPacket;
import avoir.realtime.whiteboard.common.packet.UndoPacket;
import avoir.realtime.whiteboard.common.packet.VotePacket;
import avoir.realtime.whiteboard.common.packet.VoteResultPacket;
import avoir.realtime.whiteboard.common.packet.WBPacket;

/**
 * Handles information in the socket
 * Stores an ItemList of all of the Objects/Packets in use.
 * Sends calls to update other clients of changes in status.
 * Sends information to all of the clients and triggers updates
 */
public class SocketList extends Thread {

    private static Logger logger = Logger.getLogger(SocketList.class.getName());

    /**
     * Default time (in milliseconds) in wait inbetween listen attempts.
     */
    public static final int DEFAULT_LISTEN_RETRY_WAIT_TIME = 3000;

    /**
     * Default number of times to attempt to listen for a message from the server.
     */
    public static final int DEFAULT_MAX_LISTEN_ATTEMPTS = 5;

    /**
     * Time to wait inbetween listen attempts.
     */
    private int listenWaitTime = DEFAULT_LISTEN_RETRY_WAIT_TIME;

    /**
     * Number of times to attempt to listen for a message from the server.
     */
    private int maxListenAttempts = DEFAULT_MAX_LISTEN_ATTEMPTS;

    /**
     * Number of attempts that have been made to listen for a message from the server.
     */
    private int listenAttempts = 0;

    /**
     * Variable to control the running of this object as a thread.
     */
    private boolean running = true;

    /**
     * The socket
     */
    protected Socket socket;

    /**
     * Reader for the ObjectInputStream
     */
    protected ObjectInputStream reader;

    /**
     * Writer for the ObjectOutputStream
     */
    protected ObjectOutputStream writer;

    /**
     * Client Thread
     */
    protected Thread client;

    /**
     * Message to be displayed in the status text area
     */
    protected StatusBar msg;

    /**
     * List of users
     */
    protected JTextArea userList;

    /**
     * ItemList to hold all of the packets that are transmitted
     */
    protected ItemList list = new ItemList();

    /**
     * int port
     */
    protected int port;

    /**
     * String host
     */
    protected String host;

    /**
     * The Chisimba user.
     */
    protected User user;

    /**
     * Vector of listeners
     */
    protected Vector<UpdateListener> listeners = new Vector<UpdateListener>();

    /**
     * Vector of client names
     */
    protected Vector<User> users = new Vector<User>();

    /**
     * Stack for storing the chat
     */
    protected Stack<ChatPacket> chat;

    /**
     * The currently displayed browser window tab
     */
    protected int curWindow;

    /**
     * The most recently added browser window
     */
    protected String newestWindow;

    /**
     * The stack of open browser windows
     */
    protected Stack<String> windowStack;

    /**
     * The stack of the titles of the open browser windows
     */
    protected Stack<String> windowTitleStack;

    /**
     * Returns the current poll question
     */
    protected String curQuestion;

    /**
     * The title of the newest browser window
     */
    protected String newestTitle;

    /**
     * List of current options in the poll
     */
    protected Vector<String> curOptions;

    private Vector<ClipArt> images;

    /**
     * The JList representation of the UserList
     */
    protected JList jlist;

    /**
     * Constructor
     * @param host host address
     * @param port port number
     * @param jt JTextArea to display status in
     * @param user User
     */
    public SocketList(String host, int port, StatusBar jt, User user) {
        msg = jt;
        this.host = host;
        this.port = port;
        this.user = user;
        chat = new Stack<ChatPacket>();
        curWindow = 0;
        newestWindow = "";
        newestTitle = "";
        windowStack = new Stack<String>(); // doesn't have a copy of whiteboard
        windowTitleStack = new Stack<String>();
        images = new Vector<ClipArt>();
        curQuestion = "Default Question";
        curOptions = new Vector<String>();
    }

    /**
     * Returns the Vector of ClipArt on the whiteboard
     * @return Vector<ClipArt>
     */
    public Vector<ClipArt> getImages() {
        return images;
    }

    /**
     * Returns the Vector of current options for the poll
     * @return Vector<String>
     */
    public Vector<String> getOptions() {
        return this.curOptions;
    }

    /**
     * Returns the question asked
     * @return String question
     */
    public String getQuestion() {
        return this.curQuestion;
    }

    /**
     * Returns a list of users
     * @return list of users
     */
    public Vector<User> getUsers() {
        return users;
    }

    void uploadFile(ClipArt c) {
        try {
            //     writer.writeObject(new ImagePacket(c));
            writer.flush();
        } catch (IOException e) {
            logger.log(Level.WARNING, "Error uploading file", e);
            msg.setText("Could not send image to server");
        }
    }

    /**
     * Returns the most recent browser window
     * @return String url
     */
    public String getNewestWindow() {
        return newestWindow;
    }

    /**
     * Returns the currently displayed browser window
     * @return String url
     */
    public int getCurWindow() {
        return curWindow;
    }

    /**
     * Returns the stack of open browser windows
     * @return Stack of browser windows
     */
    public Stack<String> getWindowStack() {
        return windowStack;
    }

    /**
     * Returns the most recent window title
     * @return String title of window
     */
    public String getNewestTitle() {
        return newestTitle;
    }

    /**
     * Returns the Stack of window titles
     * @return Stack titles of windows
     */
    public Stack<String> getWindowTitleStack() {
        return windowTitleStack;
    }

    /**
     * Creates a socket for given host and port.
     * Initializes readers and writers for the input and output streams
     * Begins client communications
     * @throws java.lang.Exception catches UnknownHostException, IOException, ClassNotFoundExcpetion
     */
    public boolean connect() throws Exception {
        msg.setText("Attempting to connect to host: " + host + " on port: "
                    + new Integer(port).toString());
        try {
            socket = new Socket(host, port);
            writer = new ObjectOutputStream(new BufferedOutputStream(socket
                    .getOutputStream()));

            writer.flush();
            reader = new ObjectInputStream(new BufferedInputStream(socket
                    .getInputStream()));
            //send the this user over first
            writer.writeObject(new AckPacket(user));
            writer.flush();

            //then receive an updated user list
            ClientPacket clientPacket = (ClientPacket) reader.readObject();
            users = ((ClientPacket) clientPacket).getUsers();
            Update(UpdateEvent.USERLIST_CHANGE);

            //then recieve the packets
            InitPacket packet = (InitPacket) reader.readObject();
            list = packet.getList();
            images = packet.getImages();
            windowStack = packet.getWindowStack();
            windowTitleStack = packet.getWindowTitleStack();

            curWindow = packet.getCurWindow();
            client = new Thread(this);
            client.start();
            return true;
        } catch (Exception e) {
            //TODO: we should do something with this exception to let user know
            //that an error occurred connecting
            logger.log(Level.SEVERE, "Error connecting", e);
            return false;
        }

    }

    /**
     * Calls listen()
     */
    public void run() {
        try {
            listen();
            writer.writeObject(new QuitPacket());
            writer.flush();
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error running", e);
            msg.setText("Client exception: " + e);
        } finally {
            try {
                socket.close();
            } catch (IOException e) {
                logger.log(Level.WARNING, "Error closing socket", e);
            }
        }
    }

    /**
     * Listens for Packets in the InputStream of the Socket and
     * updates the SocketList's ItemList
     * Sends a call to Update the other clients.
     * The ServerThread eventually processes those messages and rebroadcasts
     * them to the other clients
     */
    public void listen() {
        while (running) {
            try {
                Object obj = reader.readObject();
                //if we get this far we have successfully read an object, so resest attempts.
                listenAttempts = 0;
                WBPacket packet = null;
                if (obj instanceof WBPacket) {
                    packet = (WBPacket) obj;
                }
                if (packet != null) {
                    logger.finest(getName() + " Received "
                                  + packet.getClass().getName() +
                                  " from server.");
                    if (packet instanceof ModifyItemPacket) {
                        int index = ((ModifyItemPacket) packet).getIndex();
                        Item item = ((ModifyItemPacket) packet).getItem();
                        list.set(index, item);
                        Update(UpdateEvent.WB_REPAINT);
                    } else if (packet instanceof AddItemPacket) {
                        Integer id = ((AddItemPacket) packet).getID();
                        Item element = ((AddItemPacket) packet).getElement();
                        list.addElementWithID(id, element);
                        Update(UpdateEvent.WB_REPAINT);
                    } else if (packet instanceof ReplaceItemPacket) {
                        Integer oldID = ((ReplaceItemPacket) packet).getOldID();
                        Integer id = ((ReplaceItemPacket) packet).getID();
                        Item element = ((ReplaceItemPacket) packet)
                                       .getElement();
                        list.replaceElementWithID(oldID, id, element);
                        Update(UpdateEvent.WB_REPAINT);
                    } else if (packet instanceof ClientPacket) {
                        users = ((ClientPacket) packet).getUsers();
                        Update(UpdateEvent.USERLIST_CHANGE);
                    } else if (packet instanceof ChatPacket) {
                        chat.add((ChatPacket) packet);
                        Update(UpdateEvent.CHAT_ADD);
                    } else if (packet instanceof UndoPacket) {
                        list.removeLastElement();
                        Update(UpdateEvent.WB_REPAINT);
                    } else if (packet instanceof ImagePacket) {
                        logger.finest("Updating image ...");
                        Update(UpdateEvent.IMAGE, packet);
                    } else if (packet instanceof ClearPacket) {
                        list.resetList();
                        Update(UpdateEvent.WB_REPAINT);
                    } else if (packet instanceof TokenPacket) {
                        User usr = ((TokenPacket) packet).getUser();
                        Vector<String> vi = new Vector<String>();
                        for (int i = 0; i < users.size(); i++) {
                            vi.add(users.get(i).getFirstName());
                        }
                        int index = vi.indexOf(usr.getFirstName());
                        usr.setToken(!usr.hasToken());
                        users.setElementAt(usr, index);
                        Update(UpdateEvent.TOKEN_CHANGE, usr);
                    } else if (packet instanceof VoteResultPacket) {
                        int code = ((VoteResultPacket) packet).getCode();
                        if (code == UpdateEvent.VOTE_FINISHED) {
                            int status = ((VoteResultPacket) packet)
                                         .getStatus();
                            Vector<Integer>
                                    results = ((VoteResultPacket) packet)
                                              .getResults();
                            results.set(0, new Integer(status));
                            Update(UpdateEvent.VOTE_FINISHED, results);
                        } else if (code == UpdateEvent.VOTE_UPDATE) {
                            logger.finest(((VoteResultPacket) packet)
                                          .getStatus()
                                          + "");
                            Update(UpdateEvent.VOTE_UPDATE,
                                   (Object) ((VoteResultPacket) packet)
                                   .getStatus());
                        }
                    } else if (packet instanceof VotePacket) {
                        int code = ((VotePacket) packet).getCode();
                        if (code == UpdateEvent.VOTE_CREATE) {
                            curQuestion = ((VotePacket) packet).getQuestion();
                            curOptions = ((VotePacket) packet).getOptions();
                            int time = ((VotePacket) packet).getTime();
                            Vector<Object> v = new Vector<Object>();
                            v.add(curQuestion);
                            v.add(new Integer(time));
                            v.add(curOptions);
                            Update(UpdateEvent.VOTE_CREATE, v);
                        } else if (code == UpdateEvent.VOTE_SUBMIT) {
                            logger.finest("vote submit here?");
                        }
                    } else if (packet instanceof BrowserUpdatePacket) {
                        int type = ((BrowserUpdatePacket) packet).getType();
                        if (type == UpdateEvent.BROWSER_ADD) {
                            newestWindow = ((BrowserUpdatePacket) packet)
                                           .getURL();
                            windowStack.add(newestWindow);
                            newestTitle = ((BrowserUpdatePacket) packet)
                                          .getTitle();
                            windowTitleStack.add(newestTitle);
                        } else if (type == UpdateEvent.BROWSER_CHANGE) {
                            curWindow = ((BrowserUpdatePacket) packet)
                                        .getIndex();
                        } else if (type == UpdateEvent.BROWSER_LINK) {
                            newestWindow = ((BrowserUpdatePacket) packet)
                                           .getURL();
                            curWindow = ((BrowserUpdatePacket) packet)
                                        .getIndex();
                            windowStack.setElementAt(newestWindow,
                                    curWindow - 1);
                        }
                        Update(type);
                    } else if (packet instanceof BrowserClosePacket) {
                        windowStack.remove(((BrowserClosePacket) packet)
                                           .getIndex());
                        windowTitleStack.remove(((BrowserClosePacket) packet)
                                                .getIndex());
                        Update(UpdateEvent.BROWSER_CLOSE, new Integer(
                                ((BrowserClosePacket) packet).getIndex()));
                    } else {
                        logger.warning("Unknown message: " + msg);
                    }
                }
            } catch (Exception e) {
                msg.setText("Error reading from server: " + e + ", attempt "
                            + listenAttempts);
                logger.log(Level.SEVERE, "Error reading from server", e);
                if (listenAttempts++ > maxListenAttempts) {
                    logger
                            .severe(
                            "Too many errors trying to listen to server, stopping");
                    this.running = false;
                } else {
                    try {
                        Thread.sleep(listenWaitTime);
                    } catch (InterruptedException e1) {
                        logger
                                .log(Level.WARNING, "Listen wait interrupted",
                                     e1);
                    }
                }
            }

        }
    }

    /**
     * Sends a packet about a user submitting a vote
     * @param answer int answer
     */
    public synchronized void submitVote(int answer) {
        try {
            writer.writeObject(new VotePacket(answer, user.getFirstName()));
            writer.flush();
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Error submitting vote", e);
            msg.setText("Could not submit vote: " + e);
        }
    }

    /**
     * Creates a new poll
     * @param question String question
     * @param options Vector possible answer choices
     * @param time length of poll in seconds
     */
    public synchronized void createVote(String question,
                                        Vector<String> options, int time) {
        try {
            writer.writeObject(new VotePacket(question, options, time, user
                                              .getFirstName()));
            writer.flush();
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Error creating vote", e);
            msg.setText("Could not create vote: " + e);
        }
    }

    /**
     * Sends a packet when a user clicks a browser link
     * @param url String url
     * @param index int window index
     */
    public synchronized void browserClickLink(String url, int index) {
        try {
            writer.writeObject(new BrowserUpdatePacket(url, index));
            writer.flush();
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Error clicking link", e);
            msg.setText("Could not click link: " + e);
        }
    }

    /**
     * Sends a packet to signify that a browser state has been changed
     * @param newState int new state
     */
    public synchronized void changeBrowserState(int newState) {
        try {
            writer.writeObject(new BrowserUpdatePacket(newState));
            writer.flush();
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Error changing browser state", e);
            msg.setText("Could not change state: " + e);
        }
    }

    /**
     * Sends a packet to signify that a new browser window has been added to the interface
     * @param url String url
     * @param title String title of window
     */
    public synchronized void addBrowserWindow(String url, String title) {
        try {
            writer.writeObject(new BrowserUpdatePacket(url, title));
            writer.flush();
        } catch (IOException e) {
            logger.log(Level.WARNING, "Error adding browser window", e);
            msg.setText("Could not add browser window: " + e);
        }
    }

    /**
     * Sends a packet when a user closes a browser window
     * @param index int index of the window
     */
    public synchronized void closeBrowserWindow(int index) {
        try {
            writer.writeObject(new BrowserClosePacket(index));
            writer.flush();
        } catch (IOException e) {
            logger.log(Level.WARNING, "Error closing browser window", e);
            msg.setText("Could not close window: " + e);
        }
    }

    /**
     * Sends a packet to gives the drawing token to a user
     * @param user User
     */
    public synchronized void giveToken(User user) {
        try {
            writer.writeObject(new TokenPacket(user));
            writer.flush();
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Error giving token", e);
            msg.setText("Could not give token: " + e);
        }
    }

    /**
     * Sends a packet to add a chat item to the buffer
     * @param usr User who sent the message
     * @param content The message
     * @param time The time the message was sent
     */
    public synchronized void addChat(String usr, String content, String time) {
        try {
            writer.writeObject(new ChatPacket(usr, content, time));
            writer.flush();
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Error adding chat", e);
            msg.setText("Could not add chat: " + e);
        }
    }

    /**
     * Sends a packet to add an Item to the buffer
     * @param o Object to add (Item)
     */
    public synchronized void addItem(Item o) {
        try {
            writer.writeObject(new AddItemPacket(new Integer( -1), o));
            writer.flush();
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Error adding item", e);
            msg.setText("Error adding item: " + e);
        }
    }

    public synchronized void sendImgPath(String path) {
        try {
            writer.writeObject(new ImgPathPacket(path));
            writer.flush();
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Error adding item", e);
            msg.setText("Error adding item: " + e);
        }
    }

    public synchronized void modifyItem(ModifyItemPacket packet, boolean send) {
        try {
            int index = packet.getIndex();
            Item item = packet.getItem();
            list.set(index, item);
            if (send) {
                writer.writeObject(packet);
                writer.flush();
            }
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Error modifying item", e);
            msg.setText("Error modifying item: " + e);
        }
    }

    public void sentPacket(WBPacket packet) {
        try {
            writer.writeObject(packet);
            writer.flush();
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Error sending packet", e);
            msg.setText("Error sending packet: " + e);
        }

    }

    public void sentString(String str) {
        try {
            writer.writeObject(str);
            writer.flush();
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Error sending string", e);
            msg.setText("Error sending string: " + e);
        }
    }

    /**
     * Replaces the last item in the ItemList
     * @param o Old object
     * @param n New object

     this.sl.replaceLastItem(selected,
     selected.getTranslated(prevX - startX,
     prevY - startY));

     */
    public synchronized void replaceLastItem(Item o, Item n) {
        try {
            Integer id = (Integer) list.getIDOfElement(o);
            if (id != null) {
                writer
                        .writeObject(new ReplaceItemPacket(new Integer( -1), id,
                        n));
                writer.flush();
            }
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Error replacing item", e);
            msg.setText("Error replacing item: " + e);
        }
    }

    /**
     * adds an UpdateListener to the Vector of listeners
     * @param l the new UpdateListener
     */
    public synchronized void addUpdateListener(UpdateListener l) {
        listeners.addElement(l);
    }

    /**
     * Removes an UpdateListener from the Vector of listeners
     * @param l UpdateListener to remove
     */
    public synchronized void removeUpdateListener(UpdateListener l) {
        listeners.removeElement(l);
    }

    /**
     * Returns an Enumeration of the elements in the ItemList
     * @return Enumeration of Items
     */
    public Enumeration elements() {
        return list.elements();
    }

    /**
     * Returns a stack of all of the chat messages
     * @return Stack chat
     */
    public Stack getChat() {
        return chat;
    }

    /**
     * Sends a packet to signify that the user has undone their last drawing action
     */
    public synchronized void undoAction() {
        if (list.size() > 0) {
            try {
                writer.writeObject(new UndoPacket());
                writer.flush();
            } catch (IOException e) {
                logger.log(Level.SEVERE, "Error undoing", e);
                msg.setText("Error undoing: " + e);
            }
        }
    }

    /**
     * Sends a packet to signify that a client has cleared the whiteboard
     */
    public synchronized void clear() {
        try {
            writer.writeObject(new ClearPacket());
            writer.flush();
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Error clearing", e);
            msg.setText("Error clearing: " + e);
        }
    }

    /**
     * Constructor
     * @param code int update code
     * @param data Object attached data
     */
    protected void Update(int code, Object data) {
        try {
            UpdateEvent event = new UpdateEvent(this, code, data);
            for (int i = 0; i < listeners.size(); i++) {
                ((UpdateListener) listeners.elementAt(i)).updateOccurred(event);
            }
        } catch (NullPointerException e) {
            logger.log(Level.SEVERE, "Error updating", e);
            msg.setText("Error updating: " + e);
        }
    }

    /**
     * Creates and UpdateEvent to signify that the clients needs to be updated
     * @param code update type
     */
    protected void Update(int code) {
        try {
            UpdateEvent event = new UpdateEvent(this, code);
            for (int i = 0; i < listeners.size(); i++) {
                ((UpdateListener) listeners.elementAt(i)).updateOccurred(event);
            }
        } catch (NullPointerException e) {
            logger.log(Level.SEVERE, "Error during update", e);
        }
    }

    void printContents() {
        //I accidentally deleted this method.
    }
}
