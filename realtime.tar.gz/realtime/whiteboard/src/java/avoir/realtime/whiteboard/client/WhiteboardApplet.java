/**
 *  $Id: WhiteboardApplet.java,v 1.12 2007/05/11 13:52:52 davidwaf Exp $
 *
 *  Copyright (C) GNU/GPL AVOIR 2007
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.realtime.whiteboard.client;

import java.awt.AWTEvent;
import java.awt.AWTEventMulticaster;
import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GraphicsEnvironment;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.ImageIcon;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JColorChooser;
import javax.swing.JComboBox;
import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JTextArea;
import javax.swing.JToggleButton;
import javax.swing.JToolBar;

import avoir.realtime.User;
import avoir.realtime.applet.RealtimeApplet;
import avoir.realtime.whiteboard.common.UpdateEvent;
import avoir.realtime.whiteboard.common.WhiteboardConstants;
import avoir.realtime.whiteboard.common.packet.ImagePacket;
import avoir.util.ImageUtil;

/**
 * The Applet that displays the user interface for the Realtime tools
 */
@SuppressWarnings("serial")
public class WhiteboardApplet extends RealtimeApplet implements UpdateListener,
        ActionListener {

    private static Logger logger = Logger.getLogger(WhiteboardApplet.class
            .getName());

    private static final String COMMAND_PIXEL = "pixel";

    private static final String COMMAND_XOR = "xor";

    private static final String COMMAND_LIVE = "live";

    private static final String COMMAND_ADD_IMAGE = "addimage";

    private AdminPanel adminPanel;

    private MainWindow mainWindow;

    private StatusBar statusBar;

    private ChatRoom chatRoom;

    private UserList userList;

    private SocketList socketList;

    private JPanel bottomPanel, rightPanel;

    private JColorChooser chooser;

    private Whiteboard whiteBoard;

    private BrushPanel brushPanel;

    private JDesktopPane desktop = new JDesktopPane();

    private JMenuBar menubar = new JMenuBar();

    private JToolBar toolbar = new JToolBar();

    //introduce internal frames for easy applet layout
    private JInternalFrame adminFrame = new JInternalFrame("Adminstration",
            true, false, true, true);

    private JInternalFrame canvasFrame = new JInternalFrame("Whiteboard", true,
            false, true, true);

    private JInternalFrame chatFrame = new JInternalFrame("Chat", true, false,
            true, true);

    private JInternalFrame colorFrame = new JInternalFrame("Color", true,
            false, true, true);

    public JComboBox fontSizeField = new JComboBox();

    public JComboBox fontNamesField = new JComboBox();

    public JToggleButton boldButton, italicButton, underButton;

    private JPopupMenu popup = new JPopupMenu();

    private PixelButton pixelButton = new PixelButton();

    /**
     * The currently logged in user.
     */
    private User user;

    /**
     * for pixel width management
     */
    public float strokeWidth = 1;

    /** Initializes the applet */
    public void init() {
        logger.finest("Applet init");

        try {
            EventQueue.invokeAndWait(new Runnable() {
                public void run() {
                    initComponents();
                }
            });
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error creating GUI", e);
        }
    }

    /** This method is called by the init() method to
     * initialize the GUI form.
     */
    private void initComponents() {
        bottomPanel = new javax.swing.JPanel();
        rightPanel = new javax.swing.JPanel();
        rightPanel.setLayout(new java.awt.GridLayout(2, 0));
        setLayout(new java.awt.BorderLayout());
        statusBar = new StatusBar(new JTextArea());

        String host = getCodeBase().getHost();
        int port = (getParameter("port") == null) ? WhiteboardConstants.DEFAULT_SERVER_PORT
                : Integer.parseInt(getParameter("port"));
        chooser = new javax.swing.JColorChooser();

        // Retrieve the current set of panels
        javax.swing.colorchooser.AbstractColorChooserPanel[] oldPanels = chooser
                .getChooserPanels();
        // Remove panels
        chooser.setPreviewPanel(new javax.swing.JPanel());
        for (int i = 0; i < oldPanels.length; i++) {
            String clsName = oldPanels[i].getClass().getName();
            if ((clsName
                    .equals("javax.swing.colorchooser.DefaultRGBChooserPanel"))
                    || (clsName
                            .equals("javax.swing.colorchooser.DefaultHSBChooserPanel"))) {
                chooser.removeChooserPanel(oldPanels[i]);
            }
        }
        //make dragging on desktop abit lighter
        desktop.setDragMode(JDesktopPane.OUTLINE_DRAG_MODE);

        bottomPanel.add(statusBar);

        user = getCurrentUser();
        socketList = new SocketList(host, port, statusBar, user);
        try {
            if (socketList.connect()) {
                statusBar.setText("Connected to host: " + host + " on port: "
                        + new Integer(port).toString());
            } else {
                javax.swing.JOptionPane.showMessageDialog(null,
                        "Error connecting to host: " + host + " on port: "
                                + new Integer(port).toString());
                statusBar.setText("Error connecting to host: " + host
                        + " on port: " + new Integer(port).toString());

            }
        } catch (Exception e) {

            logger.log(Level.WARNING, "Error connecting to host", e);
        }
        brushPanel = new BrushPanel(socketList);

        add(desktop, java.awt.BorderLayout.CENTER);
        add(brushPanel, java.awt.BorderLayout.WEST);

        chatRoom = new ChatRoom(socketList, user.getFullName());
        userList = new UserList(socketList);

        //create the admin frame
        adminPanel = new AdminPanel(mainWindow, socketList, user);
        rightPanel.add(userList);
        rightPanel.add(adminPanel);
        adminFrame.getContentPane().add(rightPanel);
        adminFrame.setSize(250, 250); //getWidth() / 2,( getHeight() /8)*3);
        adminFrame.setLocation((getWidth() - 300), 50);
        adminFrame.setVisible(true);
        addFrame(adminFrame);

        //create the color frame
        colorFrame.getContentPane().add(chooser);
        colorFrame.setLocation((getWidth() - 300), ((getHeight() / 4) * 2));
        colorFrame.setSize((getWidth() / 4) * 3, getHeight() / 4);
        colorFrame.setVisible(true);
        addFrame(colorFrame);

        //create the chat frame
        chatFrame.getContentPane().add(chatRoom);
        chatFrame.setLocation(100, ((getHeight() / 3) * 2) - 60);
        chatFrame.setSize((getWidth() / 4) * 3, (getHeight() / 4));
        chatFrame.setVisible(true);
        addFrame(chatFrame);

        whiteBoard = new Whiteboard(host, port, statusBar, brushPanel, user,
                socketList, userList, this);
        whiteBoard.setName("Whiteboard");
        chooser.getSelectionModel().addChangeListener(whiteBoard);
        mainWindow = new MainWindow(whiteBoard, socketList, user);

        JPanel canvasPanel = (JPanel) canvasFrame.getContentPane();
        canvasPanel.setLayout(new BorderLayout());
        canvasPanel.add(mainWindow, BorderLayout.CENTER);
        canvasFrame.setSize((getWidth() / 4) * 3, getHeight() / 2);
        canvasFrame.setVisible(true);
        addFrame(canvasFrame);

        try {
            socketList.addUpdateListener(this);
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error adding update listener", e);
        }

        add(bottomPanel, java.awt.BorderLayout.SOUTH);
        add(toolbar, java.awt.BorderLayout.NORTH);
        createMenu();
        createToolBar();
        this.setJMenuBar(menubar);
    }

    /**
     * Creates the options menu.
     */
    private void createMenu() {
        JMenu optionsMenu = new JMenu("Options");

        JCheckBoxMenuItem liveDragMenuItem = new JCheckBoxMenuItem(
                "Enable Live Drag");
        liveDragMenuItem.addActionListener(this);
        liveDragMenuItem.setActionCommand(COMMAND_LIVE);
        optionsMenu.add(liveDragMenuItem);
        menubar.add(optionsMenu);

        JCheckBoxMenuItem xorMenuItem = new JCheckBoxMenuItem("Enable XOR Mode");
        xorMenuItem.addActionListener(this);
        xorMenuItem.setActionCommand(COMMAND_XOR);
        optionsMenu.add(xorMenuItem);

        JMenuItem addImageItem = new JMenuItem("Add image...");
        addImageItem.addActionListener(this);
        addImageItem.setActionCommand(COMMAND_ADD_IMAGE);
        optionsMenu.add(addImageItem);
    }

    /**
     * Create the tool bar.
     */
    private void createToolBar() {
        try {
            boldButton = new JToggleButton(ImageUtil.createImageIcon(this,
                    "/icons/text_bold.png"));
            boldButton.setBorderPainted(false);
            boldButton.setToolTipText("Bold");
            toolbar.add(boldButton);

            italicButton = new JToggleButton(ImageUtil.createImageIcon(this,
                    "/icons/text_italic.png"));
            italicButton.setToolTipText("Italic");
            italicButton.setBorderPainted(false);
            toolbar.add(italicButton);

            underButton = new JToggleButton(ImageUtil.createImageIcon(this,
                    "/icons/text_under.png"));
            underButton.setToolTipText("Underline");
            underButton.setBorderPainted(false);
            toolbar.add(underButton);

            pixelButton.addActionListener(this);
            pixelButton.setActionCommand(COMMAND_PIXEL);
            pixelButton.setSize(81, 27);
            /**
             * probably not the best place to place the pixel button..but now with the
             * toolbar layout...where else?
             */
            toolbar.add(pixelButton);

            for (int i = 8; i < 100; i++) {
                fontSizeField.addItem(i + "");
            }
            fontSizeField.setSelectedItem("12");
            GraphicsEnvironment ge = GraphicsEnvironment
                    .getLocalGraphicsEnvironment();
            String[] fontFamilies = ge.getAvailableFontFamilyNames();
            for (int i = 0; i < fontFamilies.length; i++) {
                fontNamesField.addItem(fontFamilies[i]);
            }
            fontNamesField.setSelectedItem("Dialog");
            toolbar.add(fontNamesField);
            JPanel p = new JPanel();
            p.setLayout(new BorderLayout());
            p.add(fontSizeField, BorderLayout.WEST);
            toolbar.add(p);
            toolbar.setEnabled(false);

            createPixelOptionFrame();
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error creating tool bar", e);
        }
    }

    /**
     * Create an option frame from where one can choose the pixel width of a drawing
     * tool
     */
    private void createPixelOptionFrame() {
        JPanel p = new JPanel();
        p.setPreferredSize(new Dimension(100, 100));
        p.setLayout(new GridLayout(0, 1));
        PixelButtonOption b = new PixelButtonOption(1);
        p.setSize(81, 21);
        p.add(b);

        b = new PixelButtonOption(3);
        p.setSize(81, 21);

        p.add(b);
        b = new PixelButtonOption(5);
        p.setSize(81, 21);

        p.add(b);
        b = new PixelButtonOption(7);
        p.setSize(81, 21);

        p.add(b);
        b = new PixelButtonOption(9);
        p.setSize(81, 21);

        p.add(b);
        b = new PixelButtonOption(11);
        p.setSize(81, 21);
        //just put the panel on the popup for rendering
        popup.add(p);
    }

    /**
     *
     * Create our own custom button that basically shows current pixel selection
     * Has some basic jbutton methods
     * */
    class PixelButton extends Component {

        boolean pressed = false;

        ActionListener actionListener;

        String actionCommand;

        PixelButton() {

            // Rather than adding a MouseListener we force all Mouse
            // button events to be sent to the ProcessEvents()
            // method with this call to enableEvents with this mask.
            enableEvents(AWTEvent.MOUSE_EVENT_MASK);
        }

        public void paint(Graphics g) {
            int width = getSize().width, height = getSize().height;

            // Use gray for the button sides.
            g.setColor(WhiteboardApplet.this.getBackground());

            // Use the 3D rectangle drawing methods to create a
            // button style border around the image.
            // Redraw with smaller dimensions to make border larger.
            // Note that the last argument determines if the rectangle
            // shading is for raised or lowered bevel.
            g.draw3DRect(0, 0, width - 1, height - 1, !pressed);
            g.draw3DRect(1, 1, width - 3, height - 3, !pressed);
            g.draw3DRect(2, 2, width - 5, height - 5, !pressed);

            // Change back to white for the image background.
            g.setColor(Color.white);

            // Fill the area inside the last 3D rectangle
            g.fillRect(3, 3, width - 6, height - 6);

            Graphics2D g2 = (Graphics2D) g;
            g2.setColor(Color.black);
            g2.setStroke(new BasicStroke(strokeWidth));
            g2.drawLine(2, height / 2, width - 2, height / 2);

        }

        // The layout managers call this for a component when they
        // decide how much space to allow for it.
        public Dimension getPreferredSize() {
            return getSize();
        }

        // We forced all mouse click events to come here
        // in a manner similar to the old Java 1.0 event
        // handling style. The event is examined to see
        // what kind it is.
        public void processEvent(AWTEvent e) {
            if (e.getID() == MouseEvent.MOUSE_PRESSED) {
                // Set the button in the pressed state
                pressed = true;
                // and paint it in pressed state.
                repaint();
            } else if (e.getID() == MouseEvent.MOUSE_RELEASED) {
                // Set the button in up state
                pressed = false;
                repaint();
                // and call fireEvent, which will send events
                // to the listeners to PictureButton.
                fireEvent();
            }
            super.processEvent(e);
        }

        // A listener or event handling for this button may check
        // its ActionCommand value to see which button it is.
        // For a regular Button the ActionCommand value defaults
        // to the name on the Button. The setActionCommand allows
        // one to use a different value to test for in the
        // listener. Here we are making our own button so we
        // should set the ActionCommand value.
        public void setActionCommand(String actionCommand) {
            this.actionCommand = actionCommand;
        }

        // These three methods are what allow this button to become
        // an event generator. The AWTEventMulticaster takes care
        // of most of the work.

        // Here we allow listeners to add themselves to our
        // listener list. We use the AWTEventMulticaster static add.
        public void addActionListener(ActionListener l) {

            // NOTE: an AWTEventMulticaster object is returned here.
            // but since it implements all the listener interfaces
            // so we can reference it with our actionListener variable.
            actionListener = AWTEventMulticaster.add(actionListener, l);
        }

        // Here we allow listeners to remove themselves from our
        // listener list. We use the AWTEventMulticaster static
        // remove method.
        public void removeActionListener(ActionListener l) {
            actionListener = AWTEventMulticaster.remove(actionListener, l);
        }

        // This method is called by the processEvent() above
        // when the mouse button is released over the button .
        private void fireEvent() {

            if (actionListener != null) {
                // listener list. We use the AWTEventMulticaster
                // static add.
                ActionEvent event = new ActionEvent(this,
                        ActionEvent.ACTION_PERFORMED, actionCommand);

                // The AWTEventMulticaster object, but referenced
                // here with our actionListener variable, will call
                // all the actionListeners with this call to its
                // actionPerformed.
                actionListener.actionPerformed(event);
            }
        }
    }

    /**
     * This is still our own button, with most basic jbutton methods, but
     * we do our own painting on paint method
     */
    class PixelButtonOption extends Component implements ActionListener {

        boolean pressed = false;

        ActionListener actionListener;

        String actionCommand;

        float width;

        BasicStroke basicStroke;

        PixelButtonOption(float width) {
            this.width = width;
            basicStroke = new BasicStroke(width);
            this.addActionListener(this);
            enableEvents(AWTEvent.MOUSE_EVENT_MASK);
        }

        /**
         * we do our own painting here
         * @param g Graphics
         */
        public void paint(Graphics g) {
            int width = getSize().width, height = getSize().height;
            g.setColor(Color.white);
            g.draw3DRect(1, 1, width - 3, height - 3, !pressed);
            g.setColor(Color.white);
            g.fillRect(3, 3, width - 6, height - 6);
            Graphics2D g2 = (Graphics2D) g;
            g2.setColor(Color.black);
            g2.setStroke(basicStroke);
            g2.drawLine(2, height / 2, width - 2, height / 2);
        }

        public void actionPerformed(ActionEvent e) {
            strokeWidth = width;
            pixelButton.repaint();
         }

        public Dimension getPreferredSize() {
            return getSize();
        }

        public void processEvent(AWTEvent event) {
            if (event.getID() == MouseEvent.MOUSE_PRESSED) {
                // Set the button in the pressed state
                pressed = true;
                // and paint it in pressed state.
                repaint();
            } else if (event.getID() == MouseEvent.MOUSE_RELEASED) {
                // Set the button in up state
                pressed = false;
                repaint();
                // and call fireEvent, which will send events
                // to the listeners to PictureButton.
                fireEvent();
            }
            super.processEvent(event);
        }

        public void setActionCommand(String actionCommand) {
            this.actionCommand = actionCommand;
        }

        public void addActionListener(ActionListener l) {
            actionListener = AWTEventMulticaster.add(actionListener, l);
        }

        public void removeActionListener(ActionListener l) {
            actionListener = AWTEventMulticaster.remove(actionListener, l);
        }

        private void fireEvent() {
            if (actionListener != null) {
                ActionEvent event = new ActionEvent(this,
                        ActionEvent.ACTION_PERFORMED, actionCommand);
                actionListener.actionPerformed(event);
            }
        }
    }

    /**
     * ActionListener method interface. Used to react to actions generated
     * by items in the options menu.
     *
     * @param event ActionEvent
     */
    public void actionPerformed(ActionEvent event) {
        String command = event.getActionCommand();
        if (COMMAND_LIVE.equals(command)) {
            //set live drag update true/false
            JCheckBoxMenuItem checkBox = (JCheckBoxMenuItem) event.getSource();
            whiteBoard.liveDrag = checkBox.isSelected();
        } else if (COMMAND_XOR.equals(command)) {
            //enables/disables XOR Mode
            JCheckBoxMenuItem checkBox = (JCheckBoxMenuItem) event.getSource();
            whiteBoard.XOR = checkBox.isSelected();
        } else if (COMMAND_PIXEL.equals(command)) {
            /**
             * react to pixel change selection request: basically popup
             * the menu with options
             */
            PixelButton pixelButton = (PixelButton) event.getSource();
            if (popup.isVisible()) {
                popup.setVisible(true);
            } else {
                popup.show(pixelButton, pixelButton.getX()
                        - pixelButton.getWidth(), pixelButton.getY());
            }
        } else if (COMMAND_ADD_IMAGE.equals(command)) {
            displayImageChooser();

            // Uncomment the following if you want to test with hard coded image

            /*try{
             String path = "file:/projects/JExam1.7/images/jkuat.jpg";
             java.net.URL imageURL = new URL(path);
             imageSelected(imageURL);
             }catch(Exception ex){
             logger.log(Level.SEVERE,
             "Error reading the image:", ex);
             }*/

        } else {
            logger.warning("Unrecognised action command: " + command);
        }
    }

    /**
     * Handler for UpdateEvents
     * @param ue UpdateEvent
     */
    @SuppressWarnings("unchecked")
    public void updateOccurred(UpdateEvent ue) {
        switch (ue.getCode()) {
        case UpdateEvent.BROWSER_CHANGE:
            mainWindow.changeState(socketList.getCurWindow());
            break;
        case UpdateEvent.BROWSER_ADD:
            mainWindow.addWindow(socketList.getNewestWindow(), socketList
                    .getNewestTitle());
            break;
        case UpdateEvent.BROWSER_CLOSE:
            int index = ((Integer) ue.getData()).intValue();
            mainWindow.closeWindow(index);
            break;
        case UpdateEvent.BROWSER_LINK:
            mainWindow.clickLink(socketList.getCurWindow(), socketList
                    .getNewestWindow());
            break;
        case UpdateEvent.TOKEN_CHANGE:
            whiteBoard.changeToken((User) ue.getData());
            break;
        case UpdateEvent.CHAT_ADD:
            chatRoom.update();
            break;
        case UpdateEvent.USERLIST_CHANGE:
            userList.update();
            break;
        case UpdateEvent.WB_REPAINT:
            whiteBoard.refreshScreen();
            break;
        case UpdateEvent.VOTE_CREATE:
            Vector<Object> v = (Vector<Object>) ue.getData();
            String name = (String) v.get(0);
            Integer time = (Integer) v.get(1);
            Vector<String> options = (Vector<String>) v.get(2);
            adminPanel.newVote(name, options, time.intValue());
            break;
        case UpdateEvent.VOTE_UPDATE:
            adminPanel.updateVote((Integer) ue.getData());
            break;
        case UpdateEvent.VOTE_FINISHED:
            logger.finest(((Vector) ue.getData()).toString());
            adminPanel.closeVote((Vector) ue.getData());
            break;
        case UpdateEvent.IMAGE:
            ImagePacket imPac = (ImagePacket) ue.getData();
            whiteBoard.refreshScreen();
            break;
        }
    }

    /**
     * this adds an internal frame to the desktop
     * @param frame JInternalFrame
     */
    private void addFrame(JInternalFrame frame) {
        try {
            frame.setSelected(true);
            desktop.add(frame);
        } catch (Exception e) {
            logger.log(Level.WARNING, "Error adding frame", e);
        }
    }

    /**
     * Method that is called on applet by JavaScript when user selects an
     * image to add to whiteboard via file chooser.
     *
     * @param imageURL The full HTTP address of the image to add.
     */
    public void imageSelected(String imageURL) {
        logger.fine("User selected image " + imageURL);
        try {

            //send this message to the server for distribution
            whiteBoard.commitImage(imageURL);
        } catch (Exception ex) {
            logger.log(Level.SEVERE, "Error in creating image icon", ex);
        }
    }

    /**
     * Method to make a JavaScript call back to page that applet is loaded in which
     * will in turn display the file manager image chooser in a popup window.
     */
    private void displayImageChooser() {
        try {
            URL imagePopupURL = new URL("javascript:openImageFileChooser()");
            getAppletContext().showDocument(imagePopupURL);
        } catch (MalformedURLException e) {
            logger.log(Level.SEVERE,
                    "Error calling file manager image chooser", e);
        }
    }
}
