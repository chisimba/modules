/**
 * 	$Id: ChatRoom.java,v 1.3 2007/02/02 10:59:15 davidwaf Exp $
 *
 *  Copyright (C) GNU/GPL AVOIR 2007
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.realtime.whiteboard.client;

import java.awt.event.ActionListener;
import java.util.Stack;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;
import java.awt.Dimension;
import java.awt.BorderLayout;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Color;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.JPanel;

import avoir.realtime.whiteboard.common.packet.ChatPacket;

/**
 * Window that diplays a chat session
 */
@SuppressWarnings("serial")
    public class ChatRoom
    extends JPanel implements ActionListener {

  private JTextField chatIn;
  private JTextArea chatShow;
  private JButton chatSubmit;
  private JScrollPane chatScroll;
  private JPanel chatInputPanel;
  private SocketList sl;
  private String usr;
  private int chatSize = 0;
  private MessagePanel messagePanel = new MessagePanel();
  /**
   * Constructor
   * @param sl SocketList
   * @param usr User
   */
  public ChatRoom(SocketList sl, String usr) {

    this.sl = sl;
    this.usr = usr;

    chatIn = new JTextField();
    chatShow = new JTextArea();
    chatSubmit = new JButton("Send");
    chatScroll = new JScrollPane();
    chatInputPanel = new JPanel();

    chatSubmit.addActionListener(this);

    chatIn.setEditable(true);
    chatIn.setColumns(20);
    chatIn.setText("Default Chat Text");

    chatShow.setEditable(false);
    chatShow.setColumns(20);
    chatShow.setLineWrap(true);
    chatShow.setWrapStyleWord(true);

    chatScroll.setVerticalScrollBarPolicy(ScrollPaneConstants.
                                          VERTICAL_SCROLLBAR_AS_NEEDED);
    messagePanel.setPreferredSize(new Dimension(getWidth(), 100));
    chatScroll.setViewportView(messagePanel);

    chatInputPanel.add(chatIn);
    chatInputPanel.add(chatSubmit);

    this.setLayout(new BorderLayout());// new java.awt.GridLayout(2, 0));

    this.add(chatScroll,BorderLayout.CENTER);
    this.add(chatInputPanel,BorderLayout.SOUTH);
  }

  /**
   * Event handler for the chat room
   * @param ae ActionEvent
   */
  public void actionPerformed(java.awt.event.ActionEvent ae) {
    sl.addChat(usr, chatIn.getText() + "\n",getTime());
    chatIn.setText("");
    //send chat to server
  }

  /**
   * gets the time message was received (send?)
   * @return String
   */
  public String getTime() {
    Date today;
    String result;
    SimpleDateFormat formatter;

    formatter = new SimpleDateFormat("H:m:s",
                                     new java.util.Locale("en_US"));
    today = new Date();
    result = formatter.format(today);
    return result;

  }

  /**
   * Updates the contents of the chat window
   */
  public void update() {
    movePanel(0, 1, sl.getChat().size());
    messagePanel.repaint();
  }

  /**
   * scrolls the message panel to latest message
   * @param xmove int
   * @param ymove int
   * @param size int
   */
  protected void movePanel(int xmove, int ymove, int size) {
    java.awt.Point pt = new java.awt.Point(0, size * 19);
    chatScroll.getViewport().setViewPosition(pt);
    chatScroll.repaint();
    messagePanel.repaint();
  }

  /**
   * Use this class to display the messages
   * */
  class MessagePanel
      extends JPanel {
    public MessagePanel() {
      setBackground(Color.white);

    }
    /**
     * Do actual painting here
     * @param g Graphics
     */
    public void paintComponent(Graphics g) {
      super.paintComponent(g);
      Stack chatStack = sl.getChat();
      int diff = chatStack.size() - chatSize;

      Graphics2D g2 = (Graphics2D) g;
      int yValue = 10;
      for (int i = 0; i < chatStack.size(); i++) {
        ChatPacket p = (ChatPacket) chatStack.get(i);
        g2.drawString("[" + p.getTime() + "] <" + p.getUsr() + "> " +
                      p.getContent(), 10, yValue);
        yValue += 20;
        diff--;
      }
      chatSize = chatStack.size();

      this.setPreferredSize(new Dimension(1000, chatStack.size() * 20));
      this.revalidate();
    }
  }

}
