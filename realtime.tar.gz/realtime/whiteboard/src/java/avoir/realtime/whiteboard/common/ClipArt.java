/**
 * 	$Id: ClipArt.java,v 1.2 2007/01/15 10:01:56 adrian Exp $
 * 
 *  Copyright (C) GNU/GPL AVOIR 2007
 * 
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.realtime.whiteboard.common;

import java.awt.Graphics;
import java.awt.Point;
import java.awt.image.ImageObserver;

import javax.swing.ImageIcon;

/**
 * Class used to represent a piece of clipart
 */
@SuppressWarnings("serial")
public class ClipArt implements java.io.Serializable {
    ImageIcon image;
    Point loc;
    
    /**
     * Constructor
     * @param image Image to be displayed
     * @param loc desired location of the image
     */
    public ClipArt(ImageIcon image, Point loc) {
        this.image = image;
        this.loc = loc;
    }
    
    /**
     * Returns the Image object in this clip art
     * @return Image
     */
    public ImageIcon getImage() {
        return image;
    }
    
    /**
     * Returns the location of this clip art
     * @return Point
     */
    public Point getPoint() {
        return loc;
    }
    
    /**
     * Describes how the ClipArt is to display itself
     * @param g Graphics Object
     * @param observer Image Observer
     */
    public void paint(Graphics g,ImageObserver observer) {
        g.drawImage(image.getImage(),(int)loc.getX(),(int)loc.getY(),observer);
    }
    
    /**
     * Sets the location of this ClipArt object
     * @param x horizontal coordinate
     * @param y vertical coordinate
     */
    public void setLocation(int x, int y) {
        loc = new Point(x,y);
    }
}
