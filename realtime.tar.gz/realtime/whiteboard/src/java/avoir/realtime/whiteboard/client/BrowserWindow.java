/**
 * 	$Id: BrowserWindow.java,v 1.4 2007/03/05 10:58:05 adrian Exp $
 * 
 *  Copyright (C) GNU/GPL AVOIR 2007
 *  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.realtime.whiteboard.client;

import java.awt.Dimension;
import java.io.IOException;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JEditorPane;
import javax.swing.JScrollPane;

/**
 * Used to display webpages in the applet
 */
@SuppressWarnings("serial")
public class BrowserWindow extends JScrollPane {
    private static Logger logger = Logger.getLogger(BrowserWindow.class
            .getName());

    private JEditorPane page; //the webpage

    /**
     * Construtor
     * @param url The url of the webpage to be displayed
     */
    public BrowserWindow(String url) {
        this.page = new javax.swing.JEditorPane();
        page.setEditable(false);
        setPage(url);
        this.setViewportView(page);
        this.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        this.setPreferredSize(new Dimension(250, 145));
        this.setMinimumSize(new Dimension(10, 10));
    }

    /**
     * Sets the title of the BrowserWindow
     * @param name String title
     */
    public void setTitle(String name) {
        this.setName(name);
    }

    /**
     * returns the JEditorPane containing the page
     * @return JEditorPane page
     */
    public JEditorPane getPage() {
        return page;
    }

    /**
     * Sets the contents of the BrowserWindow to those of the specified url
     * @param url String url
     */
    public void setPage(String url) {
        URL helpURL;
        try {
            helpURL = new URL(url);
        } catch (Exception e) {
            helpURL = null;
            logger.log(Level.WARNING, "Error setting page", e);
        }
        if (helpURL != null) {
            try {
                page.setPage(helpURL);
            } catch (IOException e) {
                logger.log(Level.WARNING, "Attempted to read a bad URL: "
                        + helpURL, e);
            }
        } else {
            logger.warning("Couldn't find file");
        }
    }
}
