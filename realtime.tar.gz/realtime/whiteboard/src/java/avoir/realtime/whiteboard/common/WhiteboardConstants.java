package avoir.realtime.whiteboard.common;

/**
 * Interface for constants which are used by both client applet and server.
 * 
 * @author adrian
 */
public interface WhiteboardConstants {

    /**
     * Default whiteboard servder port number.
     */
    public static final int DEFAULT_SERVER_PORT = 1981;

    /**
     * Server end of line.
     */
    public static final String SERVER_EOL = "";
    //TODO: seeing as SERVER_EOL is empty string surely we can just remove it?

}
