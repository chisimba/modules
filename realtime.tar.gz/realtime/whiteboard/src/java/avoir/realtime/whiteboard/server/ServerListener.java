/**
 * 	$Id: ServerListener.java,v 1.4 2007/03/05 12:55:04 adrian Exp $
 * 
 *  Copyright (C) GNU/GPL AVOIR 2007
 * 
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.realtime.whiteboard.server;

import java.io.IOException;
import java.net.ServerSocket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Sets up the ServerSocket and ServerThread
 */
public class ServerListener extends Thread {

    private static Logger logger = Logger.getLogger(ServerListener.class
            .getName());

    private int port;

    /**
     * The port number
     * @param port port number
     */
    public ServerListener(int port) {
        this.port = port;
    }

    /**
     * Run method
     */
    public void run() {
        try {
            ServerSocket serverSocket = new ServerSocket(port);
            logger.info("Listening for connections on port " + port);
            while (true) {
                try {
                    ServerThread server = new ServerThread(serverSocket
                            .accept());
                    new Thread(server).start();
                } catch (Exception e) {
                    logger.log(Level.SEVERE, "Error spawning listener thread",
                            e);
                }
            }
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Error assigning server socket", e);
        }
    }
}