/**
 * 	$Id: Vote.java,v 1.3 2007/01/23 13:24:40 adrian Exp $
 * 
 *  Copyright (C) GNU/GPL AVOIR 2007
 * 
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.realtime.whiteboard.common;

import java.util.Vector;

/**
 * Creates a new poll on the server
 */
public class Vote {
    private int totalVotes = 0;
    private int cap;
    //todo: get rid of vectors, could replace below with a map for example
    private Vector<String> options;
    private Vector<Integer> results;
    
    /**
     * Constructor
     * @param options Vector containing the choice options for this poll
     * @param cap the voter capacity of this poll
     */
    public Vote(int cap, Vector<String> options) {
        this.cap = cap;
        this.options = options;
        results = new Vector<Integer>();
        
        for(int lcv=0;lcv<options.size()+1;lcv++) {
            results.add(new Integer(0));
        }
    }
    
    /**
     * Adds votes to the running tally
     * @param answer voter supplied answer
     */
    public void add(int answer) {
        //check to see if user voted without choosing an input
        if(answer == -1) return;
        //get current total for the choice you voted for
        int total = results.get(answer).intValue();
        total++;
        results.set(answer, new Integer(total));
        totalVotes++;
    }
    
    /**
     * Returns the results of the poll
     * @return Vector of results
     */
    public Vector<Integer> getResults(){
        return this.results;
    }
    
    /**
     * Returns the number of votes cast
     * @return int votes cast
     */
    public int getCurrent() {
        return totalVotes;
    }
    
    /**
     * Returns the voter capacity of the poll
     * @return int voter capacity
     */
    public int getCap() {
        return cap;
    }
    
    /**
     * Returns true if everyone has voted
     * @return true if everyone has voted
     */
    public boolean isDone() {
        return totalVotes >= cap;
    }
}