/**
 * 	$Id: ReplaceItemPacket.java,v 1.2 2007/01/15 10:00:57 adrian Exp $
 * 
 *  Copyright (C) GNU/GPL AVOIR 2007
 * 
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.realtime.whiteboard.common.packet;

import avoir.realtime.whiteboard.common.item.Item;

/**
 * Packet that is sent when an Item needs to be replaced
 */
@SuppressWarnings("serial")
public class ReplaceItemPacket implements WBPacket {
    Integer oldID;
    Integer id;
    Item element;
    
    /**
     * Constructor
     * @param oldID ID of the Item to be replaced
     * @param id ID of the new Item
     * @param element The new Item
     */
    public ReplaceItemPacket(Integer oldID, Integer id, Item element) {
        this.oldID = oldID;
        this.id = id;
        this.element = element;
    }
    
    /**
     * Returns the id of the new Item
     * @return id
     */
    public Integer getID() {
        return id;
    }
    
    /**
     * Returns the new Item
     * @return new Item
     */
    public Item getElement() {
        return element;
    }
    
    /**
     * Returns the ID of the Item to be replaced
     * @return old ID
     */
    public Integer getOldID() {
        return oldID;
    }
}