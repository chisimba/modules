/**
 *  $Id: Whiteboard.java,v 1.30 2007/05/11 13:41:56 davidwaf Exp $
 *
 *  Copyright (C) GNU/GPL AVOIR 2007
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.realtime.whiteboard.client;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.font.TextAttribute;
import java.awt.font.TextLayout;
import java.awt.geom.Line2D;
import java.awt.image.PixelGrabber;
import java.io.File;
import java.text.AttributedString;
import java.util.Enumeration;
import java.util.Vector;
import java.util.logging.Logger;

import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JTextField;
import javax.swing.colorchooser.DefaultColorSelectionModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.PopupMenuEvent;
import javax.swing.filechooser.FileFilter;

import avoir.realtime.User;
import avoir.realtime.whiteboard.common.ClipArt;
import avoir.realtime.whiteboard.common.UpdateEvent;
import avoir.realtime.whiteboard.common.item.Img;
import avoir.realtime.whiteboard.common.item.Item;
import avoir.realtime.whiteboard.common.item.Oval;
import avoir.realtime.whiteboard.common.item.Pen;
import avoir.realtime.whiteboard.common.item.Rect;
import avoir.realtime.whiteboard.common.item.Txt;
import avoir.realtime.whiteboard.common.item.WBLine;
import avoir.realtime.whiteboard.common.packet.ModifyItemPacket;

/**
 * Class that creates a Whiteboard that users can draw on.  The server updates all remote instances of changes to one instance of the Whiteboard
 */
@SuppressWarnings("serial")
public class Whiteboard extends JPanel implements MouseListener,
        MouseMotionListener, ChangeListener, UpdateListener, ActionListener {

    private static Logger logger = Logger.getLogger(Whiteboard.class.getName());

    private static final int BRUSH_PEN = 0;

    private static final int BRUSH_RECT = 1;

    private static final int BRUSH_RECT_FILLED = 2;

    private static final int BRUSH_OVAL = 3;

    private static final int BRUSH_OVAL_FILLED = 4;

    private static final int BRUSH_LINE = 5;

    private static final int BRUSH_TEXT = 6;

    private static final int BRUSH_MOVE = 7;

    private static final int BRUSH_IMAGE = 8;

    private static final String[] brushName = new String[9];

    static {
        brushName[0] = "Pen";
        brushName[1] = "Rectangle";
        brushName[2] = "Filled Rectangle";
        brushName[3] = "Oval";
        brushName[4] = "Filled Oval";
        brushName[5] = "Line";
        brushName[6] = "Text";
        brushName[7] = "Move";
        brushName[8] = "Image";
    }

    /**
     * Whiteboard width.
     */
    private int width;

    /**
     * Whiteboard height.
     */
    private int height;

    private boolean dragging;

    private boolean connected;

    private int startX; //mouse cursor position on draw start

    private int startY; //mouse cursor position on draw start

    private int prevX; //last captured mouse co-ordinate pair

    private int prevY; //last captured mouse co-ordinate pair

    private Color colour;

    private SocketList socketList;

    private int brush;

    private Vector<WBLine> penVector;

    private Item selected;

    private Item selectedItem;

    public boolean XOR = false;

    private StatusBar statusBar;

    private BrushPanel brushPanel;

    private User user;

    private UserList userList;

    private boolean drawingEnabled;

    private boolean tooltip = false;

    private ClipArt tooltipIcon = null;

    private Vector<ClipArt> images;

    private WhiteboardApplet clientApplet;

    private int selectedIndex = -1;

    public boolean liveDrag = false;

    private JTextField textField = new JTextField();

    private JTextField editTextField = new JTextField();

    private JPopupMenu editPopup = new JPopupMenu();

    private JPopupMenu popup = new JPopupMenu();

    private Graphics2D graphics2D;

    private final float[] dash1 = { 1.0f };

    private final BasicStroke dashed = new BasicStroke(1.0f,
            BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 1.0f, dash1, 0.0f);

    private int rect_size = 8;

    private int initH;

    private int initW;

    private int last_w;

    private int last_h;

    private int init_x2;

    private int init_y2;

    private int init_x1;

    private int init_y1;

    /**
     * Creates a new instance of Whiteboard
     * @param userList The User List that gets displayed in the GUI
     * @param host String host
     * @param port int port
     * @param n StatusBar
     * @param bp ButtonPanel
     * @param user User
     * @param sl SocketList
     */
    public Whiteboard(String host, int port, StatusBar n, BrushPanel bp,
            User user, SocketList sl, UserList userList, WhiteboardApplet ca) {
        this.userList = userList;
        drawingEnabled = false;
        this.clientApplet = ca;
        images = new Vector<ClipArt>();
        penVector = new Vector<WBLine>();
        connected = false;
        addMouseListener(this);
        addMouseMotionListener(this);
        setBackground(Color.white);
        statusBar = n;
        this.brushPanel = bp;
        this.user = user;
        this.socketList = sl;
        images = this.socketList.getImages();
        connected = true;
        colour = Color.BLACK;
        brush = BRUSH_PEN;

        brushPanel.addActionListener(this);

        textField.addActionListener(this);
        textField.setActionCommand("text");
        textField.setOpaque(false);
        popup.setOpaque(false);
        popup.setPopupSize(new Dimension(100, 21));
        popup.add(textField);
        popup.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(PopupMenuEvent e) {
                commitStroke(startX, startY, prevX, prevY, true);
                popup.setVisible(false);
            }

            public void popupMenuWillBecomeInvisible(PopupMenuEvent e) {

            }

            public void popupMenuWillBecomeVisible(PopupMenuEvent e) {

            }
        });

        editTextField.addActionListener(this);
        editTextField.setActionCommand("edit");
        editPopup.setPopupSize(new Dimension(100, 21));
        editPopup.add(editTextField);

    }

    /**
     * Draws the ClipArt object onto the whiteboard
     * @param g the Graphics object
     */
    public void drawImages(Graphics g) {
        if (images.size() == 0) {
            return;
        }

        for (int i = 0; i < images.size(); i++) {
            images.get(i).paint(g, this);
        }
    }

    public static final boolean isGreyscaleImage(PixelGrabber pg) {
        return pg.getPixels() instanceof byte[];
    }

    /**
     * Commits an ImagePacket's contents to the whiteboard
     * @param image ImageIcon
     */
    public void commitImage(ImageIcon image) {
        this.socketList.addItem(new Img(image, startX, startY, image
                .getIconWidth(), image.getIconHeight()));
    }

    /**
     * Commits an ImagePacket's contents to the whiteboard
     * @param image ImageIcon
     */
    public void commitImage(String imagePath) {
        this.socketList.sendImgPath(imagePath);
    }
    /**
     * Handler for the BrushPanel button actions
     * @param ae ActionEvent
     */
    public void actionPerformed(ActionEvent ae) {
        brushPanel.actionPerformed(ae, this);
        if (ae.getActionCommand().equals("text")) {
            commitStroke(startX, startY, prevX, prevY, true);
            popup.setVisible(false);
        }
        if (ae.getActionCommand().equals("edit")) {
            if (selectedItem instanceof Txt) {
                Txt txt = (Txt) selectedItem;
                txt.setContent(editTextField.getText());
                int size = Integer.parseInt((String) clientApplet.fontSizeField
                        .getSelectedItem());
                int style = Font.PLAIN;
                if (clientApplet.boldButton.isSelected()) {
                    style = Font.BOLD;
                }
                if (clientApplet.italicButton.isSelected()) {
                    style = Font.ITALIC;
                }
                if (clientApplet.boldButton.isSelected()
                        && clientApplet.italicButton.isSelected()) {
                    style = Font.BOLD | Font.ITALIC;
                }
                txt.setFont(new Font((String) clientApplet.fontNamesField
                        .getSelectedItem(), style, size));
                txt.setUnderline(clientApplet.underButton.isSelected());
                txt.setColor(colour);
                this.socketList.modifyItem(new ModifyItemPacket(selectedIndex,
                        txt, ""), true);
                editPopup.setVisible(false);
            }
        }
    }

    /** clears the whiteboard canvas*/
    public void clear() {
        if (!drawingEnabled) {
            return;
        }
        this.socketList.clear();
    }

    /** refreshes the whiteboard canvas with the objects currently
     *  contained in the content buffer
     * No longer used
     */
    public void refreshScreen() {
        Graphics temp = getGraphics();
        temp.clearRect(0, 0, width, height);
        // clearBuffer();
        paint(temp);
        temp.dispose();
    }

    /** undoes the last user action */
    public void undoAction() {
        if (!drawingEnabled) {
            return;
        }
        this.socketList.undoAction();
    }

    /**
     * This is where actaul painting takes place
     * @param g Graphics
     */
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        graphics2D = g2;
        drawStroke(g2);
        if (connected) {
            Enumeration list = this.socketList.list.elements();
            if (XOR) {
                g2.setXORMode(getBackground());
            }

            int i = 0;
            while (list.hasMoreElements()) {
                Item temp = (Item) list.nextElement();
                if (temp instanceof Rect) {
                    Rect r = (Rect) temp;
                    g2.setStroke(new BasicStroke(r.getStroke()));
                    g2.setColor(r.getCol());

                    if (r.isFilled()) {
                        g2.fill(r.getRect());
                    } else {
                        g2.draw(r.getRect());
                    }
                }
                if (temp instanceof WBLine) {
                    WBLine l = (WBLine) temp;
                    g2.setStroke(new BasicStroke(l.getStroke()));
                    g2.setColor(l.getCol());
                    Line2D line = l.getLine();
                    g2.draw(line);
                }
                if (temp instanceof Pen) {
                    Pen p = (Pen) temp;
                    g2.setStroke(new BasicStroke(p.getStroke()));
                    g2.setColor(p.getCol());
                    Vector<WBLine> v = p.getPoints();
                    for (int k = 0; k < v.size(); k++) {
                        WBLine l = v.elementAt(k);
                        g2.drawLine(l.x1, l.y1, l.x2, l.y2);
                    }
                }
                if (temp instanceof Oval) {
                    Oval o = (Oval) temp;
                    g2.setStroke(new BasicStroke(o.getStroke()));
                    g2.setColor(o.getCol());
                    if (o.isFilled()) {
                        Rectangle r = o.getBounds();
                        g2.fillOval(r.x, r.y, r.width, r.height);
                    } else {
                        Rectangle r = o.getRect();
                        g2.drawOval(r.x, r.y, r.width, r.height);
                    }
                }
                if (temp instanceof Img) {
                    Img img = (Img) temp;
                    Rectangle bounds = img.getBounds();
                    g2.drawImage(img.getImg().getImage(), bounds.x, bounds.y,
                            bounds.width, bounds.height, this);
                }

                if (temp instanceof Txt) {
                    Txt t = (Txt) temp;
                    g2.setColor(t.getCol());

                    String txt = t.getContent();
                    Font font = t.getFont();
                    boolean underLine = t.isUnderlined();
                    Point point = t.getPoint();

                    if (txt.length() > 0) {
                        AttributedString as = new AttributedString(txt);
                        as.addAttribute(TextAttribute.FONT, font);
                        if (underLine) {
                            as.addAttribute(TextAttribute.UNDERLINE,
                                    TextAttribute.UNDERLINE_ON);
                        }
                        TextLayout tl = new TextLayout(as.getIterator(), g2
                                .getFontRenderContext());
                        tl.draw(g2, point.x, point.y);
                    }
                }

                i++;
                g2.setColor(Color.black);
            }

            g2.setStroke(dashed);
            g2.setColor(Color.red);

            //draw red rectangle around selected item
            if (selectedItem instanceof Txt) {
                Txt txt = (Txt) selectedItem;
                Rectangle r = txt.getRect(g2);
                g2.fillRect(r.x, r.y, rect_size, rect_size);
                g2.fillRect((r.x + r.width) - rect_size, r.y, rect_size,
                        rect_size);
                g2.fillRect((r.x + r.width) - rect_size, (r.y + r.height)
                        - rect_size, rect_size, rect_size);
                g2.fillRect(r.x, (r.y + r.height) - rect_size, rect_size,
                        rect_size);
            }
            if (selectedItem instanceof Rect) {
                Rect rr = (Rect) selectedItem;
                Rectangle r = rr.getRect();
                g2.fillRect(r.x, r.y, rect_size, rect_size);
                g2.fillRect((r.x + r.width) - rect_size, r.y, rect_size,
                        rect_size);
                g2.fillRect((r.x + r.width) - rect_size, (r.y + r.height)
                        - rect_size, rect_size, rect_size);
                g2.fillRect(r.x, (r.y + r.height) - rect_size, rect_size,
                        rect_size);
            }

            if (selectedItem instanceof Img) {
                Img img = (Img) selectedItem;
                Rectangle r = img.getBounds();
                g2.fillRect(r.x, r.y, rect_size, rect_size);
                g2.fillRect((r.x + r.width) - rect_size, r.y, rect_size,
                        rect_size);
                g2.fillRect((r.x + r.width) - rect_size, (r.y + r.height)
                        - rect_size, rect_size, rect_size);
                g2.fillRect(r.x, (r.y + r.height) - rect_size, rect_size,
                        rect_size);
            }

            if (selectedItem instanceof Oval) {
                Oval oo = (Oval) selectedItem;
                Rectangle r = oo.getRect();
                g2.fillRect(r.x, r.y, rect_size, rect_size);
                g2.fillRect((r.x + r.width) - rect_size, r.y, rect_size,
                        rect_size);
                g2.fillRect((r.x + r.width) - rect_size, (r.y + r.height)
                        - rect_size, rect_size, rect_size);
                g2.fillRect(r.x, (r.y + r.height) - rect_size, rect_size,
                        rect_size);
            }

            if (selectedItem instanceof WBLine) {
                WBLine line = (WBLine) selectedItem;
                g2.fillRect(line.x1 - (rect_size / 2), line.y1
                        - (rect_size / 2), rect_size, rect_size);
                g2.fillRect(line.x2 - (rect_size / 2), line.y2
                        - (rect_size / 2), rect_size, rect_size);
            }

            /*
             This is intentionally commented by David Wafula...needs clarification
             from Nik...this is due to changes made on this method.
             //note: images will always be drawn on the top layer
             //would fix by making ClipArt extend Item but it requires
             //an ImageObserver to paint.
             drawImages(tmp);
             if (tooltip) {
             tooltipIcon.paint(tmp, this);
             }

             g.drawImage(backbuffer, 0, 0, this);
             }

             */
        }

    }

    /**
     * commits a given tool...by basically sending to the server
     * @param x1 int
     * @param y1 int
     * @param x2 int
     * @param y2 int
     * @param fill boolean
     */
    private void commitStroke(int x1, int y1, int x2, int y2, boolean fill) {
        if (!connected) {
            return;
        }

        int x; // Top-left corner, width, and height.
        int y; // Top-left corner, width, and height.
        int w; // Top-left corner, width, and height.
        int h; // Top-left corner, width, and height.

        if (x2 >= x1) { // x1 is left edge
            x = x1;
            w = x2 - x1;
        } else { // x2 is left edge
            x = x2;
            w = x1 - x2;
        }

        if (y2 >= y1) { // y1 is top edge
            y = y1;
            h = y2 - y1;
        } else { // y2 is top edge.
            y = y2;
            h = y1 - y2;
        }

        switch (brush) {
        case BRUSH_LINE:
            this.socketList.addItem(new WBLine(x1, y1, x2, y2, colour,
                    clientApplet.strokeWidth));
            break;
        case BRUSH_RECT:
            this.socketList.addItem(new Rect(x, y, w, h, colour, false,
                    clientApplet.strokeWidth));
            break;
        case BRUSH_OVAL:
            this.socketList.addItem(new Oval(x, y, w, h, colour, false,
                    clientApplet.strokeWidth));
            break;
        case BRUSH_RECT_FILLED:
            this.socketList.addItem(new Rect(x, y, w, h, colour, true,
                    clientApplet.strokeWidth));
            break;
        case BRUSH_OVAL_FILLED:
            logger.finest("Oval filled");
            this.socketList.addItem(new Oval(x, y, w, h, colour, true,
                    clientApplet.strokeWidth));
            break;
        case BRUSH_TEXT:
            int size = Integer.parseInt((String) clientApplet.fontSizeField
                    .getSelectedItem());
            int style = Font.PLAIN;
            if (clientApplet.boldButton.isSelected()) {
                style = Font.BOLD;
            }
            if (clientApplet.italicButton.isSelected()) {
                style = Font.ITALIC;
            }
            if (clientApplet.boldButton.isSelected()
                    && clientApplet.italicButton.isSelected()) {
                style = Font.BOLD | Font.ITALIC;
            }
            this.socketList.addItem(new Txt(x, y, colour, textField.getText(),
                    new Font((String) clientApplet.fontNamesField
                            .getSelectedItem(), style, size),
                    clientApplet.underButton.isSelected()));
            break;
        }
    }

    /**
     * this draws current item...though probably temporarily
     * @param g Graphics
     */
    private void drawStroke(Graphics2D g) {
        int x1 = startX;
        int y1 = startY;
        int x2 = prevX;
        int y2 = prevY;

        // g.setXORMode(getBackground());
        g.setStroke(new BasicStroke(clientApplet.strokeWidth));
        g.setColor(colour);

        int x; // Top-left corner, width, and height.
        int y; // Top-left corner, width, and height.
        int w; // Top-left corner, width, and height.
        int h; // Top-left corner, width, and height.

        if (x2 >= x1) { // x1 is left edge
            x = x1;
            w = x2 - x1;
        } else { // x2 is left edge
            x = x2;
            w = x1 - x2;
        }

        if (y2 >= y1) { // y1 is top edge
            y = y1;
            h = y2 - y1;
        } else { // y2 is top edge.
            y = y2;
            h = y1 - y2;
        }

        switch (brush) {
        case BRUSH_PEN:
            if (penVector != null) {
                for (int i = 0; i < penVector.size(); i++) {
                    WBLine line = penVector.elementAt(i);
                    g.drawLine(line.x1, line.y1, line.x2, line.y2);
                }
            }
            break;
        case BRUSH_LINE:
            g.drawLine(x1, y1, x2, y2);
            break;
        case BRUSH_RECT:
            g.drawRect(x, y, w, h);
            break;
        case BRUSH_OVAL:
            g.drawOval(x, y, w, h);
            break;
        case BRUSH_RECT_FILLED:
            g.fillRect(x, y, w, h);
            break;
        case BRUSH_OVAL_FILLED:
            g.fillOval(x, y, w, h);
            break;
        case BRUSH_TEXT:
            Graphics2D g2 = (Graphics2D) g;
            g2.setColor(colour);
            String txt = textField.getText();
            int size = Integer.parseInt((String) clientApplet.fontSizeField
                    .getSelectedItem());
            int style = Font.PLAIN;
            if (clientApplet.boldButton.isSelected()) {
                style = Font.BOLD;
            }
            if (clientApplet.italicButton.isSelected()) {
                style = Font.ITALIC;
            }
            if (clientApplet.boldButton.isSelected()
                    && clientApplet.italicButton.isSelected()) {
                style = Font.BOLD | Font.ITALIC;
            }

            Font font = new Font((String) clientApplet.fontNamesField
                    .getSelectedItem(), style, size);
            boolean underLine = clientApplet.underButton.isSelected();
            if (txt.length() > 0) {
                AttributedString as = new AttributedString(txt);
                as.addAttribute(TextAttribute.FONT, font);
                if (underLine) {
                    as.addAttribute(TextAttribute.UNDERLINE,
                            TextAttribute.UNDERLINE_ON);
                }
                TextLayout tl = new TextLayout(as.getIterator(), g2
                        .getFontRenderContext());
                tl.draw(g2, x2, y2);
            }
            break;
        }
    }

    /**
     * Changes the brush type that the user is drawing with
     * @param i index number of the brush type
     */
    public void changeBrush(int i) {
        if (!drawingEnabled) {
            return;
        }
        brush = i;
        statusBar.setText("Brush: " + brushName[brush]);
    }

    private void changeBrush() {
        if (++brush > 8) {
            brush = 0;
        }
        statusBar.setText("Brush: " + brushName[brush]);
    }

    /**
     * Handler for color chooser changes
     * @param e ChangeEvent
     */
    public void stateChanged(ChangeEvent e) {
        DefaultColorSelectionModel temp = (DefaultColorSelectionModel) e
                .getSource();
        colour = temp.getSelectedColor();
    }

    /**
     * Handler for the mouse being pressed
     * @param e MouseEvent
     */
    public void mousePressed(MouseEvent e) {
        int button = e.getButton();
        if (dragging == true) {
            return;
        }

        if (button == MouseEvent.BUTTON1) {
            if (drawingEnabled) {
                prevX = startX = e.getX();
                prevY = startY = e.getY();

                if (brush == BRUSH_MOVE) {
                    selected = null;
                    selectedItem = null;
                    Enumeration en = this.socketList.elements();
                    int tempIndex = 0;
                    while (en.hasMoreElements()) {
                        Item tmp = (Item) en.nextElement();
                        if (tmp instanceof Txt) {
                            Txt txt = (Txt) tmp;
                            if (txt.contains(startX, startY, graphics2D)) {
                                selected = tmp;
                                selectedItem = selected;
                                selectedIndex = tempIndex;

                                clientApplet.boldButton.setSelected(false);
                                clientApplet.italicButton.setSelected(false);
                                clientApplet.underButton.setSelected(false);

                                clientApplet.underButton.setSelected(txt
                                        .isUnderlined());

                                Font f = txt.getFont();
                                clientApplet.fontNamesField.setSelectedItem(f
                                        .getFamily());
                                clientApplet.fontSizeField.setSelectedItem(f
                                        .getSize()
                                        + "");

                                int style = f.getStyle();
                                if (style == Font.BOLD) {
                                    clientApplet.boldButton.setSelected(true);
                                }
                                if (style == Font.ITALIC) {
                                    clientApplet.italicButton.setSelected(true);
                                }

                                setCursor(Cursor
                                        .getPredefinedCursor(Cursor.MOVE_CURSOR));
                                break;
                            }
                        } else if (tmp instanceof Oval) {
                            Rectangle bounds = tmp.getBounds();
                            if (bounds.contains(startX, startY)) {
                                selected = tmp;
                                selectedItem = selected;
                                selectedIndex = tempIndex;
                                setCursor(Cursor
                                        .getPredefinedCursor(Cursor.MOVE_CURSOR));

                                int xx = bounds.x;
                                int yy = bounds.y;
                                int ww = bounds.width;
                                int hh = bounds.height;
                                Rectangle r1 = new Rectangle((xx + ww) - 20,
                                        yy, 20, 20);
                                Rectangle r2 = new Rectangle((xx + ww) - 20,
                                        (yy + hh) - 20, 20, 20);

                                last_w = xx + ww;
                                initW = ww;
                                last_h = yy + hh;
                                initH = hh;

                                if (r1.contains(e.getPoint())) {
                                    setCursor(Cursor
                                            .getPredefinedCursor(Cursor.NE_RESIZE_CURSOR));
                                    last_w = xx + ww;
                                    initW = ww;
                                }
                                if (r2.contains(e.getPoint())) {
                                    setCursor(Cursor
                                            .getPredefinedCursor(Cursor.SE_RESIZE_CURSOR));
                                }
                                break;
                            }
                        } else {
                            if (tmp.contains(startX, startY)) {
                                selected = tmp;
                                selectedItem = selected;
                                selectedIndex = tempIndex;
                                setCursor(Cursor
                                        .getPredefinedCursor(Cursor.MOVE_CURSOR));

                                if (selectedItem instanceof WBLine) {
                                    WBLine line = (WBLine) selectedItem;
                                    init_x2 = line.x2;
                                    init_y2 = line.y2;
                                    init_x1 = line.x1;
                                    init_y1 = line.y1;

                                    Rectangle r1 = new Rectangle(line.x1 - 5,
                                            line.y1 - 5, 10, 10);
                                    Rectangle r2 = new Rectangle(line.x2 - 5,
                                            line.y2 - 5, 10, 10);

                                    if (r1.contains(e.getPoint())) {
                                        setCursor(Cursor
                                                .getPredefinedCursor(Cursor.NE_RESIZE_CURSOR));
                                    }
                                    if (r2.contains(e.getPoint())) {
                                        setCursor(Cursor
                                                .getPredefinedCursor(Cursor.SE_RESIZE_CURSOR));
                                    }
                                } else {
                                    Rectangle bounds = selected.getBounds();
                                    int xx = bounds.x;
                                    int yy = bounds.y;
                                    int ww = bounds.width;
                                    int hh = bounds.height;
                                    Rectangle r1 = new Rectangle(
                                            (xx + ww) - 20, yy, 20, 20);
                                    Rectangle r2 = new Rectangle(
                                            (xx + ww) - 20, (yy + hh) - 20, 20,
                                            20);

                                    last_w = xx + ww;
                                    initW = ww;
                                    last_h = yy + hh;
                                    initH = hh;

                                    if (r1.contains(e.getPoint())) {
                                        setCursor(Cursor
                                                .getPredefinedCursor(Cursor.NE_RESIZE_CURSOR));
                                        last_w = xx + ww;
                                        initW = ww;
                                    }
                                    if (r2.contains(e.getPoint())) {
                                        setCursor(Cursor
                                                .getPredefinedCursor(Cursor.SE_RESIZE_CURSOR));
                                    }
                                    break;
                                }
                            }
                        }
                        tempIndex++;
                    }
                } else if (brush != BRUSH_PEN) {
                    //          bg.setXORMode(getBackground());
                } else {
                    penVector = new Vector<WBLine>();
                    penVector.addElement(new WBLine(startX, startY, startX,
                            startY, colour, clientApplet.strokeWidth));
                }
                if (brush == BRUSH_TEXT) {
                    if (popup.isVisible()) {
                        popup.setVisible(false);
                    }
                    textField.setText("");
                    Font f = getSelectedFont();
                    textField.setFont(f);
                    FontMetrics metrics = graphics2D.getFontMetrics(f);

                    int hgt = metrics.getHeight();
                    popup.setPopupSize(100, hgt);
                    popup
                            .show(this, e.getX(), e.getY()
                                    - textField.getHeight());
                    textField.requestFocus();
                }
                dragging = true;
            } else {
                statusBar.setText("You don't have a drawing token");
            }
        }
        if (button == MouseEvent.BUTTON2) {
            changeBrush();
        }

        /**
         * allow modifying of existing text through right click
         */
        if (button == MouseEvent.BUTTON3) {
            if (drawingEnabled) {
                selected = null;
                Enumeration en = this.socketList.elements();
                int tempIndex = 0;
                while (en.hasMoreElements()) {
                    Item tmp = (Item) en.nextElement();
                    if (tmp.contains(startX, startY)) {
                        selected = tmp;
                        selectedIndex = tempIndex;
                        tempIndex++;
                        break;
                    }
                }
                if (editPopup.isVisible()) {
                    editPopup.setVisible(false);
                }
                if (selectedItem instanceof Txt) {
                    Txt txt = (Txt) selectedItem;
                    Font f = txt.getFont();
                    editTextField.setFont(f);
                    FontMetrics metrics = graphics2D.getFontMetrics(f);

                    int hgt = metrics.getHeight();
                    int adv = metrics.stringWidth(txt.getContent());
                    popup.setPopupSize(100, hgt);

                    Dimension size = new Dimension(adv + 2, hgt + 2);
                    editTextField.setText(txt.getContent());
                    editPopup.setPopupSize(size);

                    if (txt.contains(e.getX(), e.getY(), graphics2D)) {
                        editPopup.show(this, e.getX(), e.getY()
                                - editTextField.getHeight());
                    }
                    editTextField.requestFocus();
                }
            }
        }
        repaint();
    }

    private Font getSelectedFont() {
        int size = Integer.parseInt((String) clientApplet.fontSizeField
                .getSelectedItem());
        int style = Font.PLAIN;
        if (clientApplet.boldButton.isSelected()) {
            style = Font.BOLD;
        }
        if (clientApplet.italicButton.isSelected()) {
            style = Font.ITALIC;
        }
        if (clientApplet.boldButton.isSelected()
                && clientApplet.italicButton.isSelected()) {
            style = Font.BOLD | Font.ITALIC;
        }
        return new Font((String) clientApplet.fontNamesField.getSelectedItem(),
                style, size);
    }

    /**
     * Returns the user associated with this instance of the whiteboard
     * @return User
     */
    public User getUser() {
        return user;
    }

    /**
     * STILL BUGS IN THIS; new instances of Client Applet don't recognize previous token assignments
     * must be overridden
     * @param usr MouseEvent
     */
    public void changeToken(User usr) {
        if (0 == user.getFirstName().compareTo(usr.getFirstName())) {
            user.setToken(usr.hasToken());
            brushPanel.setTokenIcon(user.hasToken());
        }

        boolean tokenPred = brushPanel.getTokenIconValue();
        drawingEnabled = tokenPred;
        brush = BRUSH_PEN;
        brushPanel.penButton.setSelected(true);

        Vector<User> users = socketList.getUsers();
        Vector<String> userNames = new Vector<String>();
        for (int i = 0; i < users.size(); i++) {
            userNames.add(users.get(i).getFirstName());
        }

        int index = userNames.indexOf(usr.getFirstName());
        DefaultListModel dlm = (DefaultListModel) ((JList) userList.getList())
                .getModel();

        userList.setListModel(new DefaultListModel());
        logger
                .fine("User " + usr.getFirstName() + " has a token? "
                        + usr.hasToken());

        if (usr.hasToken()) {
            // dlm.setElementAt(new JListItem(((User)users.elementAt(index)).getName(), Color.YELLOW), index);
            dlm.setElementAt(new JListItem(usr.getFirstName(), Color.YELLOW), index);
        } else {
            dlm.setElementAt(new JListItem(usr.getFirstName(), Color.WHITE), index);
        }
        userList.setListModel(dlm);
        //user.setToken(tokenPred);
        userList.validate();
    }

    /**
     * Handles the mouse release event
     * @param e MouseEvent
     */
    public void mouseReleased(MouseEvent e) {
        logger.finest("Brush: " + brush + " Brush Image: " + BRUSH_IMAGE);
        if ((brush == BRUSH_IMAGE) && tooltip) {
            this.socketList.uploadFile(tooltipIcon);
            /* image and its location have been sent to server.
             this client is still going to get the "display image" packet.
             simple & safe: tell client to stop drawing the image until the server
             gives it back.  there will be a weird lag though so this is probably a temporary
             solution.
             also: user might think his request didn't go through, tries to place another image,
             then his original image shows up, then two seconds later he's got two images.
             */
            tooltip = false;
            tooltipIcon = null;
            dragging = false;
            return;
        }

        if ((dragging == false) || (e.getButton() != MouseEvent.BUTTON1)) {
            return;
        }

        dragging = false;

        if (drawingEnabled) {
            if (brush == BRUSH_MOVE) {
                if (selected != null) {
                    if (this.getCursor() == Cursor
                            .getPredefinedCursor(Cursor.MOVE_CURSOR)) {

                        if (!(selectedItem instanceof WBLine)) {
                            Item newItem = selected.getTranslated(prevX
                                    - startX, prevY - startY);
                            this.socketList.modifyItem(new ModifyItemPacket(
                                    selectedIndex, newItem, ""), true);
                        }
                    }
                    if ((this.getCursor() == Cursor
                            .getPredefinedCursor(Cursor.NE_RESIZE_CURSOR))
                            || (this.getCursor() == Cursor
                                    .getPredefinedCursor(Cursor.SE_RESIZE_CURSOR))) {

                        if (!(selectedItem instanceof WBLine)) {
                            int changeW = e.getX() - last_w;
                            int changeH = e.getY() - last_h;
                            int newW = initW + changeW;
                            int newH = initH + changeH;

                            if ((newW > 10) && (newH > 10)) {
                                selected.setSize(newW, newH);
                                this.socketList.modifyItem(
                                        new ModifyItemPacket(selectedIndex,
                                                selected, ""), liveDrag);
                            }
                        }
                    }
                }
            } else if (brush != BRUSH_PEN) {
                commitStroke(startX, startY, prevX, prevY, true);
            } else {
                this.socketList.addItem(new Pen(penVector, colour,
                        clientApplet.strokeWidth));
                penVector.removeAllElements();
                penVector = null;
            }
        } else {
            statusBar.setText("You don't have a drawing token");
        }
        repaint();
    }

    /**
     * Handles the mouse dragging events
     * @param e MouseEvent
     */
    public void mouseDragged(MouseEvent e) {
        if (dragging == false) {
            return;
        }

        int x = e.getX();
        int y = e.getY();
        if (drawingEnabled) {
            if (brush == BRUSH_PEN) {
                penVector.addElement(new WBLine(prevX, prevY, x, y, colour,
                        clientApplet.strokeWidth));
            } else if (brush == BRUSH_MOVE) {
                if (selected != null) {
                    if (this.getCursor() == Cursor
                            .getPredefinedCursor(Cursor.MOVE_CURSOR)) {
                        if (selectedItem instanceof WBLine) {
                            WBLine line = (WBLine) selected;
                            int w = e.getX() - startX;
                            int h = e.getY() - startY;
                            line.x1 = (init_x1 + w);
                            line.y1 = (init_y1 + h);
                            line.x2 = (init_x2 + w);
                            line.y2 = (init_y2 + h);
                            this.socketList.modifyItem(new ModifyItemPacket(
                                    selectedIndex, line, ""), liveDrag);
                        } else {
                            Item newItem = selected.getTranslated(x - startX, y
                                    - startY);
                            selectedItem = newItem;
                            this.socketList.modifyItem(new ModifyItemPacket(
                                    selectedIndex, newItem, ""), liveDrag);
                        }
                    }

                    if ((this.getCursor() == Cursor
                            .getPredefinedCursor(Cursor.NE_RESIZE_CURSOR))
                            || (this.getCursor() == Cursor
                                    .getPredefinedCursor(Cursor.SE_RESIZE_CURSOR))) {
                        if (selectedItem instanceof WBLine) {
                            WBLine line = (WBLine) selectedItem;
                            if ((this.getCursor() == Cursor
                                    .getPredefinedCursor(Cursor.NE_RESIZE_CURSOR))) {
                                line.x1 = (e.getX());
                                line.y1 = (e.getY());
                            }
                            if ((this.getCursor() == Cursor
                                    .getPredefinedCursor(Cursor.SE_RESIZE_CURSOR))) {
                                line.x2 = (e.getX());
                                line.y2 = (e.getY());
                            }
                            this.socketList.modifyItem(new ModifyItemPacket(
                                    selectedIndex, line, ""), liveDrag);
                        } else {
                            int changeW = e.getX() - last_w;
                            int changeH = e.getY() - last_h;
                            int newW = initW + changeW;
                            int newH = initH + changeH;
                            if ((newW > 10) && (newH > 10)) {
                                selected.setSize(newW, newH);
                                this.socketList.modifyItem(
                                        new ModifyItemPacket(selectedIndex,
                                                selected, ""), liveDrag);
                            }
                        }
                    }
                }
            }
        } else {
            statusBar.setText("You don't have a drawing token");
        }

        prevX = x;
        prevY = y;
        repaint();
    }

    /**
     * Handles the update events
     * @param ue UpdateEvent
     */
    public void updateOccurred(UpdateEvent ue) {
        repaint();
    }

    /**
     * "Overrides" the abstract method in interface MouseListener
     * @param e MouseEvent
     */
    public void mouseMoved(MouseEvent e) {
        if ((selected != null) && !(selected instanceof Txt)) {
            setCursor(Cursor.getPredefinedCursor(Cursor.MOVE_CURSOR));

            Rectangle bounds = selected.getBounds();
            int xx = bounds.x;
            int yy = bounds.y;
            int ww = bounds.width;
            int hh = bounds.height;
            Rectangle r1 = new Rectangle((xx + ww) - 10, yy, 10, 10);
            Rectangle r2 = new Rectangle((xx + ww) - 10, (yy + hh) - 10, 10, 10);

            last_w = xx + ww;
            initW = ww;
            last_h = yy + hh;
            initH = hh;

            if (r1.contains(e.getPoint())) {
                setCursor(Cursor.getPredefinedCursor(Cursor.NE_RESIZE_CURSOR));
                last_w = xx + ww;
                initW = ww;
            } else if (r2.contains(e.getPoint())) {
                setCursor(Cursor.getPredefinedCursor(Cursor.SE_RESIZE_CURSOR));
            } else {
                setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
            }
        }

        // moving an image around before you've placed it on the canvas
        if (tooltip) {
            tooltipIcon.setLocation(e.getX(), e.getY());
            repaint();
        }
    }

    /**
     * "Overrides" the abstract method in interface MouseListener
     * @param e MouseEvent
     */
    public void mouseEntered(MouseEvent e) {
    }

    /**
     * "Overrides" the abstract method in interface MouseListener
     * @param e MouseEvent
     */
    public void mouseExited(MouseEvent e) {
    }

    /**Image implementation summary.
     * User clicks "Insert Image" button, chooses a file.
     * As he drags this image around the canvas, it is stored as ClipArt tooltipIcon.
     * There is a boolean tooltip which indicates whether there is currently
     * a "tooltip" image, but testing tooltipIcon == null should also work.
     * When user left-clicks, it commits the image to the canvas.  tooltip and tooltipIcon
     * are set to false and null, and a message is sent to the SocketList.
     * Eventually the client will receive a ClipArt back from the Server, which it adds
     * to Vector<ClipArt> images, which is rendered every repaint.
     * ClipArtS are not ItemS.  As a result Clear and Undo do not impact images yet.
     */
    public void chooseImage() {
        final JFileChooser fc = new JFileChooser();
        fc.addChoosableFileFilter(new ImageFilter());
        fc.setAcceptAllFileFilterUsed(false);

        //In response to a button click:
        int returnVal = fc.showOpenDialog(this);
        if (returnVal == JFileChooser.APPROVE_OPTION) {
            File file = fc.getSelectedFile();
            //create the image you will drag around before officially placing the image
            tooltipIcon = new ClipArt(new ImageIcon(file.getAbsolutePath()),
                    new Point(width, height));
            tooltip = true;
        } else {
            logger.fine("Open command cancelled by user.\n");
        }
        return;
    }

    /**
     * MouseListener implementation.
     * @param e MouseEvent
     */
    public void mouseClicked(MouseEvent e) {
        if (e.getClickCount() == 2) {
            if (drawingEnabled) {
                if (brush == BRUSH_MOVE) {
                    selected = null;
                    if (selected != null) {
                        if (popup.isVisible()) {
                            popup.setVisible(false);
                        }
                        if (selected != null) {
                            if (selected instanceof Txt) {
                                Txt txt = (Txt) selected;

                                textField.setText(txt.getContent());
                                popup.show(this, e.getX(), e.getY()
                                        - textField.getHeight());
                                textField.requestFocus();
                            }
                        }
                    }
                }
            } else {
                statusBar.setText("You don't have a drawing token");
            }
        }
    }

    //class that makes sure you can only choose image files to upload
    private class ImageFilter extends FileFilter {

        public final static String jpeg = "jpeg";

        public final static String jpg = "jpg";

        public final static String gif = "gif";

        //Get the extension of a file.
        private String getExtension(File f) {
            String ext = null;
            String s = f.getName();
            int i = s.lastIndexOf('.');
            if ((i > 0) && (i < (s.length() - 1))) {
                ext = s.substring(i + 1).toLowerCase();
            }
            return ext;
        }

        //Accept all directories and all gif, jpg
        public boolean accept(File f) {
            if (f.isDirectory()) {
                return true;
            }

            String extension = getExtension(f);
            if (extension != null) {
                if (extension.equals(gif) || extension.equals(jpeg)
                        || extension.equals(jpg)) {
                    return true;
                } else {
                    return false;
                }
            }
            return false;
        }

        //The description of this filter
        public String getDescription() {
            return "Images (jpeg,jpg,gif)";
        }
    }

}
