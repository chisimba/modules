/**
 * 	$Id: VotingGraph.java,v 1.3 2007/01/19 16:38:51 adrian Exp $
 * 
 *  Copyright (C) GNU/GPL AVOIR 2007
 * 
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.realtime.whiteboard.client;

import java.awt.Canvas;
import java.awt.Graphics;
import java.util.Vector;

/**
 * Class that displays a graph of a poll's results
 */
@SuppressWarnings("serial")
public class VotingGraph extends Canvas {
    private Vector<Integer> data;
    private Vector<Double> v;
    private static final double HEIGHT_RATIO = .8;
    private static final double WIDTH_RATIO = .8;
    
    /**
     * Constructor
     * @param data The poll results to be graphed
     */
    public VotingGraph(Vector<Integer> data) {
        this.data = data;
        v = new Vector<Double>();
        Integer cap = data.get(0);
        for(int lcv=1;lcv<data.size();lcv++) {
            Integer datum = data.get(lcv);
            if(datum == null)
                v.add(new Double(0.0));
            else v.add(new Double(datum/cap));
        }
        repaint();
    }
    
    /**
     * Update method to paint the graph onto a Graphics object
     * @param g The Graphics object on which to display the graph
     */
    public void update(Graphics g) {
        paint(g);
    }
    
    /**
     * Describes how the graph is drawn based on the supplied poll results
     * @param g Graphics object to draw the graph on
     */
    //FEATURE need to show the choice strings with graph
    public void paint(Graphics g) {
        int width = getSize().width-1;
        int height = getSize().height-1;
        int widthAdj = (int)(width* WIDTH_RATIO);
        int heightAdj = (int)(height*HEIGHT_RATIO);
        int topBuffer,bottomBuffer,leftBuffer,rightBuffer;
        topBuffer = bottomBuffer = (int)(heightAdj * .1);
        leftBuffer = rightBuffer = (int)(widthAdj * .1);
        widthAdj = widthAdj - leftBuffer - rightBuffer;
        double spaceBetween= 0.5; //space between two graphs is spaceBetween*graphHeight
        int roomH = heightAdj-topBuffer-bottomBuffer;
        double unitsNeeded = (1+spaceBetween)*(v.size()-1)+1;
        double unitSize = roomH/unitsNeeded;
        int roomW = widthAdj -leftBuffer -rightBuffer;
        int topLeftW = (width-widthAdj)/2;
        int topLeftH = (height-heightAdj)/2;
        g.setColor(java.awt.Color.black);
        double startingHeight = topLeftH+topBuffer;
        for(int lcv=0;lcv<v.size();lcv++) {
            int widthBar =(int)(((Double)v.get(lcv))*roomW);
            g.fillRect(topLeftW+leftBuffer,(int)startingHeight,widthBar,(int)unitSize);
            double percNum = (Double)v.get(lcv);
            String percString;
            if(percNum >= 1.0) {
                percString = "100%";
            } else if (percNum <= 0.0) {
                percString = "0%";
            } else {
                percString = String.valueOf(percNum);
                percString+="00";
                int decIndex = percString.indexOf(".");
                percString = percString.substring(decIndex+1,decIndex+3)+"%";
            }
            //FIX: the +5,10,etc needs to be scaled (should be centered)
            //FIX: 100% leaks over edge
            g.drawString(percString,topLeftW+leftBuffer+widthBar+5,(int)startingHeight+13);
            startingHeight+=unitSize;
            startingHeight+=unitSize*spaceBetween;
        }
        g.setColor(java.awt.Color.red);
        g.drawRect(topLeftW,topLeftH,widthAdj,heightAdj);
    }
}