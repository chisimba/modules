/**
 *  $Id: AddWindowFrame.java,v 1.4 2007/01/17 11:03:02 adrian Exp $
 * 
 *  Copyright (C) GNU/GPL AVOIR 2007
 *  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.realtime.whiteboard.client;

import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.GridLayout;
import javax.swing.JTextField;
import javax.swing.JButton;

/**
 * Adds a new window to the user interface
 */
@SuppressWarnings("serial")
public class AddWindowFrame extends JPanel {
    private JLabel emptyLabel, url, title;

    private JTextField jf1, jf2;

    private JButton submit, close;

    /**
     * Constructor
     */
    public AddWindowFrame() {
	emptyLabel = new JLabel("Create a new Window: ");
	this.setLayout(new GridLayout(4, 2));
	this.add(emptyLabel);
	this.add(new JLabel());
	url = new JLabel("URL: ");
	title = new JLabel("Title: ");
	this.add(url);
	jf1 = new JTextField("http://localhost");
	jf1.setRequestFocusEnabled(true);
	jf2 = new JTextField("Default Title");
	close = new JButton("Close");

	this.add(jf1);
	this.add(title);
	this.add(jf2);
	submit = new JButton("Submit");
	this.add(submit);
	this.add(close, "Close window");
    }

    /**
     * Submits the url and title information for the new window
     * 
     * @return JButton submit
     */
    public JButton getSubmitButton() {
	return submit;
    }

    /**
     * Returns the url that the window displays
     * 
     * @return String from (JTextArea) jf1
     */
    public String getURL() {
	return jf1.getText();
    }

    /**
     * Returns the button used to close the window
     * 
     * @return JButton
     */
    public JButton getCloseButton() {
	return close;
    }

    /**
     * Returns the title of the window
     * 
     * @return String from (JTextField) jf2
     */
    public String getTitle() {
	return jf2.getText();
    }
}
