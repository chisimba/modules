/**
 * 	$Id: AdminPanel.java,v 1.7 2007/03/05 15:38:28 adrian Exp $
 * 
 *  Copyright (C) GNU/GPL AVOIR 2007
 * 
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.realtime.whiteboard.client;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.StringTokenizer;
import java.util.Vector;
import java.util.logging.Logger;

import javax.swing.JTabbedPane;

import avoir.realtime.User;
import avoir.realtime.UserLevel;

/**
 * A panel that holds the interface for the voting utility
 */
@SuppressWarnings("serial")
public class AdminPanel extends JTabbedPane implements ActionListener {

    private static Logger logger = Logger.getLogger(AdminPanel.class.getName());

    private MainWindow mainWindow;

    private SocketList socketList;

    private AddWindowFrame addWindowFrame;

    private CreateVoteFrame voteFrame;

    private SubmitVoteFrame submitVoteFrame;

    private VotingGraph votingGraph;

    /**
     * Constructor
     * @param mw The MainWindow that this AdminPanel will be placed in
     * @param sl SocketList
     * @param u User
     */
    public AdminPanel(MainWindow mw, SocketList sl, User u) {
        this.socketList = sl;
        this.mainWindow = mw;
        if (u.getLevel() == UserLevel.ADMIN) {
            addWindowFrame = new AddWindowFrame();
            addWindowFrame.getSubmitButton().addActionListener(this);
            addWindowFrame.getCloseButton().addActionListener(this);
            this.add(addWindowFrame, "Browser");
            voteFrame = new CreateVoteFrame();
            voteFrame.getButton().addActionListener(this);
            this.add(voteFrame, "Voting");
        }
    }

    /**
     * Handler for the voting-related actions
     * @param ae ActionEvent
     */
    public void actionPerformed(ActionEvent ae) {
        Object source = ae.getSource();
        if (addWindowFrame != null
                && source.equals(addWindowFrame.getCloseButton())) {
            int index = mainWindow.getSelectedIndex() - 1;
            mainWindow.close(index);
        }
        if (addWindowFrame != null
                && source == addWindowFrame.getSubmitButton()) {
            String url = addWindowFrame.getURL();
            String title = addWindowFrame.getTitle();
            mainWindow.add(url, title);
        } else if (voteFrame != null && ae.getSource() == voteFrame.getButton()) {
            if (voteFrame.getOptions().equals("")) {
                logger.warning("Please specify voter options");
            } else
                socketList.createVote(voteFrame.getQuestion(), this
                        .parseOptions(voteFrame.getOptions()), voteFrame
                        .getSeconds()
                        * SubmitVoteFrame.ONE_SECOND);
        }
    }

    private Vector<String> parseOptions(String answers) {
        Vector<String> options = new Vector<String>();
        StringTokenizer st = new StringTokenizer(answers);
        while (st.hasMoreTokens()) {
            options.add((String) st.nextToken("|"));
        }
        return options;
    }

    /**
     * Creates a new poll
     * @param question Question asked
     * @param options Answer choices
     * @param time Length of the poll in seconds
     */
    public void newVote(String question, Vector<String> options, int time) {
        //this is probably unneccessary because right now you can't start a vote while another
        //vote is taking place
        if (submitVoteFrame != null) {
            this.remove(submitVoteFrame);
        }
        //removes the current voting graph if one exists.
        //FIX: might want to capture its index, then insert the new SubmitVoteFrame into
        //that index if we add other types of dynamic windows to admin panel
        if (votingGraph != null) {
            this.remove(votingGraph);
        }
        submitVoteFrame = new SubmitVoteFrame(question, options, socketList
                .getUsers().size(), time, socketList);
        this.add(submitVoteFrame, "Vote!");
        if (voteFrame != null)
            voteFrame.getButton().setEnabled(false);
    }

    /**
     * Closes the current voting session, returns the results
     * @param results The results of the poll
     */
    public void closeVote(Vector<Integer> results) {
        //close the voting frame
        submitVoteFrame.closeVote(results);
        this.remove(submitVoteFrame);
        if (voteFrame != null)
            voteFrame.getButton().setEnabled(true);
        //crate a graphing frame
        votingGraph = new VotingGraph(results);
        this.add(votingGraph, "Graph");
        //give focus to the new graphing frame
        this.setSelectedComponent(votingGraph);
    }

    /**
     * Updates the totals on the current vote
     * @param status The vote
     */
    public void updateVote(int status) {
        submitVoteFrame.updateVote(status);
    }
}
