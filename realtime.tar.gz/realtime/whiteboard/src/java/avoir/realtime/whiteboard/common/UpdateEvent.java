/**
 * 	$Id: UpdateEvent.java,v 1.2 2007/01/15 10:01:56 adrian Exp $
 * 
 *  Copyright (C) GNU/GPL AVOIR 2007
 * 
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.realtime.whiteboard.common;
/**
 * Event Object used for updating
 */
@SuppressWarnings("serial")
public class UpdateEvent extends java.util.EventObject {
    /**
     * A new browser window is added
     */
    public static final int BROWSER_ADD = 0;
    /**
     * Switch browser windows
     */
    public static final int BROWSER_CHANGE = 1;
    /**
     * Take a link to a new browser window
     */
    public static final int BROWSER_LINK = 2;
    /**
     * Change drawing object (brush)
     */
    public static final int TOKEN_CHANGE = 3;
    /**
     * Repaint the whiteboard
     */
    public static final int WB_REPAINT = 4;
    /**
     * new chat item added
     */
    public static final int CHAT_ADD = 5;
    /**
     * clients have changed
     */
    public static final int USERLIST_CHANGE = 6;
    /**
     * Start a new poll
     */
    public static final int VOTE_CREATE = 7;
    /**
     * Sumbit a vote
     */
    public static final int VOTE_SUBMIT = 8;
    /**
     * Update a poll
     */
    public static final int VOTE_UPDATE = 9;
    /**
     * Polls have closed
     */
    public static final int VOTE_FINISHED = 10;
    /**
     * Close a browser window
     */
    public static final int BROWSER_CLOSE = 11;
    /**
     * ClipArt update event
     */
    public static final int IMAGE = 12;
    /**
     * The type of update to occur
     */
    public int code = -1;
    /**
     * Data associated with the update
     */
    public Object data = null;
    
    /**
     * Constructor calls super
     * @param source Source of UpdateEvent
     * @param code The type of update to occur (index)
     */
    public UpdateEvent(Object source, int code) {
        super(source);
        this.code = code;
    }
    /**
     * Creates an UpdateEvent with associated data
     * @param source Source of the update
     * @param code int code for update type
     * @param data Object data associated with the update
     */
    public UpdateEvent(Object source, int code, Object data) {
        super(source);
        this.code = code;
        this.data = data;
    }
    
    /**
     * Constructor
     * @param source Source of the update
     * @param data attached data
     */
    public UpdateEvent(Object source, Object data) {
        super(source);
        this.data = data;
    }
    
    /**
     * Returns the int code for the type of update
     * @return int update type
     */
    public int getCode() {
        return this.code;
    }
    
    /**
     * Returns data (if any) that is associated with an UpdateEvent
     * @return Object data that was sent along with an UpdateEvent
     */
    public Object getData() {
        return this.data;
    }
}