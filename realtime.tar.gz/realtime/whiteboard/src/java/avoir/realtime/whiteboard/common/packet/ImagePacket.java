/**
 * 	$Id: ImagePacket.java,v 1.3 2007/05/11 13:45:58 davidwaf Exp $
 * 
 *  Copyright (C) GNU/GPL AVOIR 2007
 * 
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.realtime.whiteboard.common.packet;

import java.awt.Point;

import javax.swing.ImageIcon;

import avoir.realtime.whiteboard.common.ClipArt;
import avoir.realtime.whiteboard.common.item.Img;
/**
 * Packet used to communicate ClipArt events
 */
@SuppressWarnings("serial")
public class ImagePacket implements WBPacket {
    private Img image;

    private Point loc;

    private String url;

    /**
     * Packet used to communicate events regarding a ClipArt object
     * @param c ClipArt
     */
    public ImagePacket(Img image) {
        this.image = image;
        //this.loc = c.getPoint();
    }

    public ImagePacket(String url) {
        this.url = url;
    }

    /**
     * Returns the Image in this packet
     * @return Image
     */
    public Img getImage() {
        return image;
    }

    public String getImageURL() {
        return url;
    }

    /**
     * Returns the location of the ClipArt in this packet
     * @return Point
     */
    public Point getPoint() {
        return loc;
    }
}