/**
 * 	$Id: InitPacket.java,v 1.2 2007/01/15 10:00:57 adrian Exp $
 * 
 *  Copyright (C) GNU/GPL AVOIR 2007
 * 
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.realtime.whiteboard.common.packet;

import java.util.Stack;
import java.util.Vector;

import avoir.realtime.whiteboard.common.ClipArt;
import avoir.realtime.whiteboard.common.item.ItemList;


/**
 * The initial packet in a ServerThread, info about the current state at
 * the time of the Thread's initialization
 */
 @SuppressWarnings("serial")
public class InitPacket implements WBPacket{
    ItemList list;
    Stack<String> windowStack;
    Stack<String> windowTitleStack;
    Vector<ClipArt> images;
    int curWindow;
    
    
    //serialization test
    public InitPacket() {
        
    }

    /**
     * Constructor
     * @param images Vector of ClipArt objects
     * @param list list of Items in the communications stream between the clients and server
     * @param windowStack Stack of windows in the GUI
     * @param windowTitleStack Stack of window titles in the GUI
     * @param curWindow the window selected to be displayed
     */
    public InitPacket(ItemList list,Stack<String> windowStack,Stack<String> windowTitleStack,Vector<ClipArt> images,int curWindow) {
        // these stacks don't have whiteboard
        this.windowStack = windowStack;
        this.windowTitleStack = windowTitleStack;
        this.list = list;
        this.images = images;
        this.curWindow = curWindow;
    }
    
    /**
     * Returns the Vector of ClipArt in this packet
     * @return Vector<ClipArt>
     */
    public Vector<ClipArt> getImages() {
        return images;
    }
    
    /**
     * Returns the stack of window titles
     * @return Stack
     */
    public Stack<String> getWindowTitleStack() {
        return windowTitleStack;
    }
    
    /**
     * Returns the ItemList of Items in use
     * @return ItemList
     */
    public ItemList getList() {
        return list;
    }
    
    /**
     * returns the Stack of windows in the GUI
     * @return Stack
     */
    public Stack<String> getWindowStack() {
        return windowStack;
    }
    
    /**
     * returns the window that is currently selected by the user
     * @return int window
     */
    public int getCurWindow() {
        return curWindow;
    }
}
