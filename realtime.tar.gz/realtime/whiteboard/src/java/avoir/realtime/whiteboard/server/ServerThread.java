/**
 *  $Id: ServerThread.java,v 1.13 2007/05/18 10:38:44 davidwaf Exp $
 *
 *  Copyright (C) GNU/GPL AVOIR 2007
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.realtime.whiteboard.server;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Stack;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.Timer;

import avoir.realtime.User;
import avoir.realtime.whiteboard.common.ClipArt;
import avoir.realtime.whiteboard.common.UpdateEvent;
import avoir.realtime.whiteboard.common.Vote;
import avoir.realtime.whiteboard.common.WhiteboardConstants;
import avoir.realtime.whiteboard.common.item.Item;
import avoir.realtime.whiteboard.common.item.ItemList;
import avoir.realtime.whiteboard.common.item.Img;
import avoir.realtime.whiteboard.common.packet.AckPacket;
import avoir.realtime.whiteboard.common.packet.ImgPathPacket;
import avoir.realtime.whiteboard.common.packet.AddItemPacket;
import avoir.realtime.whiteboard.common.packet.BrowserClosePacket;
import avoir.realtime.whiteboard.common.packet.BrowserUpdatePacket;
import avoir.realtime.whiteboard.common.packet.ChatPacket;
import avoir.realtime.whiteboard.common.packet.ClearPacket;
import avoir.realtime.whiteboard.common.packet.ClientPacket;
import avoir.realtime.whiteboard.common.packet.ImagePacket;
import avoir.realtime.whiteboard.common.packet.InitPacket;
import avoir.realtime.whiteboard.common.packet.ModifyItemPacket;
import avoir.realtime.whiteboard.common.packet.QuitPacket;
import avoir.realtime.whiteboard.common.packet.ReplaceItemPacket;
import avoir.realtime.whiteboard.common.packet.TokenPacket;
import avoir.realtime.whiteboard.common.packet.UndoPacket;
import avoir.realtime.whiteboard.common.packet.VotePacket;
import avoir.realtime.whiteboard.common.packet.VoteResultPacket;
import avoir.realtime.whiteboard.common.packet.WBPacket;

/**
 * Handles communications for the server, to and from the clients Processes
 * packets from client actions and broadcasts these updates
 */
@SuppressWarnings("serial")
public class ServerThread extends Thread {

    private static Logger logger = Logger.getLogger(ServerThread.class
            .getName());

    private static ItemList list = new ItemList();

    private static ClientList clients = new ClientList();

    private static String tName;

    private static Stack<String> windowStack = new Stack<String>();

    private static Stack<String> windowTitleStack = new Stack<String>();

    private static int curWindow = 0;

    private static Vote vote = null;

    private static Timer voteTimer;

    // annoying: if you place the same image twice, it saves it twice.
    // could improve to make an array of ImageIcons and an array of
    // int iconIndex and Points
    private static Vector<ClipArt> images = new Vector<ClipArt>();

    private Socket socket;

    /**
     * Constructor accepts connections
     * 
     * @param socket The socket
     */
    public ServerThread(Socket socket) {
        tName = getName();
        logger.finest("Server " + tName + " accepted connection from "
                + socket.getInetAddress() + WhiteboardConstants.SERVER_EOL);
        this.socket = socket;
    }

    /**
     * Run method initializes Object input and output Streams Calls dispatch
     * method which calls process messsages which processes incoming packets The
     * information carried by these packets is rebroadcasted to all of the
     * clients
     */
    public void run() {
        try {
            ObjectOutputStream out = new ObjectOutputStream(
                    new BufferedOutputStream(socket.getOutputStream()));
            out.flush();

            ObjectInputStream in = new ObjectInputStream(
                    new BufferedInputStream(socket.getInputStream()));
            dispatch(in, out);
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error in Server " + tName, e);
        } finally {
            logger.fine("Server " + tName + " disconnected from "
                    + socket.getInetAddress() + WhiteboardConstants.SERVER_EOL);
            try {
                socket.close();
            } catch (IOException e) {
                logger.log(Level.WARNING, "Error closing socket", e);
            }
        }
    }

    @SuppressWarnings("unchecked")
    void dispatch(ObjectInputStream oIn, ObjectOutputStream oOut)
            throws IOException, ClassNotFoundException {
        try {
            synchronized (clients) {
                // oOut.writeObject(new InitPacket(list.clone(),
                // (Stack<String>)windowStack.clone(),
                // (Stack<String>)windowTitleStack.clone(),curWindow));

                AckPacket ack = (AckPacket) oIn.readObject();
                User user = ack.getUser();
                clients.addElement(oOut, user);
                broadcastMsg(new ClientPacket((Vector<User>) clients.users
                        .clone()));
                oOut.writeObject(new InitPacket(list, windowStack,
                        windowTitleStack, images, curWindow));
                oOut.flush();

            }
            processMsgs(oIn);
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error in dispatch", e);
        } finally {
            clients.removeElement(oOut);
            broadcastMsg(new ClientPacket((Vector<User>) clients.users.clone()));
        }
    }

    void processMsgs(ObjectInputStream objectIn) throws IOException,
            ClassNotFoundException {
        while (true) {
            Object obj = objectIn.readObject();
            WBPacket packet = null;
            if (obj instanceof WBPacket) {
                packet = (WBPacket) obj;
            }
            if (packet != null) {
                logger.finest("Server " + tName + " received "
                        + packet.getClass().getName() + " from "
                        + socket.getInetAddress()
                        + WhiteboardConstants.SERVER_EOL);

                if (packet instanceof QuitPacket) {
                    logger.finest("QUIT PACKET PROCESS");
                    break;
                } else if (packet instanceof ModifyItemPacket) {
                    int index = ((ModifyItemPacket) packet).getIndex();
                    Item item = ((ModifyItemPacket) packet).getItem();
                    list.set(index, item);
                    broadcastMsg((ModifyItemPacket) packet);
                } else if (packet instanceof AddItemPacket) {
                    Item item = ((AddItemPacket) packet).getElement();
                    synchronized (clients) {
                        Integer id = list.addElement(item);
                        broadcastMsg(new AddItemPacket(id, item));
                    }
                } else if (packet instanceof ReplaceItemPacket) {
                    Integer oldID = ((ReplaceItemPacket) packet).getID();
                    Item item = ((ReplaceItemPacket) packet).getElement();

                    synchronized (clients) {
                        Integer id = list.replaceElement(oldID, item);
                        if (id != null) {
                            broadcastMsg(new ReplaceItemPacket(oldID, id, item));
                        }
                    }
                } else if (packet instanceof ChatPacket) {
                    synchronized (clients) {
                        broadcastMsg(packet);
                    }
                } else if (packet instanceof TokenPacket) {
                    synchronized (clients) {
                        broadcastMsg(packet);
                    }
                } else if (packet instanceof VotePacket) {
                    int code = ((VotePacket) packet).getCode();
                    if (code == UpdateEvent.VOTE_CREATE) {
                        if (vote == null) {
                            Vector<String> options = ((VotePacket) packet)
                                    .getOptions();
                            vote = new Vote(clients.size(), options);

                            int time = ((VotePacket) packet).getTime();
                            voteTimer = new Timer(time, new ActionListener() {
                                public void actionPerformed(ActionEvent evt) {
                                    if (vote == null) {
                                        return;
                                    }

                                    WBPacket packet = new VoteResultPacket(vote
                                            .getCurrent(), vote.getResults());
                                    vote = null;
                                    voteTimer.stop();

                                    synchronized (clients) {
                                        broadcastMsg(packet);
                                    }
                                }
                            });
                            voteTimer.start();
                        } else {
                            return;
                        }
                    } else if (code == UpdateEvent.VOTE_SUBMIT) {
                        if (vote == null) {
                            return;
                        }

                        vote.add(((VotePacket) packet).getAnswer());

                        if (vote.isDone()) {
                            packet = new VoteResultPacket(vote.getCurrent(),
                                    vote.getResults());
                            vote = null;
                            voteTimer.stop();
                        } else {
                            packet = new VoteResultPacket(vote.getCurrent());
                        }
                    }

                    synchronized (clients) {
                        broadcastMsg(packet);
                    }
                } else if (packet instanceof ClearPacket) {
                    list.resetList();

                    synchronized (clients) {
                        broadcastMsg(new ClearPacket());
                    }
                } else if (packet instanceof UndoPacket) {
                    list.removeLastElement();

                    synchronized (clients) {
                        broadcastMsg(new UndoPacket());
                    }
                } else if (packet instanceof BrowserUpdatePacket) {
                    if (((BrowserUpdatePacket) packet).getType() == UpdateEvent.BROWSER_ADD) {
                        windowStack
                                .add(((BrowserUpdatePacket) packet).getURL());
                        windowTitleStack.add(((BrowserUpdatePacket) packet)
                                .getTitle());
                    } else if (((BrowserUpdatePacket) packet).getType() == UpdateEvent.BROWSER_CHANGE) {
                        curWindow = ((BrowserUpdatePacket) packet).getIndex();
                    } else if (((BrowserUpdatePacket) packet).getType() == UpdateEvent.BROWSER_LINK) {
                        curWindow = ((BrowserUpdatePacket) packet).getIndex();
                        windowStack.setElementAt(((BrowserUpdatePacket) packet)
                                .getURL(), curWindow - 1);
                    }

                    synchronized (clients) {
                        broadcastMsg(packet);
                    }
                } else if (packet instanceof ImgPathPacket) {
                    logger.finest("Received image icon string..");
                    ImgPathPacket imgPacket = (ImgPathPacket) packet;
                    String str1 = imgPacket.getImagePath();
                    javax.swing.ImageIcon icon = new javax.swing.ImageIcon(str1
                            .trim());
                    Img actualImgPacket = new Img(icon, 10, 10, (int) icon
                            .getIconWidth(), (int) icon.getIconHeight());
                    synchronized (clients) {
                        broadcastMsg(new AddItemPacket(new Integer(-1),
                                actualImgPacket));
                    }

                    logger.finest("Finished writing image..");
                } else if (packet instanceof BrowserClosePacket) {
                    windowStack
                            .remove(((BrowserClosePacket) packet).getIndex());
                    windowTitleStack.remove(((BrowserClosePacket) packet)
                            .getIndex());

                    synchronized (clients) {
                        broadcastMsg(packet);
                    }
                } else {
                    logger.warning("Server " + tName
                            + " received unrecognised packet: " + packet
                            + WhiteboardConstants.SERVER_EOL);
                }
            }
        }
    }

    static void broadcastMsg(WBPacket packet) {
        logger.fine("Server " + tName + " broadcasting "
                + packet.getClass().getName() + " to " + clients.size()
                + " recipients" + WhiteboardConstants.SERVER_EOL);

        for (int i = 0; i < clients.size(); i++) {
            ObjectOutputStream out = (ObjectOutputStream) clients.elementAt(i);
            try {
                out.writeObject(packet);
                out.flush();
            } catch (IOException e) {
                logger.log(Level.SEVERE, "Error broadcasting in Server "
                        + tName, e);
            }
        }
    }
}
