/**
 * 	$Id: UserList.java,v 1.7 2007/05/02 09:50:12 davidwaf Exp $
 * 
 *  Copyright (C) GNU/GPL AVOIR 2007
 * 
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.realtime.whiteboard.client;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Vector;
import java.util.logging.Logger;

import javax.swing.DefaultListModel;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import avoir.realtime.User;

/**
 * Stores a list of Users using the Realtime application
 */
@SuppressWarnings("serial")
public class UserList extends JPanel implements ListSelectionListener,
        MouseListener {

    private static Logger logger = Logger.getLogger(UserList.class.getName());

    private JList theList;

    private JScrollPane listScroll;

    private JLabel listHeader;

    private SocketList socketList;

    /**
     * Constructor
     * @param sl SocketList
     */
    public UserList(SocketList sl) {
        this.socketList = sl;
        this.setLayout(new GridLayout(2, 0));
        listHeader = new JLabel("Connected Users:");
        this.add(listHeader);
        theList = new JList();
        theList.setCellRenderer(new CellRenderer());
        theList
                .setSelectionMode(javax.swing.ListSelectionModel.SINGLE_INTERVAL_SELECTION);
        theList.setLayoutOrientation(javax.swing.JList.VERTICAL);
        theList.setVisibleRowCount(-1);
        theList.addListSelectionListener(this);
        theList.addMouseListener(this);
        listScroll = new JScrollPane();
        listScroll.setViewportView(theList);
        this.add(listScroll);
        this.update();
    }

    /**
     * Returns the JList of Users
     * @return JList
     */
    public JList getList() {
        return theList;
    }

    /**
     * Sets the ListModel of this UserList
     * @param model DefaultListModel
     */
    public void setListModel(DefaultListModel model) {
        theList.setModel(model);
    }

    public void clear() {
        if (theList != null) {
            theList.removeAll();
        }
    }

    /**
     * Updates the list of Users
     */
    public void update() {
        DefaultListModel myModel = new DefaultListModel();
        Vector<User> users = socketList.getUsers();

        for (int i = 0; i < users.size(); i++) {
            //probably creating too many new list items here
            if (users.get(i).hasToken()) {
                logger.finest(users.get(i).getFullName() + " has a token "
                        + users.get(i).hasToken());
                myModel.addElement(new JListItem(((User) users.elementAt(i))
                        .getFullName(), Color.YELLOW));
            } else {
                logger.finest(users.get(i).getFullName() + " has a token "
                        + users.get(i).hasToken());
                myModel.addElement(new JListItem(((User) users.elementAt(i))
                        .getFullName(), Color.WHITE));
            }
        }
        theList.setModel(myModel);
        this.validate();
    }

    /**
     * If a user in the list is double clicked, it flips their token status and highlights their name in yellow
     * @param e MouseEvent
     */
    public void mouseClicked(MouseEvent e) {
        if (e.getClickCount() == 2) {
            Vector<User> users = socketList.getUsers();
            int index = theList.locationToIndex(e.getPoint());
            socketList.giveToken(users.get(index));
            this.validate();
        }
    }

    /**
     * MouseListener implementation.
     * @param e MouseEvent
     */
    public void mouseExited(MouseEvent e) {
    }

    /**
     * MouseListener implementation.
     * @param e MouseEvent
     */
    public void mouseEntered(MouseEvent e) {
    }

    /**
     * MouseListener implementation.
     * @param e MouseEvent
     */
    public void mousePressed(MouseEvent e) {
    }

    /**
     * MouseListener implementation.
     * @param e MouseEvent
     */
    public void mouseReleased(MouseEvent e) {
    }

    /**
     * handler for when the user selected in the list has changed
     * @param lse ListSelectionEvent
     */
    public void valueChanged(ListSelectionEvent lse) {
        /*if(theList.getSelectedIndex() >= 0 && !clickStarted) {
         Vector<User> users = sl.getUsers();
         DefaultListModel theModel = (DefaultListModel)theList.getModel();
         lastSelected = theList.getSelectedIndex();
         String name = ((JListItem)theModel.getElementAt(theList.getSelectedIndex())).getValue();
         //sl.giveToken(users.get(lastSelected));
         clickStarted = true;
         } else clickStarted = false;   */
    }
}
