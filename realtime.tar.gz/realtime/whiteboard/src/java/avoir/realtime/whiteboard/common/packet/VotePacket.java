/**
 * 	$Id: VotePacket.java,v 1.2 2007/01/15 10:00:57 adrian Exp $
 * 
 *  Copyright (C) GNU/GPL AVOIR 2007
 * 
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.realtime.whiteboard.common.packet;

import java.util.Vector;

import avoir.realtime.whiteboard.common.UpdateEvent;
/**
 * Packet used to carry information about a voting session
 */
@SuppressWarnings("serial")
public class VotePacket implements WBPacket {
    private String question;
    private String user;
    private Vector<String> options;
    private int answer;
    private int code;
    private int time;
    
    /**
     * Constructor used to create a new poll
     * @param options Vector of choices
     * @param question Question
     * @param time length of time remaining in the poll (seconds)
     * @param user String user who submitted the poll
     */
    public VotePacket(String question,Vector<String> options, int time,String user) {
        this.question = question;
        this.time = time;
        this.user = user;
        this.options = options;
        this.code = UpdateEvent.VOTE_CREATE;
    }
    
    /**
     * Constructor used to cast a vote
     * @param answer what the user voted
     * @param user user casting the vote
     */
    public VotePacket(int answer,String user) {
        this.user = user;
        this.answer = answer;
        this.code = UpdateEvent.VOTE_SUBMIT;
    }
    
    /**
     * Returns the Vector of poll choices
     * @return Vector options
     */
    public Vector<String> getOptions() {
        return this.options;
    }
    
    /**
     * Returns the posed question
     * @return String question
     */
    public String getQuestion() {
        return this.question;
    }
    
    /**
     * Returns the amount of time that the polls are open for
     * @return int length of poll
     */
    public int getTime() {
        return this.time;
    }
    
    /**
     * Returns the code for the status of the vote
     * @return int status code
     */
    public int getCode() {
        return this.code;
    }
    
    /**
     * Returns the answer supplied by a polled client
     * @return int voter answer
     */
    public int getAnswer() {
        return this.answer;
    }
}