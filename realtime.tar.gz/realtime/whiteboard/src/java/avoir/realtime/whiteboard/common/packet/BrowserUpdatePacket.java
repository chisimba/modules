/**
 * 	$Id: BrowserUpdatePacket.java,v 1.2 2007/01/15 10:00:57 adrian Exp $
 * 
 *  Copyright (C) GNU/GPL AVOIR 2007
 * 
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.realtime.whiteboard.common.packet;

import avoir.realtime.whiteboard.common.UpdateEvent;

/**
 * Packet used for notification of changes in a BrowserWindow
 */
@SuppressWarnings("serial")
public class BrowserUpdatePacket implements WBPacket {
    private int type;
    private int index;
    private String url;
    private String title;
    
    /**
     * Constructor
     * @param index tab index (int)
     */
    public BrowserUpdatePacket(int index) {
        this.type = UpdateEvent.BROWSER_CHANGE;
        this.index = index;
        this.url = null;
        this.title = null;
    }
    
    /**
     * Constructor
     * @param url String url
     * @param title String title of BrowserWindow
     */
    public BrowserUpdatePacket(String url,String title) {
        this.type = UpdateEvent.BROWSER_ADD;
        this.url = url;
        this.title = title;
        this.index = -1;
    }
    
    /**
     * Constructor
     * @param url String url
     * @param index tab index (int)
     */
    public BrowserUpdatePacket(String url, int index) {
        this.type = UpdateEvent.BROWSER_LINK;
        this.url = url;
        this.index = index;
    }
    
    /**
     * Returns the title of the BrowserWindow
     * @return String title
     */
    public String getTitle() {
        return this.title;
    }
    
    /**
     * Return type, which stores what kind of UpdateEvent this BrowserUpdatePacket resulted from
     * @return type
     */
    public int getType() {
        return this.type;
    }
    
    /**
     * Returns the index variable
     * @return int index (tab number)
     */
    public int getIndex() {
        return this.index;
    }
    
    /**
     * Returns the url displayed in the BrowserWindow
     * @return String url
     */
    public String getURL() {
        return this.url;
    }
}

