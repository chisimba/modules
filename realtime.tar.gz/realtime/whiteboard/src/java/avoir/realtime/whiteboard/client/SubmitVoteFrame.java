/**
 * 	$Id: SubmitVoteFrame.java,v 1.3 2007/01/19 16:38:51 adrian Exp $
 * 
 *  Copyright (C) GNU/GPL AVOIR 2007
 * 
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.realtime.whiteboard.client;

import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.Timer;

import avoir.realtime.whiteboard.common.ClientVote;

/**
 * Creates a panel with a ballot form
 */
@SuppressWarnings("serial")
public class SubmitVoteFrame extends JPanel implements ActionListener {
    /**
     * Second = 1000 ms
     */
    public final static int ONE_SECOND = 1000;
    /**
     * minutes = 60s
     */
    public final static int ONE_MINUTE = ONE_SECOND * 60;
    private JProgressBar progressBar;
    private Timer timer;
    private JButton buttonSubmit;
    private ClientVote task;
    private JTextArea taskOutput;
    private int timeRemaining;
    private SocketList sl;
    private Vector<String> options;
    private JRadioButton[] choiceButtons;
    private ButtonGroup group;
    
    /**
     * Constructor for the ballot panel
     * @param question String Question
     * @param options Vector of poll choices
     * @param size Number of expected votes (Users polled)
     * @param time Length of time the vote will last for (seconds)
     * @param sl SocketList
     */
    public SubmitVoteFrame(String question,Vector<String> options,int size,int time,SocketList sl) {
        this.options = options;
        this.sl = sl;
        timeRemaining = time;
        task = new ClientVote(size);
        //Create the demo's UI.
        progressBar = new JProgressBar(0, size);
        progressBar.setValue(0);
        progressBar.setStringPainted(true);
        
        taskOutput = new JTextArea(5, 20);
        taskOutput.setMargin(new Insets(5,5,5,5));
        taskOutput.setEditable(false);
        taskOutput.setCursor(null);
        taskOutput.setText(question);
        
        buttonSubmit = new JButton("Submit Vote");
        buttonSubmit.addActionListener(this);
        JPanel panel = new JPanel();
        JPanel choices = new JPanel();
        choices.setLayout(new java.awt.GridLayout(options.size()+1,0));
        choices .add(new JLabel(question));
        group = new ButtonGroup();
        choiceButtons = new JRadioButton[options.size()];
        for(int lcv=0;lcv<options.size();lcv++) {
            choiceButtons[lcv] = new JRadioButton(options.get(lcv));
            group.add(choiceButtons[lcv]);
            choices.add(choiceButtons[lcv]);
        }
        panel.setLayout(new java.awt.GridLayout(2,0));
        panel.add(choices);
        JPanel submitPanel = new JPanel();
        submitPanel.add(progressBar);
        submitPanel.add(buttonSubmit);
        panel.add(submitPanel);
        this.setLayout(new java.awt.BorderLayout());
        this.add(panel,java.awt.BorderLayout.PAGE_START);
        this.add(new JScrollPane(taskOutput), java.awt.BorderLayout.CENTER);
        
        //Create a timer.
        timer = new Timer(ONE_SECOND, new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                progressBar.setValue(task.getCurrent());
                progressBar.setString(task.getCurrent()+"/"+task.getCap());
                int minutes = timeRemaining/(ONE_MINUTE);
                int seconds = timeRemaining/ONE_SECOND - minutes*60;
                String str;
                if(seconds < 10)
                    str = minutes+":0"+seconds;
                else str = minutes+":"+seconds;
                taskOutput.setText(str);
                if(timeRemaining > 0)
                    timeRemaining -= ONE_SECOND;
            }
        });
        timer.start();
    }
    
    /**
     * Returns what choice a voter picked
     * @return int '1' for choice 'A', int '2' for choice 'B'
     */
    public int getSelection() {
        for(int lcv=0;lcv<options.size();lcv++) {
            if(choiceButtons[lcv].isSelected()) {
                return lcv+1;
            }
        }
        return -1;
    }
    
    /**
     * Updates the current status of the vote count and progress
     * @param status Status int
     */
    public void updateVote(int status) {
        task.update(status);
        progressBar.setValue(task.getCurrent());
        progressBar.setString(task.getCurrent()+"/"+task.getCap());
    }
    
    /**
     * Handler for the voting actions
     * @param ae ActionEvent
     */
    public void actionPerformed(ActionEvent ae) {
        if(this.getSelection() == -1) return;
        for(int lcv=0;lcv<options.size();lcv++) {
            choiceButtons[lcv].setEnabled(false);
        }
        buttonSubmit.setEnabled(false);
        sl.submitVote(this.getSelection());
    }
    
    /**
     * Closes the polls and prints/displays the tallied results
     * @param v Vector of vote tallies
     */
    public void closeVote(Vector<Integer> v) {
        int status = v.get(0);
        String str="Results:";
        for(int lcv=1;lcv<v.size();lcv++) {
            str+="\nChoice: "+lcv+" Value: ";
            if(v.get(lcv) != null)
                str+=v.get(lcv);
            else str+= "0";
            
        }
        taskOutput.setText(str);
        task.update(status);
        progressBar.setValue(task.getCurrent());
        progressBar.setString(task.getCurrent()+"/"+task.getCap());
        timer.stop();
        buttonSubmit.setEnabled(false);
    }
}