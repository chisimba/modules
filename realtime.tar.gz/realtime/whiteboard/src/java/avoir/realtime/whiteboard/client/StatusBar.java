/**
 * 	$Id: StatusBar.java,v 1.2 2007/01/15 09:57:49 adrian Exp $
 *  
 *  Copyright (C) GNU/GPL AVOIR 2007
 * 
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.realtime.whiteboard.client;

import javax.swing.JTextArea;
import java.awt.Dimension;
import javax.swing.JScrollPane;

/**
 * Class that defines a JTextArea for the Realtime tools to display status messages in
 */
@SuppressWarnings("serial")
public class StatusBar extends JScrollPane {
    JTextArea ta;
    /**
     * Constructor
     * @param textArea The JTextArea that will be displayed in this status bar
     */
    public StatusBar(JTextArea textArea) {
        super(textArea);
        ta = textArea;
        ta.setEditable(false);
        ta.setText("Whiteboard started");
        this.setPreferredSize(new Dimension(500, 19));
        this.setRequestFocusEnabled(false);
        this.createVerticalScrollBar();
        ta.setLineWrap(true);
        ta.setWrapStyleWord(true);
    }
    
    /**
     * Sets the text of the text area in the status bar
     * @param text String text
     */
    public void setText(String text){
        ta.setText(text);
    }
}
