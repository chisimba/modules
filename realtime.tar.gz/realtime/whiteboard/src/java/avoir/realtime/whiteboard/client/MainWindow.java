/**
 * 	$Id: MainWindow.java,v 1.5 2007/03/05 15:39:17 adrian Exp $
 * 
 *  Copyright (C) GNU/GPL AVOIR 2007
 * 
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.realtime.whiteboard.client;

import java.util.Stack;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JTabbedPane;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

import avoir.realtime.User;
import avoir.realtime.UserLevel;

/**
 * The main window for the user interface in the realtime tools applet
 */
@SuppressWarnings("serial")
public class MainWindow extends JTabbedPane implements ChangeListener,
        HyperlinkListener {

    private static Logger logger = Logger.getLogger(MainWindow.class.getName());

    private Vector<Object> windows; //list of browser windows

    private SocketList socketList;

    private User user;

    /**
     * Constructor
     * @param w The Whiteboard object to be added to this window
     * @param sl The SocketList to be used for client/server communications
     * @param u the User
     */
    public MainWindow(Whiteboard w, SocketList sl, User u) {
        super(javax.swing.JTabbedPane.TOP);
        this.user = u;
        this.socketList = sl;
        this.add(w);
        this.windows = new Vector<Object>();
        windows.add(w);
        Stack windowStack = sl.getWindowStack();
        Stack windowTitleStack = sl.getWindowTitleStack();
        for (int lcv = windowStack.size() - 1; lcv >= 0; lcv--) {
            addWindow((String) windowStack.get(lcv), (String) windowTitleStack
                    .get(windowStack.size() - lcv - 1));
        }
        this.changeState(sl.getCurWindow());
        if (UserLevel.ADMIN.equals(u.getLevel())) {
            this.addChangeListener(this);
        }
    }

    /**
     * Begins the process of notifying the server that a user has added a new BrowserWindow to the interface
     * @param url the url to display in the new window
     * @param title The title of hte new window
     */
    public void add(String url, String title) {
        socketList.addBrowserWindow(url, title);
    }

    /**
     * Adds a new BrowserWindow to the MainWindow and makes a call to notify the server
     * @param url String url
     * @param title String title
     */
    public void addWindow(String url, String title) {
        BrowserWindow bw = new BrowserWindow(url);
        if (UserLevel.ADMIN.equals(user.getLevel())) {
            bw.getPage().addHyperlinkListener(this);
        }
        bw.setName(title);
        windows.add(bw);
        this.add(bw);
        this.validate();
    }

    /**
     * Closes a browser window tab
     * @param index index of the window to be closed
     */
    public void closeWindow(int index) {
        if (index >= 0) {
            windows.remove(index + 1);
            this.remove(index + 1);
            this.validate();
        } else {
            logger.finest("Can't delete index: " + index);
        }
    }

    /**
     * Begins the process of notifying the other clients of the browser
     * window closing
     * @param index int
     */

    public void close(int index) {
        if (index >= 0) {
            socketList.closeBrowserWindow(index);
        } else {
            logger.finest("Can't close window with index: " + index);
        }
    }

    /**
     * Brings the window to the foreground
     * @param index window tab index
     */
    public void changeState(int index) {
        this.setSelectedIndex(index);
    }

    /**
     * Abstract method that must be overriden
     * @param e ChangeEvent
     */
    public void stateChanged(ChangeEvent e) {
        socketList.changeBrowserState(this.getSelectedIndex());
    }

    /**
     * Updates the url displayed in a window upon clicking a tab or link
     * @param index the tab index
     * @param url the url to display
     */
    public void clickLink(int index, String url) {
        ((BrowserWindow) windows.get(index)).setPage(url);
    }

    /**
     * Handler for hyperlink events
     * @param event the HyperlinkEvent
     */
    public void hyperlinkUpdate(HyperlinkEvent event) {
        if (event.getEventType() == HyperlinkEvent.EventType.ACTIVATED) {
            try {
                socketList.browserClickLink(event.getURL().toString(), this
                        .getSelectedIndex());
            } catch (Exception e) {
                logger.log(Level.WARNING, "Error activating hyperlink", e);
            }
        }
    }
}
