package avoir.realtime.whiteboard.common.packet;

import avoir.realtime.whiteboard.common.item.Item;

/**
 * <p>Title: Whiteboard</p>
 *
 * <p>Description: This class is used to modify properties of an item, e.g, when
 * the item location,size,color changes</p>
 *
 * <p>Copyright: Copyright (c) 2007</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class ModifyItemPacket implements WBPacket {
  //the position of the item in the list
  int index = 0;
  //who sent the item;
  String user;
  Item item;
  public ModifyItemPacket(int index, Item item, String user) {
    this.index = index;
    this.user = user;
    this.item = item;
  }
  /**
   * returns the index of the item in thid packet
   * @return int
   */
  public int getIndex() {
    return index;
  }
  /**
   * returns the item in the packet
   * @return Item
   */
  public Item getItem() {
    return item;
  }
  /**
   * returns the username of whoever send the packet
   * @return String
   */
  public String getUser() {
    return user;
  }
}
