package avoir.realtime.presentations.client;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JInternalFrame;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.ListCellRenderer;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import avoir.realtime.presentations.common.util.*;

public class Viewer extends JInternalFrame {
    
    ImageIcon slideIcon = Utils.createImageIcon("/icons/slide.gif", "");
    
    private JPanel jContentPane = null;
    
    static Dimension ss = Toolkit.getDefaultToolkit().getScreenSize();
    
    JSplitPane viewerSplitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
    
    Surface surface;
    
    DefaultListModel model = new DefaultListModel();
    
    JList list = new JList(model);
    
    JLabel titleLabel=new JLabel("Slides");
    /**
     * This is the xxx default constructor
     */
    public Viewer(Surface surface) {
        super("Viewer");
        this.surface = surface;
        initialize();
    }
    
    /**
     * This method initializes this
     *
     * @return void
     */
    private void initialize() {
        setResizable(true);
        setMaximizable(true);
        setIconifiable(true);
        this.setFont(new java.awt.Font("Dialog",0,10));
        titleLabel.setFont(new java.awt.Font("Dialog",0,10));
        
        JPanel p = new JPanel();
        p.setLayout(new BorderLayout());
        p.add(titleLabel, BorderLayout.NORTH);
        p.add(new JScrollPane(list), BorderLayout.CENTER);
        
        setSize(680,418);//(ss.width / 8) * 5, (ss.height / 4) * 3);
        double xWidth=((ss.height / 4) * 3);
        
        double divLocation=0.95;
        viewerSplitPane.setLeftComponent(p);
        viewerSplitPane.setDividerLocation(150);
        viewerSplitPane.setRightComponent(new JScrollPane(surface));
        
        JPanel contentPane = getJContentPane();
        contentPane.add(viewerSplitPane, BorderLayout.CENTER);
        this.setContentPane(contentPane);
        
        list.setLayoutOrientation(JList.HORIZONTAL_WRAP);
        list.setCellRenderer(new SlideRenderer());
        list.addListSelectionListener(new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent e) {
                int index = list.getSelectedIndex();
                if (surface != null) {
                    surface.pageNo = index;
                    surface.repaint();
                }
                
            }
        });
        showSlideThumbNails();
        
    }
    
    public void showSlideThumbNails() {
        //
        surface.pageNo = 0;
        list.clearSelection();
        list.removeAll();
        int pages = surface.content.size();
        model.clear();
        for (int i = 0; i < pages; i++) {
            model.addElement(new Integer(i));
        }
        surface.repaint();
    }
    
    /**
     * This method initializes jContentPane
     *
     * @return javax.swing.JPanel
     */
    private JPanel getJContentPane() {
        if (jContentPane == null) {
            jContentPane = new JPanel();
            jContentPane.setLayout(new BorderLayout());
        }
        return jContentPane;
    }
    
    class SlideRenderer extends JLabel implements ListCellRenderer {
        
        public SlideRenderer() {
            setOpaque(true);
            setHorizontalAlignment(LEFT);
            setVerticalAlignment(CENTER);
        }
        
                /*
                 * This method finds the image and text corresponding to the selected
                 * value and returns the label, set up to display the text and image.
                 */
        public Component getListCellRendererComponent(JList list, Object value,
                int index, boolean isSelected, boolean cellHasFocus) {
            // Get the selected index. (The index param isn't
            // always valid, so just use the value.)
            int selectedIndex = ((Integer) value).intValue();
            
            if (isSelected) {
                setBackground(list.getSelectionBackground());
                setForeground(list.getSelectionForeground());
            } else {
                setBackground(list.getBackground());
                setForeground(list.getForeground());
            }
            
            setIcon(slideIcon);
            if (slideIcon != null) {
                setText("Slide " + (selectedIndex + 1));
                setFont(list.getFont());
                
            }
            return this;
        }
        
    }
    
}
