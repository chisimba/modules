/*
 * StartTimePacket.java
 *
 * Created on October 24, 2007, 11:45 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package avoir.realtime.presentations.common.packet;

/**
 *
 * @author dwafula
 */
public class StartTimePacket implements PresentationsPacket{
    String time;
    /** Creates a new instance of StartTimePacket */
    public StartTimePacket(String time) {
        this.time=time;
    }
    
    public String getTime(){
        return time;
    }
}
