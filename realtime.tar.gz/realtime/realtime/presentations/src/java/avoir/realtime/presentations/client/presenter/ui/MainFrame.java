/**
 * Copyright (C) GNU/GPL AVOIR 2007
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 51
 * Franklin St, Fifth Floor, Boston, MA 02110-1301 USA
 */
package avoir.realtime.presentations.client.presenter.ui;

import java.awt.*;
import java.awt.event.*;
import java.util.jar.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.*;
import java.io.*;
import java.applet.*;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.*;
import javax.swing.tree.*;
import javax.media.*;

import avoir.realtime.presentations.client.util.*;
import avoir.realtime.presentations.common.util.*;
import avoir.realtime.presentations.common.packet.*;
import avoir.realtime.presentations.client.presenter.*;
import avoir.realtime.presentations.client.*;
import avoir.realtime.presentations.client.sound.*;

//import avoir.realtime.video.transmitter.gui.*;
//import avoir.realtime.video.transmitter.engine.*;

public class MainFrame extends JApplet implements ActionListener {

    ImageIcon logoIcon = Utils.createImageIcon("/icons/logo.jpg", "");
    static boolean invokedAsApplication = false;
    private static Logger logger = Logger.getLogger(MainFrame.class.getName());
    JPanel contentPane;
    JSplitPane splitPane = new JSplitPane();
    JSplitPane leftSplitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
    JMenuBar menubar = new JMenuBar();
    static Dimension ss = Toolkit.getDefaultToolkit().getScreenSize();
    JToolBar toolbar = new JToolBar(JToolBar.VERTICAL);
    static Dimension frameWidth = ss;
    public Surface surface;
    JTabbedPane tabbedPane = new JTabbedPane();
    AudioCapture voicePanel = new AudioCapture();
    public JLabel statusBar = new JLabel();
    ImageIcon slideIcon = Utils.createImageIcon("/icons/slide.gif", "");
    DefaultListModel model = new DefaultListModel();
    JList list = new JList(model);
    JLabel titleLabel = new JLabel("");
    public Connector connector;
    static String host = "xlocalhost";
    static int port = PresentationConstants.DEFAULT_SERVER_PORT;
    String user = "";

    /**
     * This represents the content base path of Chisimba where the uploaded
     * presentation files are stored.
     */
    public static String contentBasePath = ".";
    public JButton saveButton = new JButton("Save Session");
    boolean slideSelected = false;
    JPanel recordingPanel = new JPanel();
    JPanel optionsPanel = new JPanel();
    JToggleButton recordingButton = new JToggleButton(Utils.createImageIcon("/icons/record.png", ""));
    JButton playBackButton = new JButton(Utils.createImageIcon("/icons/play.png", ""));
    Vector recording = new Vector();
    Recorder recorder;
    //JDesktopPane desktop = new JDesktopPane();

    JInternalFrame chatFrame = new JInternalFrame("Chat", true, true, true, true);
    public ChatPanel chatPanel = new ChatPanel();
    JPanel leftPanel = new JPanel();
    JPanel rightPanel = new JPanel();
    JTextArea slidesField=new JTextArea();
    // JMFrame playerWindow=null;

    //CaptureUtil captureUtil=new CaptureUtil();

    ToolBox toolBox = new ToolBox();

    /*    public MainFrame(String host, int port, String contentBasePath,String user) {
        this.host = host;
        this.port = port;
        this.contentBasePath = contentBasePath;
        this.user=user;
        System.out.println("calling init");
        init();
    }*/
    /**
     * Application entry point
     *
     * */
    public static void main(String[] args) {
        invokedAsApplication = true;
        final String[] xargs = args;
        SwingUtilities.invokeLater(new Runnable() {

                    public void run() {
                        System.out.println("started...");
                        host = xargs[0];
                        port = Integer.parseInt(xargs[1]);
                        contentBasePath = xargs[2];
                    /* MainFrame fr = new MainFrame(host, port, contentBasePath,xargs[3]);
                        Dimension ss = Toolkit.getDefaultToolkit().getScreenSize();
                        fr.setLocation((ss.width - fr.getWidth()) / 2, (ss.height - fr.getHeight()) / 2);
                        fr.setVisible(true);
                         System.out.println("visible..."+fr.isVisible()+" "+fr);
                    */
                    /*
                // Create the frame this applet will run in
                Frame appletFrame = new Frame("Presentater Studio");
                
                // The frame needs a layout manager, use the GridLayout to maximize
                // the applet size to the frame.
                appletFrame.setLayout(new GridLayout(1,0));
                
                // Have to give the frame a size before it is visible
                appletFrame.setSize(850,468);
                
                // Make the frame appear on the screen. You should make the frame appear
                // before you call the applet's init method. On some Java implementations,
                // some of the graphics information is not available until there is a frame.
                // If your applet uses certain graphics functions like getGraphics() in the
                // init method, it may fail unless there is a frame already created and
                // showing.
                
                appletFrame.setLocationRelativeTo(null);
                appletFrame.setVisible(true);
                
                
                // Create an instance of the applet
                Applet theApplet = new  MainFrame();
                
                // Add the applet to the frame
                appletFrame.add(theApplet);
                
                // Initialize and start the applet
                theApplet.init();
                theApplet.start();*/

                    }
                });

    }

    /**
     * Component initialization.
     *
     * @throws java.lang.Exception
     */
    public void init() {
        try {

            if (!invokedAsApplication) {
                this.host = getCodeBase().getHost();
                this.port = Integer.parseInt(this.getParameter("port"));
                this.contentBasePath = this.getParameter("contentBasePath");
            }

            surface = new Surface();


            rightPanel.setLayout(new BorderLayout());
            JTabbedPane pp = new JTabbedPane();
            pp.addTab("Slides", new JScrollPane(slidesField));
            rightPanel.add(pp, BorderLayout.SOUTH);

            //  rightPanel.add(new JScrollPane(list),BorderLayout.SOUTH);
            rightPanel.add(surface, BorderLayout.CENTER);

            splitPane.setRightComponent(rightPanel);
            splitPane.setLeftComponent(leftPanel);
            contentPane = (JPanel) getContentPane();
            contentPane.setLayout(new BorderLayout());
            frameWidth = getSize();


            recordingPanel.setBorder(BorderFactory.createTitledBorder("Video"));
            recordingPanel.setLayout(new BorderLayout());
            JPanel pl = new JPanel();
            pl.add(saveButton);
            //pl.add(playBackButton);

            leftPanel.setLayout(new BorderLayout());
            leftPanel.add(new AboutPanel(), BorderLayout.CENTER);
            leftPanel.add(tabbedPane, BorderLayout.SOUTH);


            recordingButton.setSelected(true);
            recordingButton.setToolTipText("Recording Presentation");
            /*Thread t=new Thread(){
                public void run(){
                    Player player=captureUtil.transmitLive();
                    playerWindow=new JMFrame(player,"");
                    JPanel pl=(JPanel)playerWindow.getContentPane();
                    //pl.setPreferredSize(new Dimension(160,120));
                    recordingPanel.add(pl,BorderLayout.CENTER);
                }
            };t.start();
            */
            playBackButton.setEnabled(false);

            leftSplitPane.setTopComponent(optionsPanel);
            leftSplitPane.setBottomComponent(new JScrollPane());


            optionsPanel.setLayout(new BorderLayout());

            optionsPanel.setPreferredSize(new Dimension(100, 200));
            tabbedPane.addTab("Chat", chatPanel);
            //tabbedPane.addTab("Audio", voicePanel);

            menubar.setFont(new Font("Dialog", 0, 10));
            statusBar.setBorder(BorderFactory.createLoweredBevelBorder());

            /* JInternalFrame desktopFrame = new JInternalFrame();
            desktopFrame.setSize((ss.width / 8) * 7, (ss.height / 8) * 7);
            desktopFrame.getContentPane().setLayout(new BorderLayout());
            desktopFrame.getContentPane().add(splitPane, BorderLayout.CENTER);
            desktopFrame.putClientProperty("JInternalFrame.isPalette", Boolean.TRUE);
            desktopFrame.setVisible(true);
            desktop.add(desktopFrame);
            */


            //setTitle("Presenter Studio - Development Version");


            contentPane.add(statusBar, java.awt.BorderLayout.SOUTH);
            contentPane.add(splitPane, java.awt.BorderLayout.CENTER);
            contentPane.add(titleLabel, java.awt.BorderLayout.NORTH);

            setSize((ss.width / 8) * 7, (ss.height / 8) * 7);

            saveButton.addActionListener(new ActionListener() {

                        public void actionPerformed(ActionEvent e) {
                            if (connector != null) {
                                if (connector.sentPacket(createRecordPacket())) {
                                    Utils.msg(("Session saved"));
                                } else {
                                    Utils.err(("Errors occured. Cannot save this session"));
                                }
                            }

                        }
                    });
            list.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
            list.setLayoutOrientation(JList.HORIZONTAL_WRAP);
            list.setCellRenderer(new SlideRenderer());
            list.addListSelectionListener(new ListSelectionListener() {

                        public void valueChanged(ListSelectionEvent e) {
                            int index = list.getSelectedIndex();
                            if (surface != null) {
                                surface.pageNo = index;
                                surface.repaint();
//                                connector.sendSlide();
                                slideSelected = true;
                            }

                        }
                    });

            recordingButton.addActionListener(new ActionListener() {

                        public void actionPerformed(ActionEvent e) {
                            if (!recordingButton.isSelected()) {
                                recorder.stop();
                                recordingButton.setEnabled(false);
                                playBackButton.setEnabled(true);

                            }
                        }
                    });

            playBackButton.addActionListener(new ActionListener() {

                        public void actionPerformed(ActionEvent e) {
                        //                    playBack();
                        }
                    });
            showSlideThumbNails();

            //leftSplitPane.setDividerLocation(150);
            //splitPane.setDividerLocation(150);

            buildMenu();
            addButtons();
            this.setJMenuBar(menubar);
            connect();

        //            this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /*public void createChatFrame() {
        try {
            chatPanel = new ChatPanel(connector, user);
            chatFrame.setSize(ss.width / 4, 200);
            chatFrame.setLocation(30, (ss.height / 4) * 2);
            chatFrame.getContentPane().setLayout(new BorderLayout());
            chatFrame.getContentPane().add(chatPanel, BorderLayout.CENTER);
            chatFrame.setVisible(true);
            chatFrame.setSelected(true);
            desktop.add(chatFrame, new Integer(1));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }*/
    public RecordPacket createRecordPacket() {
        Vector rec = new Vector();
        for (int i = 0; i < recording.size(); i++) {
            Recording r = (Recording) recording.elementAt(i);
            Vector v = new Vector();
            v.addElement(new Integer(r.slideNo));
            v.addElement(new Long(r.getTime()));
            rec.addElement(v);
        }
        return new RecordPacket(rec, contentBasePath);
    }

    public ImageIcon getCurrentSlide() {
        ImageIcon img = null;
        Vector slides = surface.content;
        if (slides.size() > 0) {
            int index = list.getSelectedIndex();
            if (index == -1) {
                index = 0;
            }
            img = (ImageIcon) slides.elementAt(index);
            return img;

        }
        return new ImageIcon();
    }

    public int getCurrentSlideIndex() {
        return list.getSelectedIndex();
    }

    public void setStatusText(String msg, Color color) {
        statusBar.setForeground(color);
        statusBar.setText(msg);
    }

    public void showSlideThumbNails() {
        surface.pageNo = 0;
        list.clearSelection();
        list.removeAll();
        int pages = surface.content.size();
        model.clear();
        for (int i = 0; i < pages; i++) {
            slidesField.append("Slide "+i+"\n");
            model.addElement(new Integer(i));

        }
        surface.repaint();

    }

    class Recorder {

        Toolkit toolkit;
        Timer timer;
        long time = 0;

        public Recorder() {
            toolkit = Toolkit.getDefaultToolkit();
            timer = new Timer();
            timer.schedule(new RecordTask(),
                    0, //initial delay
                    1 * 1000);  //subsequent rate
        }

        public void stop() {
            if (timer != null) {
            //  timer.cancel();
            }
        }

        class RecordTask extends TimerTask {

            public void run() {
                recording.addElement(new Recording(list.getSelectedIndex(), time));
                slideSelected = false;
                time++;
            } // run()

        } //

    } //


    class SlideRenderer extends JLabel implements ListCellRenderer {

        public SlideRenderer() {
            setOpaque(true);
            setHorizontalAlignment(LEFT);
            setVerticalAlignment(CENTER);
        }

        /*
                 * This method finds the image and text corresponding to the selected
                 * value and returns the label, set up to display the text and image.
                 */
        public Component getListCellRendererComponent(JList list, Object value,
                int index, boolean isSelected, boolean cellHasFocus) {
            // Get the selected index. (The index param isn't
            // always valid, so just use the value.)
            int selectedIndex = ((Integer) value).intValue();

            if (isSelected) {
                setBackground(list.getSelectionBackground());
                setForeground(list.getSelectionForeground());
            } else {
                setBackground(list.getBackground());
                setForeground(list.getForeground());
            }

            setIcon(slideIcon);
            if (slideIcon != null) {
                setText("Slide " + (selectedIndex + 1));
                setFont(list.getFont());

            }
            return this;
        }
    }

    private void connect() {
        setStatusText("Connecting to " + host + ": " + port + " ...", Color.RED);
        Thread t = new Thread() {

                    public void run() {
                        // int port = (getParameter("port") == null) ?
                // PresentationConstants.DEFAULT_SERVER_PORT
                // : Integer.parseInt(getParameter("port"));

                //        connector = new Connector(host, port, MainFrame.this, contentBasePath, user);
                        try {
                            if (connector.connect()) {
                                setStatusText("Connected to host: " + host +
                                        " port: " + new Integer(port).toString(), new Color(0, 131, 0));
                                chatPanel.setConnector(connector);
                                chatPanel.setUser(user);

                                showSlideThumbNails();
                                // createChatFrame();
                                //only start recording after connection to the server
                                recorder = new Recorder();
                            } else {
                                Utils.disposeStatusWindow();
                                setStatusText("Error connecting to host: " + host +
                                        " on port: " +
                                        new Integer(port).toString(), Color.RED);
                            }

                        } catch (Exception e) {
                            Utils.disposeStatusWindow();
                            logger.log(Level.WARNING, "Error connecting to host", e);
                        }
                    }
                };
        t.start();

    }

    /**
     * Builds the menu system
     *
     */
    private void buildMenu() {
        JMenu menu = new JMenu("File");
        menu.setFont(new Font("Dialog", 0, 10));
        menu.add(createMenuItem("Chat", "showChat"));
        menu.add(createMenuItem("Connect", "connect"));
        menu.addSeparator();
        menu.add(createMenuItem("Exit", "exit"));
        menubar.add(menu);
        menu = new JMenu("Help");
        menu.setFont(new Font("Dialog", 0, 10));

        menu.add(createMenuItem("About", "about"));

        menubar.add(menu);

    }

    /**
     * Create a menut item
     *
     * @param text :
     *            text of menu
     * @param action:
     *            action command
     * @return
     */
    public JMenuItem createMenuItem(String text, String action) {
        JMenuItem menuItem = new JMenuItem(text);
        menuItem.setFont(new Font("Dialog", 0, 10));
        menuItem.setActionCommand(action);
        menuItem.addActionListener(this);
        return menuItem;
    }

    /**
     * Create a JButton
     *
     * @param icon
     * @param tooltip
     * @param action
     * @param addBg
     * @return
     */
    private JButton createJButton(Icon icon, String tooltip, String action,
            boolean addBg) {
        JButton button = new JButton(icon);

        button.setToolTipText(tooltip);
        button.setActionCommand(action);
        button.setBorderPainted(false);
        button.addActionListener(this);

        return button;
    }

    /**
     * Adds buttons to the toolbar
     *
     */
    private void addButtons() {
        toolbar.add(createJButton(Utils.createImageIcon("/icons/open.gif", ""),
                "Open", "open", false));

    }

    /**
     * Respond to actions
     */
    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("about")) {
            JOptionPane.showMessageDialog(null,
                    "(c)2007 UWC,JKUAT - The AVOIR", "About",
                    JOptionPane.INFORMATION_MESSAGE);
        }
        if (e.getActionCommand().equals("exit")) {
            System.exit(0);
        }
        if (e.getActionCommand().equals("showChat")) {
        //            createChatFrame();
        }
        if (e.getActionCommand().equals("connect")) {
            connect();
        }

    }

    class AboutPanel extends JPanel {

        Image image = logoIcon.getImage();

        public AboutPanel() {
            this.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
            this.setBackground(Color.WHITE);
            setPreferredSize(new Dimension(300, 500));
        }

        public void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            int xx = (getWidth() - image.getWidth(this)) / 2;
            int yy = (getHeight() - image.getHeight(this)) / 2;

            g2.setColor(new Color(0, 131, 0));

            g2.drawImage(image, xx, yy, this);
        }
    }

    class PresentationFile {

        String title;
        String id;
        /** Creates a new instance of Presentation */

        public PresentationFile(String id, String title) {
            this.id = id;
            this.title = title;
        }

        public String getId() {
            return id;
        }

        public String getTitle() {
            return title;
        }

        public String toString() {
            return title;
        }
    }
}
