package avoir.realtime.presentations.common.packet;

import java.util.Vector;

public class PresentationContentPacket implements PresentationsPacket {
	

	private Vector slides = new Vector();

	public PresentationContentPacket(Vector slides) {
		this.slides=slides;
	}

	
	/**
	 * Get the number of pages in the document
	 * 
	 * @return Vector
	 */
	public Vector getSlides() {
		
		return slides;
	}

        /**
         * This will be modified in future to return specific content
         * @return
         */
        public Vector getContent(){
            return slides;
        }
}
