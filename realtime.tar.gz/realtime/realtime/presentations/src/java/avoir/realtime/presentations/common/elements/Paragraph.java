/**
 * Copyright (C) GNU/GPL AVOIR 2007
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 51
 * Franklin St, Fifth Floor, Boston, MA 02110-1301 USA
 */
package avoir.realtime.presentations.common.elements;

public class Paragraph  implements java.io.Serializable{
	double marginLeft;

	double marginRight;

	double indent;

	double marginTop;

	double marginBottom;

	public Paragraph() {
	}

	public String toString() {
		return "Margin Right: " + marginRight + " Margin Left: " + marginLeft
				+ " Margin Top: " + marginTop + " Margin Bottom: "
				+ marginBottom;
	}

	public void setTopMargin(double marginTop) {
		this.marginTop = marginTop;
	}

	public double getTopMargin() {
		return marginTop;
	}

	public void setBottomMargin(double marginBottom) {
		this.marginBottom = marginBottom;
	}

	public double getBottomMargin() {
		return marginBottom;
	}

	public void setLeftMargin(double marginLeft) {
		this.marginLeft = marginLeft;
	}

	public double getLeftMargin() {
		return marginLeft;
	}

	public void setRightMargin(double marginRight) {
		this.marginRight = marginRight;
	}

	public double getRightMargin() {
		return marginRight;
	}

	public void setIndent(double indent) {
		this.indent = indent;
	}

	public double getIndent() {
		return indent;
	}
}
