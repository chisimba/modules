/**
 * Copyright (C) GNU/GPL AVOIR 2007
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 51
 * Franklin St, Fifth Floor, Boston, MA 02110-1301 USA
 */
package avoir.realtime.presentations.client;

import javax.swing.*;
import java.awt.*;
import java.awt.image.*;

import java.util.*;
import java.util.logging.*;

import java.io.File;

public class Surface extends JPanel {

    private static Logger logger = Logger.getLogger(Surface.class.getName());
    protected String text;
    protected float m_nHAlign;
    protected float m_nVAlign;
    protected int baseline;
    protected FontMetrics fm;
    public int pageNo = 0;
    int currentY;
    Color prevColor = Color.black;
    public String msg = "Loading ...";
    public Color color = new Color(0, 131, 0);
    public Vector content = new Vector();
    ImageIcon slide = null;

    public Surface() {
        this.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));

        this.setBackground(Color.white);
    }

    public void setContent(Vector content) {
        this.content = content;
        repaint();
    }

    public void setCurrentSlide(ImageIcon slide) {
        this.slide = slide;
        repaint();
    }

    private void centerString(String msg, Graphics2D g, int xValue, int y) {
        // Get measures needed to center the message
        FontMetrics fm = g.getFontMetrics();

        // How many pixels wide is the string
        int msg_width = fm.stringWidth(msg);

        // How far above the baseline can the font go?
        int ascent = fm.getMaxAscent();

        // How far below the baseline?
        int descent = fm.getMaxDescent();

        int x1 = xValue;
        int x2 = xValue + 650;
        int ss = x2 - x1;
        int dd = (ss + xValue) / 2;
        // Use the string width to find the starting point
        int msg_x = (x2 - x1) / 2 - msg_width / 2;
        //  int msg_x = xValue + xValue+600 / 2 - msg_width / 2;
        g.drawString(msg, msg_x + xValue, y);

    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        if (slide != null) {
            //ImageIcon image = sl(ImageIcon) content.elementAt(pageNo);
            int xx = (getWidth() - slide.getIconWidth()) / 2;
            int yy = (getHeight() - slide.getIconHeight()) / 2;


            g2.drawImage(slide.getImage(), xx, yy, this);
            g2.setColor(Color.RED);
        } else {
            int xxx = (getWidth() - (getWidth() - 20)) / 2;
            int yyy = (getHeight() - (getHeight() - 20)) / 2;
            g2.setFont(new java.awt.Font("Dialog", 1, 18));
            g2.setColor(color);

            centerString(msg, g2, 0, getHeight() / 2);
        }
    }
}
