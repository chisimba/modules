/*
 * Groove.java
 *
 * Created on October 31, 2007, 2:42 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package avoir.realtime.presentations.client.sound;

import javax.swing.*;
import javax.sound.midi.*;
import java.awt.*;

import avoir.realtime.presentations.client.ClientViewer;
import java.util.*;
/**
 *
 * @author dwafula
 */
public class Groove extends JPanel implements MetaEventListener{
    
    final int PROGRAM = 192;
    
    final int NOTEON = 144;
    
    final int NOTEOFF = 128;
    
    int velocity = 100;
    
    public Sequencer sequencer;
    
    public Track track;
     
    String instruments[] =
    
    { "Acoustic bass drum", "Bass drum 1", "Side stick", "Acoustic snare",
      "Hand clap", "Electric snare", "Low floor tom", "Closed hi-hat",
      "High floor tom", "Pedal hi-hat", "Low tom", "Open hi-hat",
      "Low-mid tom", "Hi-mid tom", "Crash cymbal 1", "High tom",
      "Ride cymbal 1", "Chinese cymbal", "Ride bell", "Tambourine",
      "Splash cymbal", "Cowbell", "Crash cymbal 2", "Vibraslap",
      "Ride cymbal 2", "Hi bongo", "Low bongo", "Mute hi conga",
      "Open hi conga", "Low conga", "High timbale", "Low timbale",
      "High agogo", "Low agogo", "Cabasa", "Maracas",
      "Short whistle", "Long whistle", "Short guiro", "Long guiro",
      "Claves", "Hi wood block", "Low wood block", "Mute cuica",
      "Open cuica", "Mute triangle", "Open triangle" };
    
    Vector data = new Vector(instruments.length);
    
    ClientViewer cv;
    
    /** Creates a new instance of Groove */
    public Groove(ClientViewer cv) {
        this.cv=cv;
            for (int i = 0, id = 35; i < instruments.length; i++, id++) {
                data.add(new Data(instruments[i], id));
            }
            open();
    }
     
    private void setCell(int id, int tick) {
        for (int i = 0; i < data.size(); i++) {
            Data d = (Data) data.get(i);
            if (d.id == id) {
                d.staff[tick] = Color.black;
                break;
            }
        }
    }
    
    public void open() {
        try {
            sequencer = MidiSystem.getSequencer();
            sequencer.setLoopCount(sequencer.LOOP_CONTINUOUSLY);
            sequencer.open();
           cv.playButton.setSelected(true);
        } catch (Exception e) { e.printStackTrace(); }
        sequencer.addMetaEventListener(this);
    }
    
    public void mute(boolean mute){
      sequencer.setTrackMute(0, mute);
    }
    
    public void close() {
        if (sequencer != null) {
            sequencer.stop();
        }
       // sequencer = null;
    }
    
    
    public void buildTrackThenStartSequencer() {
        Sequence sequence = null;
        try {
            sequence = new Sequence(Sequence.PPQ, 4);
        } catch (Exception ex) { ex.printStackTrace(); }
        track = sequence.createTrack();
        createEvent(PROGRAM, 9, 1, 0);
        for (int i = 0; i < data.size(); i++) {
            Data d = (Data) data.get(i);
            for (int j = 0; j < d.staff.length; j++) {
                if (d.staff[j].equals(Color.black)) {
                    createEvent(NOTEON, 9, d.id, j);
                    createEvent(NOTEOFF, 9, d.id, j+1);
                }
            }
        }
        // so we always have a track from 0 to 15.
        createEvent(PROGRAM, 9, 1, 15);
        
        // set and start the sequencer.
        try {
            sequencer.setSequence(sequence);
        } catch (Exception ex) { ex.printStackTrace(); }
        if(sequencer != null){
            sequencer.start();
        }
    }
    private void createEvent(int type, int chan, int num, long tick) {
        ShortMessage message = new ShortMessage();
        try {
            message.setMessage(type, chan, num, velocity);
            MidiEvent event = new MidiEvent( message, tick );
            track.add(event);
        } catch (Exception ex) { ex.printStackTrace(); }
    }
    
    
    public void meta(MetaMessage message) {
        if (message.getType() == 47) {  // 47 is end of track
            if (sequencer != null && sequencer.isOpen()) {
                sequencer.start();
            }
        }
    }
    
    
    
    public void presetTracks(int num) {
        
        final int ACOUSTIC_BASS = 35;
        final int ACOUSTIC_SNARE = 38;
        final int HAND_CLAP = 39;
        final int PEDAL_HIHAT = 44;
        final int LO_TOM = 45;
        final int CLOSED_HIHAT = 42;
        final int CRASH_CYMBAL1 = 49;
        final int HI_TOM = 50;
        final int RIDE_BELL = 53;
        switch (num) {
        case 0 : for (int i = 0; i < 16; i+=2) {
            setCell(CLOSED_HIHAT, i);
        }
        setCell(ACOUSTIC_SNARE, 4);
        setCell(ACOUSTIC_SNARE, 12);
        int bass1[] = { 0, 3, 6, 8 };
        for (int i = 0; i < bass1.length; i++) {
            setCell(ACOUSTIC_BASS, bass1[i]);
        }
        break;
        case 1 : for (int i = 0; i < 16; i+=4) {
            setCell(CRASH_CYMBAL1, i);
        }
        for (int i = 0; i < 16; i+=2) {
            setCell(PEDAL_HIHAT, i);
        }
        setCell(ACOUSTIC_SNARE, 4);
        setCell(ACOUSTIC_SNARE, 12);
        int bass2[] = { 0, 2, 3, 7, 9, 10, 15 };
        for (int i = 0; i < bass2.length; i++) {
            setCell(ACOUSTIC_BASS, bass2[i]);
        }
        break;
        case 2 : for (int i = 0; i < 16; i+=4) {
            setCell(RIDE_BELL, i);
        }
        for (int i = 2; i < 16; i+=4) {
            setCell(PEDAL_HIHAT, i);
        }
        setCell(HAND_CLAP, 4);
        setCell(HAND_CLAP, 12);
        setCell(HI_TOM, 13);
        setCell(LO_TOM, 14);
        int bass3[] = { 0, 3, 6, 9, 15 };
        for (int i = 0; i < bass3.length; i++) {
            setCell(ACOUSTIC_BASS+1, bass3[i]);
        }
        break;
        default :
        }
    }
    /**
     * Storage class for instrument and musical staff represented by color.
     */
    class Data extends Object {
        String name; int id; Color staff[] = new Color[16];
        public Data(String name, int id) {
            this.name = name;
            this.id = id;
            for (int i = 0; i < staff.length; i++) {
                staff[i] = Color.white;
            }
        }
    }
}
