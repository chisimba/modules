/**
 * Copyright (C) GNU/GPL AVOIR 2007
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 51
 * Franklin St, Fifth Floor, Boston, MA 02110-1301 USA
 */

package avoir.realtime.presentations.client.util;

import java.awt.*;
import java.awt.event.*;

import java.util.Vector;

import javax.swing.*;
import javax.swing.event.TreeModelEvent;
import javax.swing.event.TreeModelListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.MutableTreeNode;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;
import avoir.realtime.presentations.client.presenter.ui.*;
import avoir.realtime.presentations.common.packet.*;
import avoir.realtime.presentations.common.util.*;

public class DynamicTree extends JPanel {
	protected DefaultMutableTreeNode rootNode;

	protected DefaultTreeModel treeModel;

	protected JTree tree;

	private Toolkit toolkit = Toolkit.getDefaultToolkit();

	MainFrame mf;

	JPopupMenu popup;

	public DynamicTree(MainFrame mf) {
		super(new GridLayout(1, 0));
		this.mf = mf;
		init();
	}

	private void init() {
		rootNode = new DefaultMutableTreeNode("Presentations");
		treeModel = new DefaultTreeModel(rootNode);
		treeModel.addTreeModelListener(new MyTreeModelListener());

		tree = new JTree(treeModel);
		// tree.setEditable(true);
		popup = new JPopupMenu();

		JMenuItem menuItem = new JMenuItem("Publish");
		menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultMutableTreeNode node = null;
				TreePath parentPath = tree.getSelectionPath();
				node = (DefaultMutableTreeNode) (parentPath
						.getLastPathComponent());

				if (node == null) {
				} else {
					processDoubleClick((String) node.getUserObject());
				}
			}
		});
		popup.add(menuItem);
		// Add listener to components that can bring up popup menus.
		MouseListener popupListener = new PopupListener();
		tree.addMouseListener(popupListener);

		tree.addKeyListener(new KeyAdapter() {
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode() == 127) {
					processDelete();
				}
			}
		});
		tree.getSelectionModel().setSelectionMode(
				TreeSelectionModel.SINGLE_TREE_SELECTION);
		tree.setShowsRootHandles(true);

		tree.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				if (e.getClickCount() == 2) {
					DefaultMutableTreeNode node = null;
					TreePath parentPath = tree.getSelectionPath();
					node = (DefaultMutableTreeNode) (parentPath
							.getLastPathComponent());

					if (node == null) {
					} else {
						processDoubleClick((String) node.getUserObject());
					}

				}
			}
		});

		JScrollPane scrollPane = new JScrollPane(tree);
		add(scrollPane);
	}

	private void processDoubleClick(final String filename) {
		/**
		 * request the server to extract and parse this file
		 */
		Thread t = new Thread() {
			public void run() {
				Utils.showStatusWindow("Sending request to the server ...",
						false);

 				mf.connector.sentPacket(new ParseFileRequestPacket(
					 	mf.contentBasePath + "/" + filename));
				Utils.setStatusMessage("Waiting for server response ...");
			}
		};
		t.start();
	}

	private void processDelete() {
		DefaultMutableTreeNode node = null;
		TreePath parentPath = tree.getSelectionPath();

		if (parentPath == null) {
			JOptionPane.showMessageDialog(null,
					"Select the presentation you wish to delete first");

			return;
		}

		node = (DefaultMutableTreeNode) (parentPath.getLastPathComponent());

		if (node == null) {
		} else {
			node = (DefaultMutableTreeNode) (parentPath.getLastPathComponent());

			String selectedNode = (String) node.getUserObject();
		}

	}

	/** Remove all nodes except the root node. */
	public void clear() {
		rootNode.removeAllChildren();
		treeModel.reload();
	}

	/** Remove the currently selected node. */
	public void removeCurrentNode() {
		TreePath currentSelection = tree.getSelectionPath();

		if (currentSelection != null) {
			DefaultMutableTreeNode currentNode = (DefaultMutableTreeNode) (currentSelection
					.getLastPathComponent());
			MutableTreeNode parent = (MutableTreeNode) (currentNode.getParent());

			if (parent != null) {
				treeModel.removeNodeFromParent(currentNode);

				return;
			}
		}

		// Either there was no selection, or the root was selected.
		toolkit.beep();
	}

	/** Add child to the currently selected node. */
	public DefaultMutableTreeNode addObject(Object child) {
		DefaultMutableTreeNode parentNode = null;
		TreePath parentPath = tree.getSelectionPath();

		if (parentPath == null) {
			parentNode = rootNode;
		} else {
			parentNode = (DefaultMutableTreeNode) (parentPath
					.getLastPathComponent());
		}

		return addObject(parentNode, child, true);
	}

	public DefaultMutableTreeNode addObject(DefaultMutableTreeNode parent,
			Object child) {
		return addObject(parent, child, true);
	}

	public DefaultMutableTreeNode addObject(DefaultMutableTreeNode parent,
			Object child, boolean shouldBeVisible) {
		DefaultMutableTreeNode childNode = new DefaultMutableTreeNode(child);

		if (parent == null) {
			parent = rootNode;
		}

		treeModel.insertNodeInto(childNode, parent, parent.getChildCount());

		// Make sure the user can see the lovely new node.
		if (shouldBeVisible) {
			tree.scrollPathToVisible(new TreePath(childNode.getPath()));
		}

		return childNode;
	}

	class PopupListener extends MouseAdapter {
		public void mousePressed(MouseEvent e) {
			maybeShowPopup(e);
		}

		public void mouseReleased(MouseEvent e) {
			maybeShowPopup(e);
		}

		private void maybeShowPopup(MouseEvent e) {
			if (e.isPopupTrigger()) {
				popup.show(e.getComponent(), e.getX(), e.getY());
			}
		}
	}

	class MyTreeModelListener implements TreeModelListener {
		public void treeNodesChanged(TreeModelEvent e) {
			DefaultMutableTreeNode node;
			node = (DefaultMutableTreeNode) (e.getTreePath()
					.getLastPathComponent());

			/*
			 * If the event lists children, then the changed node is the child
			 * of the node we've already gotten. Otherwise, the changed node and
			 * the specified node are the same.
			 */
			try {
				int index = e.getChildIndices()[0];
				node = (DefaultMutableTreeNode) (node.getChildAt(index));
			} catch (NullPointerException exc) {
			}

			System.out.println("The user has finished editing the node.");
			System.out.println("New value: " + node.getUserObject());
		}

		public void treeNodesInserted(TreeModelEvent e) {
		}

		public void treeNodesRemoved(TreeModelEvent e) {
		}

		public void treeStructureChanged(TreeModelEvent e) {
		}
	}
}
