/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package avoir.realtime.presentations.common.packet;


/**
 * Packet that stores information about a Chat event
 */
@SuppressWarnings("serial")
public class ChatPacket implements PresentationsPacket {
    String usr;
    String content;
    String time;
    /**
     * Constructor
     * @param usr The person who sent this message
     * @param content The contents of the message
     * @param time The time message was send
     */
    public ChatPacket(String usr,String content,String time) {
        this.usr = usr;
        this.content = content;
        this.time=time;
    }

    /**
     * Returns the user who wrote this message
     * @return the user
     */
    public String getUsr() {
        return this.usr;
    }

    /**
     * Returns the contents of this message
     * @return String content
     */
    public String getContent() {
        return this.content;
    }

    /**
     * Returns the time the message was send
     * @return String
     */
    public String getTime(){
      return this.time;
    }

    /**
     * Creates a string with the User's name and their message
     * @return Format- "User:" message"
     */
    public String toString() {
        return "User: "+usr+" Content: "+content+" Time: "+time;
    }
}
