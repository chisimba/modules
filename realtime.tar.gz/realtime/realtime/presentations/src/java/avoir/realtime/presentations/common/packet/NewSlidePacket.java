/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package avoir.realtime.presentations.common.packet;

import javax.swing.ImageIcon;
/**
 *
 * @author dwafula
 */

public class NewSlidePacket implements PresentationsPacket {

    ImageIcon img;
    int totalSlides;
    int slideNo;
    String id;

    public NewSlidePacket(ImageIcon img, int slideNo, int totalSlides,String id) {
        this.img = img;
        this.totalSlides = totalSlides;
        this.slideNo = slideNo;
        this.id=id;

    }

    public String getId(){
        return id;
    }
    
    public int getSlideNo() {
        return slideNo;
    }

    public ImageIcon getImageIcon() {
        return img;
    }

    public int getTotalSlides() {
        return totalSlides;
    }
}
