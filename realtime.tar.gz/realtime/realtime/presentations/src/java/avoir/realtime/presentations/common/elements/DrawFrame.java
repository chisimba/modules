/**
 * Copyright (C) GNU/GPL AVOIR 2007
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 51
 * Franklin St, Fifth Floor, Boston, MA 02110-1301 USA
 */
package avoir.realtime.presentations.common.elements;

import java.util.Vector;

public class DrawFrame implements java.io.Serializable{
	String layer = "layout";

	String textStyleName = "P1";

	String presentationClass = "title";

	String styleName = "pr1";

	double height = 3.256;

	double width = 25.199;

	double x = 1.4;

	double y = 0.962;

	String name;

	Vector textBoxes = new Vector();

	DrawImage drawImage;

	public void setDrawImage(DrawImage drawImage) {
		this.drawImage = drawImage;
	}

	public DrawImage getDrawImage() {
		return drawImage;
	}

	/**
	 * 
	 */
	public DrawFrame() {

	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public Vector getTextBoxes() {
		return textBoxes;
	}

	/**
	 * get the element's draw layer
	 * 
	 * @return String
	 */
	public String getLayer() {
		return layer;
	}

	/**
	 * 
	 * @param drawLayer
	 *            String
	 */
	public void setLayer(String layer) {
		this.layer = layer;
	}

	/**
	 * the the item's presentation class
	 * 
	 * @return String
	 */
	public String getPresentationClass() {
		return this.presentationClass;
	}

	/**
	 * set's the items presentation class
	 * 
	 * @param presentationClass
	 *            String
	 */
	public void setPresentationClass(String presentationClass) {
		this.presentationClass = presentationClass;
	}

	/**
	 * get the element's style name
	 * 
	 * @return String
	 */
	public String getTextStyleName() {
		return textStyleName;
	}

	/**
	 * 
	 * @param textStyleName
	 *            String
	 */
	public void setTextStyleName(String textStyleName) {
		this.textStyleName = textStyleName;
	}

	/**
	 * get the element's text style name
	 * 
	 * @return String
	 */
	public String getStyleName() {
		return styleName;
	}

	/**
	 * 
	 * @param drawTextStyleName
	 *            String
	 */
	public void setStyleName(String styleName) {
		this.styleName = styleName;
	}

	/**
	 * get the element's height
	 * 
	 * @return double
	 */
	public double getHeight() {
		return height;
	}

	/**
	 * 
	 * @param svgHeight
	 *            double
	 */
	public void setHeight(double height) {
		this.height = height;
	}

	/**
	 * gets the element'ss width
	 * 
	 * @return double
	 */
	public double getWidth() {
		return width;
	}

	public void setWidth(double width) {
		this.width = width;
	}

	/**
	 * get the element's x cood
	 * 
	 * @return double
	 */
	public double getX() {
		return x;
	}

	/**
	 * 
	 * @param svgX
	 *            double
	 */
	public void setX(double x) {
		this.x = x;
	}

	/**
	 * get element's y coood
	 * 
	 * @return double
	 */
	public double getY() {
		return y;
	}

	/**
	 * 
	 * @param svgY
	 *            double
	 */
	public void setY(double y) {
		this.y = y;
	}

	public void addTextBox(TextBox textBox) {
		textBoxes.addElement(textBox);
	}

	public String toString() {
		return "draw:layer= \"" + layer + "\" draw:text_style_name= \""
				+ textStyleName + "\" presentation:class= \""
				+ presentationClass + "\" presentation:style_name= \""
				+ styleName + "\" svg:height= \"" + height + "\" svg:width =\""
				+ width + "\" svg:x= \"" + x + "\" svg:y= \"" + y + "\"";

	}
}
