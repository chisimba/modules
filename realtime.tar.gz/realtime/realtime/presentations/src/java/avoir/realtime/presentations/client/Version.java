
         package avoir.realtime.presentations.client;

         public class Version{

         public static String version="20071120";

         }
        