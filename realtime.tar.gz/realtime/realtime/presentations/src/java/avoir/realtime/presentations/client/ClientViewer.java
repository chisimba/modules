package avoir.realtime.presentations.client;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.event.*;
import java.awt.Dimension;
import java.awt.BorderLayout;
import java.awt.Toolkit;
import javax.swing.JLabel;
import java.util.logging.*;
import avoir.realtime.presentations.common.util.*;
import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import avoir.realtime.presentations.client.sound.*;
import avoir.realtime.presentations.client.presenter.ui.*;
//import avoir.realtime.*;
import javax.swing.*;
import java.net.*;
import java.util.*;
import java.util.Timer;

public class ClientViewer extends JApplet implements ActionListener {

    private static Logger logger = Logger.getLogger(ClientViewer.class.getName());
    public String msg = "Could not detect any live presentation.";
    Color color = new Color(0, 131, 0);
    JLabel connectionField = new JLabel("Not Connected");
    public JLabel statusBar = new JLabel();
    ImageIcon slide = null;
    static boolean startedOnCommandLine = false;
    public ClientSurface surface;
    public JLabel slideNoField = new JLabel();
    public JLabel startTimeField = new JLabel();
    ImageIcon slideIcon = Utils.createImageIcon("/icons/slide.gif", "");
    ImageIcon muteOnIcon = Utils.createImageIcon("/icons/mute_on.png", "");
    ImageIcon muteOffIcon = Utils.createImageIcon("/icons/mute_off.png", "");
    ImageIcon playIcon = Utils.createImageIcon("/icons/play.png", "");
    ImageIcon stopIcon = Utils.createImageIcon("/icons/stop.png", "");
    ImageIcon logoIcon = Utils.createImageIcon("/icons/logo.jpg", "");
    JSplitPane viewerSplitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
    JPanel leftPanel = new JPanel();
    //User user;

    JSplitPane leftSplitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
    JPanel utilsPanel = new JPanel();
    JToolBar toolbar = new JToolBar();
    static String host = "localhost";
    static int port = PresentationConstants.DEFAULT_SERVER_PORT;
    static Dimension ss = Toolkit.getDefaultToolkit().getScreenSize();
    DefaultListModel model = new DefaultListModel();
    JList list = new JList(model);
    JLabel titleLabel = new JLabel("Slides");
    JSlider volumeField = new JSlider();
    JTextArea chatField = new JTextArea();
    //static public String thumbNail = "";

    static public String id = "";
    Player player;
    JSlider slider = new JSlider();
    Groove groove;
    public Vector slides = new Vector();
    public Vector recording = new Vector();
    JPanel audioPanel = new JPanel();
    JToggleButton speakerButton = new JToggleButton(muteOffIcon);
    public JToggleButton playButton = new JToggleButton(playIcon);
    JButton stopButton = new JButton(stopIcon);
    Random r = new Random();
    JDesktopPane desktop = new JDesktopPane();
    JInternalFrame chatFrame = new JInternalFrame("Chat", true, true, true, true);
    public ChatPanel chatPanel;
    Connector connector;
    JInternalFrame introFrame = new JInternalFrame();
    JPanel mediaPanel = new JPanel();
    JMenuBar menubar = new JMenuBar();
    boolean invokedAsApplication = false;
    JTabbedPane tabbedPane = new JTabbedPane();
    JLabel infoLabel = new JLabel();
    public boolean invokedThroughWebPresent = false;
    boolean loggedIn = false;
    String user = "";
    /*public ClientViewer(String host, int port, String thumbNail, String id) {
        this.host = host;
        this.port = port;
        this.thumbNail = thumbNail;
        this.id = id;
        init();
    }*/

    public void init() {

        try {

            if (!invokedAsApplication) {
                this.host = getCodeBase().getHost();
                this.port = Integer.parseInt(this.getParameter("port"));
                this.id = this.getParameter("id");
                this.invokedThroughWebPresent = new Boolean(this.getParameter("invokedThroughWebpresent"));
                this.loggedIn =this.getParameter("isLoggedIn").equals("1")?true:false;
                this.user = this.getParameter("user");
            }
            surface = new ClientSurface();


            setLayout(new BorderLayout());
            volumeField.setMinimum(0);
            volumeField.setMaximum(10);
            volumeField.setValue(0);

            volumeField.setPaintTicks(false);
            volumeField.setPaintLabels(false);

            leftPanel.setLayout(new BorderLayout());
            leftPanel.add(new AboutPanel(), BorderLayout.CENTER);
            leftPanel.add(tabbedPane, BorderLayout.SOUTH);

            audioPanel.setLayout(new BorderLayout());
            audioPanel.add(slider, BorderLayout.NORTH);

            volumeField.setOrientation(JSlider.VERTICAL);
            volumeField.setPreferredSize(new Dimension(10, 50));
            JToolBar buttonsPanel = new JToolBar();
            buttonsPanel.add(speakerButton);
            buttonsPanel.add(playButton);
            buttonsPanel.add(stopButton);

            speakerButton.setSelectedIcon(muteOnIcon);
            speakerButton.setBorderPainted(false);
            speakerButton.setContentAreaFilled(false);

            playButton.setBorderPainted(false);
            //playButton.setContentAreaFilled(false);

            stopButton.setBorderPainted(false);
            stopButton.setContentAreaFilled(false);


            playButton.addActionListener(new ActionListener() {

                        public void actionPerformed(ActionEvent e) {
                            playBack();
                        }
                    });
            speakerButton.addActionListener(new ActionListener() {

                        public void actionPerformed(ActionEvent e) {
                            if (groove != null) {
                                groove.mute(speakerButton.isSelected());
                            }
                        }
                    });

            audioPanel.add(buttonsPanel, BorderLayout.SOUTH);


            //leftSplitPane.setTopComponent(new AboutPanel());
            //leftSplitPane.setDividerLocation(150);
            desktop.setPreferredSize(new Dimension(300, 150));
            tabbedPane.addTab("Chat", desktop);
            //leftSplitPane.setBottomComponent(tabbedPane);
            mediaPanel.setBorder(BorderFactory.createTitledBorder("Presenter"));

            viewerSplitPane.setLeftComponent(leftPanel);
            JPanel sP = new JPanel();
            sP.setLayout(new BorderLayout());
            sP.add(surface, BorderLayout.CENTER);
            infoLabel.setBorder(BorderFactory.createEtchedBorder());
            infoLabel.setText("No Slides Detected");
            sP.add(infoLabel, BorderLayout.SOUTH);
            viewerSplitPane.setRightComponent(sP);


            add(statusBar, BorderLayout.SOUTH);

            /*JInternalFrame desktopFrame = new JInternalFrame();
            
            desktopFrame.setSize((ss.width / 8) * 7, (ss.height / 8) * 7);
            // viewerSplitPane.setDividerLocation(150);
            desktopFrame.getContentPane().setLayout(new BorderLayout());
            desktopFrame.getContentPane().add(viewerSplitPane, BorderLayout.CENTER);
            desktopFrame.putClientProperty("JInternalFrame.isPalette", Boolean.TRUE);
            desktopFrame.setVisible(true);
            */
            //            setTitle("Live Presentation - Development Version");
            //createChatFrame();

            //desktop.add(desktopFrame);
            add(viewerSplitPane, BorderLayout.CENTER);
            //add(toolbar, BorderLayout.NORTH);
            list.setLayoutOrientation(JList.HORIZONTAL_WRAP);
            list.setCellRenderer(new SlideRenderer());
            //  setSize((ss.width / 8) * 7, (ss.height / 8) * 7);
            addButtons();
            surface.repaint();

            slider.setMinimum(0);
            slider.setMaximum(10);
            slider.setValue(0);
            slider.setPaintLabels(false);
            slider.setPaintTicks(false);
            list.addListSelectionListener(new ListSelectionListener() {

                        public void valueChanged(ListSelectionEvent e) {
                            int index = list.getSelectedIndex();
                            if (surface != null) {
                                if (slides.size() > 0 && index > -1) {
                                    slide = (ImageIcon) slides.elementAt(index);
                                    surface.repaint();
                                }
                            }

                        }
                    });

            showIntro();


            surface.repaint();
            buildMenu();
            connect();

            this.setJMenuBar(menubar);
            groove = new Groove(this);

        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }

    private void enableMenus(boolean state) {
        for (int i = 0; i < menubar.getMenuCount(); i++) {
            menubar.getMenu(i).setEnabled(state);
        }
    }

    private void buildMenu() {
        JMenu menu = new JMenu("File");
        menu.setFont(new Font("Dialog", 0, 10));
        // menu.add(createMenuItem("Chat", "showChat"));
        menu.add(createMenuItem("Connect", "connect"));
        menu.addSeparator();
        menu.add(createMenuItem("Exit", "exit"));
        menubar.add(menu);
        menu = new JMenu("Help");
        menu.setFont(new Font("Dialog", 0, 10));

        menu.add(createMenuItem("About", "about"));

        menubar.add(menu);

    }
    /**
     * Create a menut item
     *
     * @param text :
     *            text of menu
     * @param action:
     *            action command
     * @return
     */

    public JMenuItem createMenuItem(String text, String action) {
        JMenuItem menuItem = new JMenuItem(text);
        menuItem.setFont(new Font("Dialog", 0, 10));
        menuItem.setActionCommand(action);
        menuItem.addActionListener(this);
        return menuItem;
    }

    public void playBack() {
        if (slides.size() > 0 && !list.isSelectionEmpty()) {
            slide = (ImageIcon) slides.elementAt(0);
            list.setSelectedIndex(0);
            surface.repaint();
        }
        player = new Player();

    }

    public void showSlideThumbNails() {

        if (slides != null && model != null) {
            list.clearSelection();
            list.removeAll();
            model.clear();
            for (int i = 0; i < slides.size(); i++) {
                model.addElement(new Integer(i));
                if (i == 0) {
                    list.setSelectedIndex(0);
                }

            }
            surface.repaint();

        }

    }
    /**
     * @param args
     */

    public static void main(String[] args) {
        startedOnCommandLine = true;
        host = args[0];
        port = Integer.parseInt(args[1]);
        //        thumbNail = args[2];
        id = args[3];
    /* ClientViewer fr = new ClientViewer(host, port, thumbNail, id);
        Dimension ss = Toolkit.getDefaultToolkit().getScreenSize();
        fr.setLocation((ss.width - fr.getWidth()) / 2, (ss.height - fr.getHeight()) / 2);
        fr.setVisible(true);
    */    }

    public void setStatusText(String msg, Color color) {
        statusBar.setForeground(color);
        statusBar.setText(msg);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("connect")) {
            connect();
        }
        if (e.getActionCommand().equals("exit")) {
            System.exit(0);
        }
        if (e.getActionCommand().equals("about")) {
            Utils.msg("AVOIR PROJECT\nReal Time Presentations, Development Version\nVersion DV" + Version.version);
        }
    }

    private void connect() {
        //enableMenus(false);
        setStatusText("Connecting to " + host + ": " + port + " ...", new Color(0, 131, 0));
        Thread t = new Thread() {

                    public void run() {

                        connector = new Connector(host, port, ClientViewer.this, id);
                        try {
                            if (connector.connect()) {

                                setStatusText("Connected to host: " + host + " on port: " + new Integer(port).toString(), new Color(0, 131, 0));
                                showSlideThumbNails();
                                /* infoLabel.setText("Could not detect any live presentation. Check chat history for more information");
                                msg = "Could not detect any live presentation.";
                                color = Color.RED;
                                surface.repaint();
                                */ introFrame.dispose();
                                if (!loggedIn) {
                                    //generate guest no between 1 and 100 
                                    int randomInt = 1 + Math.abs((int) (Math.random() * 100));
                                    user = "guest" + randomInt;
                                }
                                chatPanel = new ChatPanel(connector, user);
                                ChatFrame fr = new ChatFrame(chatPanel, user);
                                try {
                                    desktop.add(fr);
                                } catch (Exception ex) {
                                    ex.printStackTrace();
                                }

                                playBack();


                            } else {
                                setStatusText("Error connecting to host: " + host + " on port: " + new Integer(port).toString(), Color.red);
                                enableMenus(true);
                                msg = "Error connecting to host: " + host + " on port: " + new Integer(port).toString();
                                color = Color.RED;
                                surface.repaint();
                                introFrame.dispose();

                            }
                        } catch (Exception e) {
                            enableMenus(true);
                            logger.log(Level.WARNING, "Error connecting to host", e);
                            msg = "Error connecting to server";
                            color = Color.RED;
                            surface.repaint();

                        }
                    }
                };
        t.start();
    }

    /**
     * Create a JButton
     *
     * @param icon
     * @param tooltip
     * @param action
     * @param addBg
     * @return
     */
    private JButton createJButton(Icon icon, String tooltip, String action,
            boolean addBg) {
        JButton button = new JButton(icon);

        button.setToolTipText(tooltip);
        button.setActionCommand(action);
        button.setText(tooltip);
        button.setBorderPainted(false);
        button.addActionListener(this);

        return button;
    }

    /*  public void createChatFrame() {
        try {
            chatPanel = new ChatPanel();
            chatFrame.setSize(ss.width / 4, 200);
            chatFrame.setLocation(30, (ss.height / 4) * 2);
            chatFrame.getContentPane().setLayout(new BorderLayout());
            chatFrame.getContentPane().add(chatPanel, BorderLayout.CENTER);
            chatFrame.setVisible(true);
            chatFrame.setSelected(true);
          desktop.add(chatFrame, new Integer(1));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
   * /
    /**
     * Adds buttons to the toolbar
     *
     */
    private void addButtons() {
        toolbar.add(createJButton(Utils.createImageIcon("/icons/refresh.png",
                ""), "Refresh", "refresh", false));

    }

    public void setCurrentSlide(ImageIcon slide, int slideNo, int slideCount) {
        this.slide = slide;
        infoLabel.setText("Slide " + (slideNo + 1) + " of " + slideCount);
        surface.repaint();
    }

    public void showIntro() {
        try {
            introFrame.setSize(400, 100);
            introFrame.getContentPane().setLayout(new BorderLayout());
            Dimension ss = this.getSize();
            introFrame.setLocation((ss.width - introFrame.getWidth()) / 2, (ss.height - introFrame.getHeight()) / 2);
            JLabel msgLabel = new JLabel("Connecting ...", JLabel.CENTER);
            msgLabel.setFont(new java.awt.Font("System", 3, 22));
            msgLabel.setForeground(new Color(0, 131, 0));

            JProgressBar pb = new JProgressBar();
            pb.setIndeterminate(true);
            introFrame.setBorder(BorderFactory.createRaisedBevelBorder());
            introFrame.getContentPane().add(msgLabel, BorderLayout.CENTER);
            introFrame.getContentPane().add(pb, BorderLayout.SOUTH);
            introFrame.putClientProperty("JInternalFrame.isPalette", Boolean.TRUE);
            introFrame.setVisible(true);
        //            desktop.add(introFrame, new Integer(2));
        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }

    class Player {

        Toolkit toolkit;
        Timer timer;
        long startTime = 0;
        long endTime;

        public Player() {
            if (recording.size() > 0) {
                Vector lastRecording = (Vector) recording.lastElement();
                Vector firstRecording = (Vector) recording.firstElement();
                Long xtime = (Long) firstRecording.elementAt(1);
                startTime = xtime.intValue();
                Long xendTime = (Long) lastRecording.elementAt(1);
                endTime = xendTime.intValue();
            }

            toolkit = Toolkit.getDefaultToolkit();
            timer = new Timer();
            timer.schedule(new PlayTask(),
                    0, //initial delay
                    2 * 1000);  //subsequent rate
            slider.setMinimum(0);
            slider.setMaximum((int) (endTime - startTime));

            //play sound
            if (groove != null) {
                groove.presetTracks(1);
                try {
                    if (groove.sequencer != null) {
                        groove.sequencer.stop();
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
                groove.buildTrackThenStartSequencer();
            }

        }

        private int getSlideNo(long time) {
            for (int i = 0; i < recording.size(); i++) {
                Vector record = (Vector) recording.elementAt(i);
                Integer slideNo = (Integer) record.elementAt(0);
                Long xtime = (Long) record.elementAt(1);
                if (xtime.intValue() == time) {
                    return slideNo.intValue();
                }
            }
            return -1;
        }

        class PlayTask extends TimerTask {

            public void run() {
                slider.setValue((int) startTime);

                if (startTime <= endTime) {
                    int slideNo = getSlideNo(startTime);
                    if (slideNo != -1) {
                        list.setSelectedIndex(slideNo);

                    }
                } else {
                    timer.cancel();
                    playButton.setSelected(false);
                    slider.setValue(0);
                    recording.clear();
                    groove.close();
                }
                startTime++;
            } // run()

        } //

    } //


    class AboutPanel extends JPanel {

        //Image image = Toolkit.getDefaultToolkit().createImage("/icons/logo.jpg");

        public AboutPanel() {
            this.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
            this.setBackground(color.WHITE);
            setPreferredSize(new Dimension(300, 500));
        }

        public void paintComponent(Graphics g) {
            super.paintComponent(g);
            Image image = logoIcon.getImage();
            Graphics2D g2 = (Graphics2D) g;
            int xx = (getWidth() - image.getWidth(this)) / 2;
            int yy = (getHeight() - image.getHeight(this)) / 2;

            g2.setColor(new Color(0, 131, 0));
            if (image != null) {
                g2.drawImage(image, xx, yy, this);
            }
        /*            g2.setColor(Color.ORANGE);
            g2.setFont(new java.awt.Font("system", 1, 20));
            g2.drawString("webPresent", 100, xx + image.getHeight(this) + 50);
            g2.setFont(new java.awt.Font("system", 1, 14));
            g2.drawString("knowledge in presentation", 120, xx + image.getHeight(this) + 70);
  */        }
    }

    class ClientSurface extends JPanel {

        public ClientSurface() {
            this.setBackground(Color.WHITE);
            this.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        }

        private void centerString(String msg, Graphics2D g, int xValue, int y) {
            // Get measures needed to center the message
            FontMetrics fm = g.getFontMetrics();

            // How many pixels wide is the string
            int msg_width = fm.stringWidth(msg);

            // How far above the baseline can the font go?
            int ascent = fm.getMaxAscent();

            // How far below the baseline?
            int descent = fm.getMaxDescent();

            int x1 = xValue;
            int x2 = xValue + 650;
            int ss = x2 - x1;
            int dd = (ss + xValue) / 2;
            // Use the string width to find the starting point
            int msg_x = (x2 - x1) / 2 - msg_width / 2;
            //  int msg_x = xValue + xValue+600 / 2 - msg_width / 2;
            g.drawString(msg, msg_x + xValue, y);

        }

        public void paintComponent(Graphics g) {
            super.paintComponent(g);

            Graphics2D g2 = (Graphics2D) g;
            if (slide != null) {
                int xx = (getWidth() - slide.getIconWidth()) / 2;
                int yy = (getHeight() - slide.getIconHeight()) / 2;

                g2.drawImage(slide.getImage(), xx, yy, this);

            } else {

                int xxx = (getWidth() - (getWidth() - 20)) / 2;
                int yyy = (getHeight() - (getHeight() - 20)) / 2;



                //g2.setColor(Color.red);
                // g2.drawRect(xxx, yyy, getWidth() - 20, getHeight() - 20);
                g2.setFont(new java.awt.Font("Dialog", 1, 18));
                g2.setColor(color);

                centerString(msg, g2, 0, getHeight() / 2);
            //  g2.setFont(new java.awt.Font("Dialog",2,15));
              //  g2.drawString("1. Click refresh button on the applet.", 100, 80);
              //  g2.drawString("2. Try later.", 100, 100);

            }
        }
    }

    class SlideRenderer extends JLabel implements ListCellRenderer {

        public SlideRenderer() {
            setOpaque(true);
            setHorizontalAlignment(LEFT);
            setVerticalAlignment(CENTER);
        }

        /*
                 * This method finds the image and text corresponding to the selected
                 * value and returns the label, set up to display the text and image.
                 */
        public Component getListCellRendererComponent(JList list, Object value,
                int index, boolean isSelected, boolean cellHasFocus) {
            // Get the selected index. (The index param isn't
            // always valid, so just use the value.)
            int selectedIndex = ((Integer) value).intValue();

            if (isSelected) {
                setBackground(list.getSelectionBackground());
                setForeground(list.getSelectionForeground());
            } else {
                setBackground(list.getBackground());
                setForeground(list.getForeground());
            }

            setIcon(slideIcon);
            if (slideIcon != null) {
                setText("Slide " + (selectedIndex + 1));
                setFont(list.getFont());

            }
            return this;
        }
    }
}
