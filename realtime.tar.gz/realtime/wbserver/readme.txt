
CHANGES TO MAKE:
================
1. Open wrapper.conf located in conf directory of wbserver folder, using a text editor. Edit the following line to reflect your java location:
wrapper.java.command=java
