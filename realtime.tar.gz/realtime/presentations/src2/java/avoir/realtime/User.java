/**
 * $Id: User.java,v 1.4 2007-12-12 09:56:57 davidwaf Exp $
 * 
 * Copyright (C) GNU/GPL AVOIR 2007
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 51
 * Franklin St, Fifth Floor, Boston, MA 02110-1301 USA
 */
package avoir.realtime;

import java.io.Serializable;
import java.util.logging.Logger;

/**
 * Class to represent Users of the realtime tools, maps to the logged in user in
 * Chisimba.
 */
@SuppressWarnings("serial")
public class User implements Serializable {

    private static Logger logger = Logger.getLogger(User.class.getName());
    private UserLevel level;
    private String fullname;
    private String userId;
    private boolean hasToken;
    boolean active = true;

    public User() {

    }
    /**
	 * Constructs a new User with the passed level and name.
	 * 
	 * @param level
	 *            User level (equivalent to Chisimba group).
	 * @param fullname
	 *            User's first name.
	 */

    public User(UserLevel level, String fullname) {
        this(level, fullname, null, false);
    }

    /**
	 * Constructs a new User with the passed values.
	 * 
	 * @param level
	 *            User level (equivalent to Chisimba group).
	 * @param fullname
	 *            User's first name.
	 * @param id
	 *            ID of User in the Chisimba database.
	 * @param hasToken
	 *            Whether the user has a token or not.
	 */
    public User(UserLevel level, String fullname, String id, boolean hasToken) {
        this.level = level;
        this.fullname = fullname;
        this.userId = id;

        this.hasToken = hasToken;
        logger.finest("Created new user object with name " + fullname + " and level " + level);
    }

    public User(UserLevel level, String fullname, String id) {
        this.level = level;
        this.fullname = fullname;
        this.userId = id;

        logger.finest("Created new user object with name " + fullname + " and level " + level);
    }

    /**
	 * Returns the user's name.
	 * 
	 * @return String The user's name.
	 */
    public String getFullName() {
        return this.fullname;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }
    /*** Returns the user's level.
	 * 
	 * @return UserLevel The user's level.
	 */

    public UserLevel getLevel() {
        return this.level;
    }

        /**
	 * Returns whether the user has a drawing token or not.
	 * 
	 * @return returns true if the user has a drawing token, otherwise false.
	 */
    public boolean hasToken() {
        return hasToken;
    }

        /**
	 * Sets whether the user has a drawing token or not.
	 * 
	 * @param hasToken
	 *            The new value for the drawing token.
	 */
    public void setToken(boolean hasToken) {
        this.hasToken = hasToken;
    }

    /**
	 * returns userid of the user
	 * 
	 * @return userid the id of the user
	 */
    public String getUserId() {
        return this.userId;
    }

    /**
	 * Flips a user's "has token" boolean to the opposite value.
	 */
    public void flipToken() {
        if (!hasToken) {
            hasToken = true;
        } else {
            hasToken = false;
        }
    }

    /**
	 * Implemented to allow display of user name in GUI lists.
	 * 
	 * @return The user name.
	 */
    public String toString() {
        return this.fullname;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if ((object == null) || (object.getClass() != this.getClass())) {
            return false;
        }
        User otherUser = (User) object;
        if (this.level.equals(otherUser.getLevel()) && this.fullname.equals(otherUser.getFullName())) {
            if (this.userId == null && otherUser.getUserId() == null) {
                return true;
            }
            if (this.userId != null && otherUser.getUserId() != null) {
                if (this.userId.equals(otherUser.getUserId())) {
                    return true;
                }
            }
        }
        return false;
    }

    public void setFullName(String name) {
        fullname = name;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public int hashCode() {
        int hash = 1;
        hash = hash * 31 + level.hashCode() + fullname.hashCode();
        hash = hash * 31 + (userId == null ? 0 : userId.hashCode());
        return hash;
    }
}
