package avoir.realtime.presentations.client.viewer;

import JMFRegistry;
import javax.swing.JPanel;
import javax.swing.event.*;
import java.awt.Dimension;
import java.awt.BorderLayout;
import java.awt.Toolkit;
import javax.swing.JLabel;
import java.util.logging.*;
import avoir.realtime.presentations.common.util.*;
import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import avoir.realtime.presentations.client.sound.*;
import avoir.realtime.presentations.common.packet.*;
import avoir.realtime.presentations.client.presenter.*;
import avoir.realtime.presentations.client.Connector;
import avoir.realtime.presentations.client.Version;
import avoir.realtime.presentations.client.ChatPanel;
import avoir.realtime.presentations.client.ChatFrame;
import avoir.realtime.presentations.common.util.PresentationConstants;

import avoir.realtime.User;
import javax.swing.*;
import java.net.*;
import java.util.*;
import java.util.Timer;
import java.awt.geom.AffineTransform;

public class ClientViewer extends avoir.realtime.applet.RealtimeApplet implements ActionListener {

    private static Logger logger = Logger.getLogger(ClientViewer.class.getName());
    public String msg = "Could not detect any live presentation yet...";
    public Color color = new Color(0, 131, 0);
    public JLabel statusBar = new JLabel();
    public ImageIcon slide = null;
    public ClientSurface surface;
    public JLabel slideNoField = new JLabel();
    public JLabel startTimeField = new JLabel();
    ImageIcon slideIcon = Utils.createImageIcon("/icons/slide.gif", "");
    ImageIcon muteOnIcon = Utils.createImageIcon("/icons/mute_on.png", "");
    ImageIcon muteOffIcon = Utils.createImageIcon("/icons/mute_off.png", "");
    ImageIcon playIcon = Utils.createImageIcon("/icons/play.png", "");
    ImageIcon stopIcon = Utils.createImageIcon("/icons/stop.png", "");
    ImageIcon logoIcon = Utils.createImageIcon("/icons/logo.jpg", "");
    static String host = "localhost";
    static int port = PresentationConstants.DEFAULT_SERVER_PORT;
    static Dimension ss = Toolkit.getDefaultToolkit().getScreenSize();
    JLabel titleLabel = new JLabel("Slides");
    static public String id = "";
    //  Groove groove;

    Random r = new Random();
    JDesktopPane mainDesktop = new JDesktopPane();
    public ChatPanel chatPanel;
    public Connector connector;
    JMenuBar menubar = new JMenuBar();
    boolean invokedAsApplication = false;
    JTabbedPane tabbedPane = new JTabbedPane();
    public JLabel infoLabel = new JLabel();
    public boolean invokedThroughWebPresent = false;
    boolean loggedIn = false;
    public User user;
    //public String fullnames = "Guest";

    public String contentBasePath = ".";
    public DynamicTree audiencePanel = new DynamicTree();
    public String jmfPath;
    public String presenter = "UNIDENTIFIED";
    public String SURFACE_ERROR = "";
    int appletHeight = 600;// appletSize.height;

    int appletWidth = 800;// appletSize.width;

    public JMFDiagnostics jmfPanel;
    public JTabbedPane mediaTP = new JTabbedPane();

    public void init() {

        try {

            if (!invokedAsApplication) {
                this.host = getCodeBase().getHost();
                this.port = Integer.parseInt(this.getParameter("port"));
                this.id = this.getParameter("id");
                this.invokedThroughWebPresent = new Boolean(this.getParameter("invokedThroughWebpresent"));
                this.loggedIn = this.getParameter("isLoggedIn").equals("1") ? true : false;

                this.contentBasePath = this.getParameter("contentBasePath");
                this.jmfPath = this.getParameter("jmfResourcePath");
            // System.out.println("JMF Path: "+jmfPath);
             // Utils.err(jmfPath+" "+id);

            }
            jmfPanel = new JMFDiagnostics(this);
            surface = new ClientSurface();
            user = getCurrentUser();
            createSurfaceFrame();
            try {
                createMediaFrame();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            createAudienceFrame();

            mainDesktop.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));

            add(statusBar, BorderLayout.SOUTH);
            add(mainDesktop, BorderLayout.CENTER);
            buildMenu();
            connect();

            this.setJMenuBar(menubar);
        // groove = new Groove(this);

        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }

    private void createSurfaceFrame() {
        JPanel sP = new JPanel();
        sP.setLayout(new BorderLayout());
        sP.add(surface, BorderLayout.CENTER);
        infoLabel.setBorder(BorderFactory.createEtchedBorder());
        infoLabel.setText("No Slides Detected");
        sP.add(infoLabel, BorderLayout.SOUTH);
        JInternalFrame board = new JInternalFrame();//"Surface", true, true, true, true);
        final JTabbedPane pp = new JTabbedPane();
        pp.addTab("Slides", sP);
        pp.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        board.getContentPane().setLayout(new BorderLayout());
        board.getContentPane().add(sP, BorderLayout.CENTER);
        //board.setUI(new NoBorderInternalFrameUI(board));
        board.setResizable(true);
        board.putClientProperty("JInternalFrame.isPalette", Boolean.TRUE);
        board.setSize(600, 500);
        //board.setLocation((appletWidth - board.getWidth()) / 2, 20);
        board.setLocation(300, 20);
        board.setVisible(true);
        addFrame(board);
    }

    private void createMediaFrame() {

        Thread t = new Thread() {

                    public void run() {
                        boolean jmfAvailable = false;
                        boolean realtimeVideoAvailable = false;
                        // Check for basic JMF classes.

                        try {
                            System.out.println("jmf testing...");
                            Class.forName("javax.media.Player");
                            jmfAvailable = true;
                        } catch (Exception ex) {//Throwable throwable2) {
                            ex.printStackTrace();
                            setStatusText("JMF not found", Color.BLACK);
                            return;
                        }

                        //check for realtime vid
                        try {
                            System.out.println("vid testing...");
                            Class.forName("avoir.realtime.video.transmitter.engine.CaptureUtil");
                            realtimeVideoAvailable = true;
                        } catch (Exception ex) {//Throwable throwable2) {
                            ex.printStackTrace();
                            setStatusText("Realtime video not found", Color.BLACK);
                            return;
                        }

  


                        if (realtimeVideoAvailable && jmfAvailable) {
                            avoir.realtime.video.transmitter.engine.CaptureUtil util = new avoir.realtime.video.transmitter.engine.CaptureUtil();
                            javax.media.Player player = util.transmitLive();

                            avoir.realtime.video.transmitter.gui.JMFrame fr = new avoir.realtime.video.transmitter.gui.JMFrame(player, "");
                            fr.setVisible(true);
                            addFrame(fr);
                        }
                    }
                };
        t.start();
    /*try {

            JInternalFrame mediaFrame = new JInternalFrame();

            mediaTP.setBorder(BorderFactory.createLineBorder(Color.BLACK));
            mediaTP.setUI(new javax.swing.plaf.metal.MetalTabbedPaneUI() {

                        protected void paintContentBorder(Graphics g, int tabPlacement, int selectedIndex) {
                            mediaTP.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));//10, to stand-out, reduce to whatever
                        }
                    });
            mediaTP.addTab("JMF", jmfPanel);


            mediaFrame.getContentPane().setLayout(new BorderLayout());
            mediaFrame.getContentPane().add(mediaTP, BorderLayout.CENTER);
            //mediaFrame.setUI(new NoBorderInternalFrameUI(mediaFrame));
            mediaFrame.setResizable(true);
            mediaFrame.putClientProperty("JInternalFrame.isPalette", Boolean.TRUE);
            mediaFrame.setSize(250, 200);
            mediaFrame.setLocation(10, 20);
            mediaFrame.setVisible(true);
            addFrame(mediaFrame);
            jmfPanel.start();
        } catch (Exception ex) {
            ex.printStackTrace();
        }*/
    }

    private void createAudienceFrame() {
        try {

            JInternalFrame audienceFrame = new JInternalFrame();
            UIManager.put("TabbedPane.selected", new Color(238, 238, 238));

            final JTabbedPane tP = new JTabbedPane();
            tP.setUI(new javax.swing.plaf.metal.MetalTabbedPaneUI() {

                        protected void paintContentBorder(Graphics g, int tabPlacement, int selectedIndex) {
                            tP.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));//10, to stand-out, reduce to whatever
                        }
                    });
            tP.setFont(new Font("Dialog", 0, 10));

            tP.addTab("Audience", audiencePanel);
            audienceFrame.getContentPane().setLayout(new BorderLayout());
            audienceFrame.getContentPane().add(tP, BorderLayout.CENTER);
            //mediaFrame.setUI(new NoBorderInternalFrameUI(mediaFrame));
            audienceFrame.setResizable(true);
            audienceFrame.putClientProperty("JInternalFrame.isPalette", Boolean.TRUE);
            audienceFrame.setSize(250, 200);
            audienceFrame.setLocation(20, 200);
            audienceFrame.setVisible(true);
            addFrame(audienceFrame);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void addFrame(JInternalFrame fr) {
        try {
            fr.setSelected(true);
            mainDesktop.add(fr);

        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }

    public void destroy() {
        connector.sentPacket(new UserPacket(user, false));
        user.setActive(false);
        connector.sentPacket(new ChatPacket(user, user.getUserId() + " has left presentation", "", false, true, contentBasePath));

    }

    private void enableMenus(boolean state) {
        for (int i = 0; i < menubar.getMenuCount(); i++) {
            menubar.getMenu(i).setEnabled(state);
        }
    }

    private void buildMenu() {
        JMenu menu = new JMenu("File");
        menu.setFont(new Font("Dialog", 0, 10));
        // menu.add(createMenuItem("Chat", "showChat"));
        menu.add(createMenuItem("Connect", "connect"));
        menu.addSeparator();
        menu.add(createMenuItem("Exit", "exit"));
        menubar.add(menu);
        menu = new JMenu("Help");
        menu.setFont(new Font("Dialog", 0, 10));

        menu.add(createMenuItem("About", "about"));

        menubar.add(menu);

    }
    /**
     * Create a menut item
     *
     * @param text :
     *            text of menu
     * @param action:
     *            action command
     * @return
     */

    public JMenuItem createMenuItem(String text, String action) {
        JMenuItem menuItem = new JMenuItem(text);
        menuItem.setFont(new Font("Dialog", 0, 10));
        menuItem.setActionCommand(action);
        menuItem.addActionListener(this);
        return menuItem;
    }

    public void playBack() {
    /*  if (slides.size() > 0 && !list.isSelectionEmpty()) {
            slide = (ImageIcon) slides.elementAt(0);
            list.setSelectedIndex(0);
            surface.repaint();
        }
        player = new Player();
*/
    }

    public void setStatusText(String msg, Color color) {
        statusBar.setForeground(color);
        statusBar.setText(msg);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("connect")) {
            connect();
        }
        if (e.getActionCommand().equals("exit")) {
            System.exit(0);
        }
        if (e.getActionCommand().equals("about")) {
            Utils.msg("AVOIR PROJECT\nReal Time Presentations, Beta Version\nVBuild  1-" + Version.version);
        }
    }

    public void doPostConnectStuff() {
        setStatusText("Connected to host: " + host + " on port: " + new Integer(port).toString(), new Color(0, 131, 0));

        if (!loggedIn) {
            //generate guest no between 1 and 100 
            int randomInt = 1 + Math.abs((int) (Math.random() * 100));
            user.setFullName("guest" + randomInt);
            user.setUserId("guest" + randomInt);
        }

        connector.sentPacket(new UserPacket(user, PresentationConstants.NEW_USER));
        connector.sentPacket(new RequestContentPacket(id));


        chatPanel = new ChatPanel(connector, user, PresentationConstants.VIEWER);
        ChatFrame fr = new ChatFrame(chatPanel, user);
        try {
            fr.setLocation(10, 300);
            mainDesktop.add(fr, new Integer(1));
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        //        Utils.msg(contentBasePath);

        connector.sentPacket(new ChatPacket(user, user + " has joined presentation",
                "", PresentationConstants.VIEWER, PresentationConstants.SYSTEM_MESSAGE, contentBasePath));



    }

    private void connect() {
        //enableMenus(false);
        setStatusText("Connecting to " + host + ": " + port + " ...", new Color(0, 131, 0));
        Thread t = new Thread() {

                    public void run() {

                        connector = new Connector(host, port, ClientViewer.this, id);
                        connector.connect();
                    }
                };
        t.start();
    }

    /**
     * Create a JButton
     *
     * @param icon
     * @param tooltip
     * @param action
     * @param addBg
     * @return
     */
    private JButton createJButton(Icon icon, String tooltip, String action,
            boolean addBg) {
        JButton button = new JButton(icon);

        button.setToolTipText(tooltip);
        button.setActionCommand(action);
        button.setText(tooltip);
        button.setBorderPainted(false);
        button.addActionListener(this);

        return button;
    }

    public void setCurrentSlide(ImageIcon slide, int slideNo, int slideCount) {
        this.slide = slide;
        infoLabel.setText("Slide " + (slideNo + 1) + " of " + slideCount + " PRESENTER: " + presenter);
        surface.repaint();
    }

    /*class Player {

        Toolkit toolkit;
        Timer timer;
        long startTime = 0;
        long endTime;

        public Player() {
            if (recording.size() > 0) {
                Vector lastRecording = (Vector) recording.lastElement();
                Vector firstRecording = (Vector) recording.firstElement();
                Long xtime = (Long) firstRecording.elementAt(1);
                startTime = xtime.intValue();
                Long xendTime = (Long) lastRecording.elementAt(1);
                endTime = xendTime.intValue();
            }

            toolkit = Toolkit.getDefaultToolkit();
            timer = new Timer();
            timer.schedule(new PlayTask(),
                    0, //initial delay
                    2 * 1000);  //subsequent rate
            slider.setMinimum(0);
            slider.setMaximum((int) (endTime - startTime));

            //play sound
            if (groove != null) {
                groove.presetTracks(1);
                try {
                    if (groove.sequencer != null) {
                        groove.sequencer.stop();
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
                groove.buildTrackThenStartSequencer();
            }

        }

        private int getSlideNo(long time) {
            for (int i = 0; i < recording.size(); i++) {
                Vector record = (Vector) recording.elementAt(i);
                Integer slideNo = (Integer) record.elementAt(0);
                Long xtime = (Long) record.elementAt(1);
                if (xtime.intValue() == time) {
                    return slideNo.intValue();
                }
            }
            return -1;
        }

        class PlayTask extends TimerTask {

            public void run() {
                slider.setValue((int) startTime);

                if (startTime <= endTime) {
                    int slideNo = getSlideNo(startTime);
                    if (slideNo != -1) {
                        list.setSelectedIndex(slideNo);

                    }
                } else {
                    timer.cancel();
                    playButton.setSelected(false);
                    slider.setValue(0);
                    recording.clear();
                    groove.close();
                }
                startTime++;
            } // run()

        } //

    } //*/
    class AboutPanel extends JPanel {

        //Image image = Toolkit.getDefaultToolkit().createImage("/icons/logo.jpg");

        public AboutPanel() {
            this.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
            this.setBackground(color.WHITE);
            setPreferredSize(new Dimension(150, 400));
        }

        public void paintComponent(Graphics g) {
            super.paintComponent(g);
            Image image = logoIcon.getImage();
            Graphics2D g2 = (Graphics2D) g;
            int xx = (getWidth() - image.getWidth(this)) / 2;
            int yy = (getHeight() - image.getHeight(this)) / 2;

            g2.setColor(new Color(0, 131, 0));
            if (image != null) {
                g2.drawImage(image, xx, yy, this);
            }
        /*            g2.setColor(Color.ORANGE);
            g2.setFont(new java.awt.Font("system", 1, 20));
            g2.drawString("webPresent", 100, xx + image.getHeight(this) + 50);
            g2.setFont(new java.awt.Font("system", 1, 14));
            g2.drawString("knowledge in presentation", 120, xx + image.getHeight(this) + 70);
  */        }
    }

    public class ClientSurface extends JPanel {

        public ClientSurface() {
            this.setBackground(Color.WHITE);
            this.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        }

        private void centerString(String msg, Graphics2D g, int xValue, int y) {
            // Get measures needed to center the message
            FontMetrics fm = g.getFontMetrics();

            // How many pixels wide is the string
            int msg_width = fm.stringWidth(msg);

            // How far above the baseline can the font go?
            int ascent = fm.getMaxAscent();

            // How far below the baseline?
            int descent = fm.getMaxDescent();

            int x1 = xValue;
            int x2 = xValue + 650;
            int ss = x2 - x1;
            int dd = (ss + xValue) / 2;
            // Use the string width to find the starting point
            int msg_x = (x2 - x1) / 2 - msg_width / 2;
            //  int msg_x = xValue + xValue+600 / 2 - msg_width / 2;
            g.drawString(msg, msg_x + xValue, y);

        }

        public void paintComponent(Graphics g) {
            super.paintComponent(g);

            Graphics2D g2 = (Graphics2D) g;
            if (slide != null) {
                int xx = (getWidth() - slide.getIconWidth()) / 2;
                int yy = (getHeight() - slide.getIconHeight()) / 2;

                g2.drawImage(slide.getImage(), xx, yy, this);
                g2.drawRect(xx - 5, yy - 5, slide.getIconWidth() + 10, slide.getIconHeight() + 10);

            } else {

                int xxx = (getWidth() - (getWidth() - 20)) / 2;
                int yyy = (getHeight() - (getHeight() - 20)) / 2;



                //g2.setColor(Color.red);
                // g2.drawRect(xxx, yyy, getWidth() - 20, getHeight() - 20);
                g2.setFont(new java.awt.Font("Dialog", 1, 18));
                g2.setColor(color);

                centerString(msg, g2, 0, getHeight() / 2);
            //  g2.setFont(new java.awt.Font("Dialog",2,15));
              //  g2.drawString("1. Click refresh button on the applet.", 100, 80);
              //  g2.drawString("2. Try later.", 100, 100);

            }
        }

        public void update() {
            repaint();
        }
    }

    public void start() {

    }
}
