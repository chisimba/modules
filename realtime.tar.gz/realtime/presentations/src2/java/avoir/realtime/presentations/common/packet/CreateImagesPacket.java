/*
 * CreateImagesPacket.java
 *
 * Created on October 25, 2007, 1:25 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package avoir.realtime.presentations.common.packet;

/**
 *
 * @author dwafula
 */
public class CreateImagesPacket implements PresentationsPacket {
    public String path;
    /** Creates a new instance of CreateImagesPacket */
    public CreateImagesPacket(String path) {
        this.path=path;
    }
    
    public String getPath(){
        return path;
    }
}
