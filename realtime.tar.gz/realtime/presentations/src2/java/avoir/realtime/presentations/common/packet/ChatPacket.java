/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package avoir.realtime.presentations.common.packet;
import avoir.realtime.User;

/**
 * Packet that stores information about a Chat event
 */
@SuppressWarnings("serial")
public class ChatPacket implements PresentationsPacket {

    User usr;
    String content;
    String time;
    boolean presenter = false;
    boolean systemMessage = false;
    
    public String logFilePath="ChatLog.txt";
    /**
     * Constructor
     * @param usr The person who sent this message
     * @param content The contents of the message
     * @param time The time message was send
     */

    public ChatPacket(User usr, String content, String time, boolean presenter, boolean systemMessage,String logFilePath) {
        this.usr = usr;
        this.content = content;
        this.time = time;
        this.presenter = presenter;
        this.systemMessage = systemMessage;
        this.logFilePath=logFilePath;
    }

    /**
     * Returns the user who wrote this message
     * @return the user
     */
    public User getUser() {
        return this.usr;
    }

    public boolean isPresenter() {
        return presenter;
    }

    public boolean isSystemMessage() {
        return systemMessage;
    }
    /**
     * Returns the contents of this message
     * @return String content
     */

    public String getContent() {
        return this.content;
    }
    /**
     * Gets the path of file to where log chats are stored
     * @return
     */
    public String getLogFilePath(){
        return this.logFilePath;
    }

    /**
     * Returns the time the message was send
     * @return String
     */
    public String getTime() {
        return this.time;
    }

    /**
     * Creates a string with the User's name and their message
     * @return Format- "User:" message"
     */
    public String toString() {
        return "["+getTime()+"] <"+ usr + "> " + content;
        
    }
}
