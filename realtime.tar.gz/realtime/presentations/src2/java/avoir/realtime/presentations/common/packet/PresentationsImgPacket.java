/*
 * PresentationImgPacket.java
 *
 * Created on October 21, 2007, 9:46 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package avoir.realtime.presentations.common.packet;
import javax.swing.ImageIcon;
/**
 *
 * @author dwafula
 */
public class PresentationsImgPacket implements PresentationsPacket {
    ImageIcon img;
    int slideNo;
    int totalSlides;
    String id;
    /** Creates a new instance of PresentationImgPacket */
    public PresentationsImgPacket(ImageIcon img,int slideNo,String id,int totalSlides) {
        this.img=img;
        this.slideNo=slideNo;
        this.totalSlides=totalSlides;
        this.id=id;
    }
    
    public String getId(){
        return id;
    }
    
    public ImageIcon getImage(){
        return img;
    }
    
    public int getSlideNo(){
        return slideNo;
    }
    
        public int getSlideCount(){
        return totalSlides;
    }
}

