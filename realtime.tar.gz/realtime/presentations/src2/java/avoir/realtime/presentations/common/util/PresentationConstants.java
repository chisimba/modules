/**
 * Copyright (C) GNU/GPL AVOIR 2007
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 51
 * Franklin St, Fifth Floor, Boston, MA 02110-1301 USA
 */
package avoir.realtime.presentations.common.util;

public class PresentationConstants {

    public static int DEFAULT_OUTLINE_FONT_SIZE = 12;
    public static int DEFAULT_SERVER_PORT = 1962;
    public static String CHISIMBA_USERS_DIR = "/opt/lampp/htdocs/chisimba/app/usrfiles/users";
    public static boolean PRESENTER = true;
    public static boolean VIEWER = false;
    public static boolean NEW_USER=true;
    public static boolean OLD_USER=false;
    public static boolean SYSTEM_MESSAGE=true;
    public static boolean USER_MESSAGE=false;
}
