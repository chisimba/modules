/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package avoir.realtime.presentations.common.util;

import javax.swing.*;
import java.util.Vector;
import java.awt.*;
import java.awt.event.*;

import avoir.realtime.presentations.client.viewer.ClientViewer;
import avoir.realtime.presentations.client.presenter.PresenterFrame;
import avoir.realtime.presentations.common.packet.RequestFilePacket;
/**
 *
 * @author dwafula
 */

public class JMFDiagnostics extends JPanel {

    Vector jmf = new Vector();
    JToggleButton installButton = new JToggleButton("Install JMF");
    public JTextArea ta = new JTextArea();
    ClientViewer cv;
    PresenterFrame pf;

    public JMFDiagnostics(ClientViewer cv) {
        this.cv = cv;
        init();
    }

    public JMFDiagnostics(PresenterFrame pf) {
        this.pf = pf;
        init();
    }

    public void init() {
        setLayout(new BorderLayout());
        add(new JScrollPane(ta), BorderLayout.CENTER);
        JPanel p = new JPanel();
        p.add(installButton);
        //  installButton.setEnabled(false);
        ta.setEditable(false);
        installButton.addActionListener(new ActionListener() {

                    public void actionPerformed(ActionEvent e) {
                        installJMF();

                    }
                });
        add(p, BorderLayout.SOUTH);
    }

    public void installJMF() {
        setStatusMessage("Installing JMF 2.1.1e ...", new Color(0, 131, 0));
        Thread t = new Thread() {

                    String[] fileList = {"jmf.properties",
                            "jmf.properties.orig",
                            "libjmcvid.so",
                            "libjmdaud.so",
                            "libjmfjawt.so",
                            "libjmg723.so",
                            "libjmgsm.so",
                            "libjmh261.so",
                            "libjmh263enc.so",
                            "libjmjpeg.so",
                            "libjmmpa.so",
                            "libjmmpegv.so",
                            "libjmmpx.so",
                            "libjmutil.so",
                            "libjmv4l.so",
                            "libjmxlib.so",
                            "mediaplayer.jar",
                            "multiplayer.jar",
                            "video.jar",
                            "jmf.jar",//should be last :)

                    };
                    public void run() {
                        installButton.setEnabled(false);
                        if (pf != null) {
                            for (int i = 0; i < fileList.length; i++) {
                                setStatusMessage("Copying " + fileList[i] + "...", new Color(0, 131, 0));
                                pf.connector.sentPacket(new RequestFilePacket(pf.jmfPath + "/" + fileList[i], fileList[i]));
                            }
                            setStatusMessage("Ready", new Color(0, 131, 0));

                        }
                        if (cv != null) {
                            for (int i = 0; i < fileList.length; i++) {
                                setStatusMessage("Copying " + fileList[i] + "...", new Color(0, 131, 0));
                                cv.connector.sentPacket(new RequestFilePacket(cv.jmfPath + "/" + fileList[i], fileList[i]));
                            }
                            setStatusMessage("Ready", new Color(0, 131, 0));
                        }
                        installButton.setEnabled(true);
                        installButton.setSelected(false);
                    }
                };
        t.start();

    }

    private void setStatusMessage(String msg, Color color) {
        if (pf != null) {
            pf.setStatusText(msg, color);
        }
        if (cv != null) {
            cv.setStatusText(msg, color);
        }
    }

    public void start() {
        ta.setText("");
        jmf.clear();
        boolean flag2 = false;
        float f2 = 0.0F;
        Class clz;
        String string1 = "JMF Diagnostics:\n\n";
        jmf.addElement(string1);
        string1 = "Java 1.1 compliant browser.....";
        // Check for JDK.
        try {
            Class.forName("java.awt.event.ComponentAdapter");
            string1 = new StringBuffer(String.valueOf(string1)).append("Maybe\n").toString();
            jmf.addElement(string1);
            string1 = "JMF classes.....";
        } catch (Throwable throwable1) {
            string1 = new StringBuffer(String.valueOf(string1)).append("No\n").toString();
            jmf.addElement(string1);
            showStatus();
            return;
        }


        // Check for basic JMF classes.
        try {
            Class.forName("javax.media.Player");
            string1 = new StringBuffer(String.valueOf(string1)).append("Found\n").toString();
            boolean flag1 = false;
            float f1 = 0.0F;
            jmf.addElement(string1);
            clz = null;
             showPlayer();
        } catch (Throwable throwable2) {
            string1 = new StringBuffer(String.valueOf(string1)).append("Not Found\n").toString();
            jmf.addElement(string1);
            showStatus();
            return;
        }


        // Identify the versions.
        try {
            Class.forName("com.sun.media.util.LoopThread");

            flag2 = true;
            f2 = 0.0F;
        } catch (Throwable throwable3) {

        }


        if (flag2) {

            // Identify the 2.0 minor versions.
            try {
                clz = Class.forName("avoir.realtime.presentations.common.util.QueryJMF20");
                f2 = 2.0F;
            } catch (Throwable throwable4) {

            }

            if (f2 < 2.0F) {
                // Check for v1.1
                try {
                    clz = Class.forName("avoir.realtime.presentations.common.util.QueryJMF11");
                    f2 = 1.1F;
                } catch (Throwable throwable5) {
                }
            }

            if (f2 < 1.1) {
                // Check for v1.0
                try {
                    clz = Class.forName("avoir.realtime.presentations.common.util.QueryJMF10");
                    f2 = 1.02F;
                } catch (Throwable throwable6) {
                }
            }

            if (f2 >= 1.02 && clz != null) {
                QueryJMF queryJMF = null;
                try {
                    queryJMF = (QueryJMF) clz.newInstance();
                    String string2 = queryJMF.getVersion();
                    String string3 = queryJMF.getDetails();
                    string1 = "\nJMF Version... " + string2 + "\n\n";
                    string1 = new StringBuffer(String.valueOf(string1)).append(string3).toString();
                    jmf.addElement(string1);

                    showStatus();
                    return;
                } catch (Throwable throwable7) {
                }
            }

            string1 = new StringBuffer(String.valueOf("")).append("\nJMF Version... pre 1.0.2\n").toString();
            jmf.addElement(string1);
            string1 = new StringBuffer(String.valueOf("")).append("Please upgrade to a newer version\n").toString();
            jmf.addElement(string1);
            showStatus();
            showPlayer();
            return;
        }

        string1 = new StringBuffer(String.valueOf("")).append("\nUnknown JMF implementation!\n").toString();
        jmf.addElement(string1);
        //      repaint();
        showStatus();

    }

    public void showPlayer() {
/*
        if (pf != null) {
            if (pf.mediaTP.getTabCount() < 2) {
                pf.mediaTP.addTab("Voice", new JPanel());
                pf.mediaTP.setSelectedIndex(1);
            }
        }
        if (cv != null) {
            if (cv.mediaTP.getTabCount() < 2) {
                avoir.realtime.video.transmitter.engine.CaptureUtil util = new avoir.realtime.video.transmitter.engine.CaptureUtil();
                javax.media.Player player = util.transmitLive();
                if (player != null) {
                    player.realize();

                    JPanel p = new JPanel();
                    p.setLayout(new BorderLayout());
                    p.add(player.getVisualComponent(), BorderLayout.CENTER);
                    p.add(player.getControlPanelComponent(), BorderLayout.SOUTH);
                    Utils.err("There");
                    cv.mediaTP.addTab("Voice", p);
                    cv.mediaTP.setSelectedIndex(1);
                }
            }
        }*/
    }

    public void showStatus() {
        for (int i = 0; i < jmf.size(); i++) {
            ta.append((String) jmf.elementAt(i));
        }
    }
}
