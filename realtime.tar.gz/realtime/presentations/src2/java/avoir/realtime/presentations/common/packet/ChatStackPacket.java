/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package avoir.realtime.presentations.common.packet;

import java.util.Stack;
/**
 *
 * @author dwafula
 */
public class ChatStackPacket implements PresentationsPacket{
    public Stack chatStack;
    public ChatStackPacket(Stack chatStack){
        this.chatStack=chatStack;
    }

    public Stack getChatStack(){
        return chatStack;
    }
}
