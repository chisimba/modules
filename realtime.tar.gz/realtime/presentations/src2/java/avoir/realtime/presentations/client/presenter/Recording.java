/*
 * Recording.java
 *
 * Created on October 31, 2007, 11:43 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package avoir.realtime.presentations.client.presenter;

public class Recording {
    int slideNo;
    long time;
    
    public Recording(int slideNo,long time){
        this.slideNo=slideNo;
        this.time=time;
    }
    
    public int getSlideNo(){
        return slideNo;
    }
    public long getTime(){
        return time;
    }
}
