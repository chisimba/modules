/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package avoir.realtime.presentations.common.packet;

/**
 *
 * @author dwafula
 */
public class BroadcastRequestPacket implements PresentationsPacket {

    String id;

    public BroadcastRequestPacket(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }
}
