package avoir.realtime.presentations.client;

import javax.swing.*;
import java.awt.*;
import avoir.realtime.User;
//import avoir.realtime.presentations.common.packet.UserPacket;

public class ChatFrame extends JInternalFrame {

    ChatPanel chatPanel;
    User user;

    public ChatFrame(ChatPanel chatPanel, User user) {
        this.chatPanel = chatPanel;
        this.user = user;
        init();

    }

    public void init() {
        JPanel mPanel = (JPanel) this.getContentPane();
        setResizable(true);
        mPanel.setLayout(new BorderLayout());
        UIManager.put("TabbedPane.selected", new Color(238, 238, 238));
        final JTabbedPane tP = new JTabbedPane();
        tP.setUI(new javax.swing.plaf.metal.MetalTabbedPaneUI() {

                    protected void paintContentBorder(Graphics g, int tabPlacement, int selectedIndex) {
                        tP.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));//10, to stand-out, reduce to whatever
                    }
                });
        //setBackground(new Color(0, 0, 0, 0));
        //putClientProperty("JInternalFrame.isPalette", Boolean.TRUE);
        //setUI(new NoBorderInternalFrameUI(this));
        tP.setFont(new Font("Dialog", 0, 10));
        tP.addTab("Chat", chatPanel);
        setTitle("ME: "+user.getFullName());
        mPanel.add(tP, BorderLayout.CENTER);
        setSize(250, 200);

        setVisible(true);


    }
}