package avoir.realtime.presentations.common.packet;

public class RequestContentPacket implements PresentationsPacket{
    String id;
    public RequestContentPacket(String id){
        this.id=id;
    }
    
    public String getId(){
        return id;
    }
}
