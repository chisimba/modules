/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package avoir.realtime.presentations.common.packet;

/**
 *
 * @author dwafula
 */
public class FilePacket implements PresentationsPacket{

    byte[] byteArray;
    String filename;
    public FilePacket(byte[] byteArray,String filename) {
        this.byteArray = byteArray;
        this.filename=filename;
    }
    
    public String getFilename(){
        return filename;
    }

    public byte[] getByteArray() {
        return byteArray;
    }
}
