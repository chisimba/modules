/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package avoir.realtime.presentations.client.presenter;

import avoir.realtime.User;
import avoir.realtime.applet.RealtimeApplet;

import avoir.realtime.presentations.client.ChatFrame;
import avoir.realtime.presentations.client.presenter.Surface;
import avoir.realtime.presentations.client.ChatPanel;
import avoir.realtime.presentations.client.util.*;
import avoir.realtime.presentations.common.util.*;
import avoir.realtime.presentations.common.packet.*;
import avoir.realtime.presentations.client.*;
import avoir.realtime.presentations.common.util.PresentationConstants;
import avoir.realtime.presentations.client.sound.*;

import javax.swing.*;
import javax.swing.event.*;

import java.awt.*;
import java.awt.event.*;
import java.util.logging.*;
import java.util.*;
import java.io.*;

/**
 *
 * @author dwafula
 */
public class PresenterFrame extends avoir.realtime.applet.RealtimeApplet implements ActionListener {

    private static Logger logger = Logger.getLogger(PresenterFrame.class.getName());
    ImageIcon slideIcon = Utils.createImageIcon("/icons/slide.gif", "");
    ImageIcon logoIcon = Utils.createImageIcon("/icons/logo.jpg", "");
    ImageIcon nextIcon = Utils.createImageIcon("/icons/rightarrow.png", "");
    ImageIcon backIcon = Utils.createImageIcon("/icons/leftarrow.png", "");
    ImageIcon firstIcon = Utils.createImageIcon("/icons/2leftarrow.png", "");
    ImageIcon lastIcon = Utils.createImageIcon("/icons/2rightarrow.png", "");
    JButton nextButton = new JButton(nextIcon);
    JButton backButton = new JButton(backIcon);
    JButton firstButton = new JButton(firstIcon);
    JButton lastButton = new JButton(lastIcon);
    JPanel slidesPanel = new JPanel();
    static String host = "xlocalhost";
    static int port = PresentationConstants.DEFAULT_SERVER_PORT;
    public User user;
    public String contentBasePath = ".";
    JPanel leftPanel = new JPanel();
    JPanel rightPanel = new JPanel();
    public Connector connector;
    public Surface surface;
    public JLabel statusBar = new JLabel();
    boolean slideSelected = false;
    JTabbedPane tabbedPane = new JTabbedPane();
    public JLabel infoLabel = new JLabel("PRESENTER: Unknown");
    public boolean loadingDone = false;
    private JLabel slideNoLabel = new JLabel();
    public int slideNo = 0;
    JMenuBar menubar = new JMenuBar();
    JDesktopPane mainDesktop = new JDesktopPane();
    public ChatPanel chatPanel;
    public String slideId;
    //    JFileChooser fc = new JFileChooser();

    //public String fullnames;

    ToolBox toolBox;
    JSplitPane leftSplitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
    //JSplitPane rightSplitPane = new JSplitPane();

    JSplitPane topLeftSplitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
    public DynamicTree audiencePanel = new DynamicTree();
    int appletHeight = 600;// appletSize.height;

    int appletWidth = 800;// appletSize.width;

    public JMFDiagnostics jmfPanel;
    public String jmfPath;
    public JTabbedPane mediaTP = new JTabbedPane();
    /**
     * Initialization method that will be called after the applet is loaded
     * into the browser.
     */

    public void init() {
        this.host = getCodeBase().getHost();
        this.port = Integer.parseInt(this.getParameter("port"));
        this.contentBasePath = this.getParameter("contentBasePath");
        // this.user = this.getParameter("user");
        this.slideId = this.getParameter("slideId");
        //  this.fullnames = this.getParameter("fullname");
        this.jmfPath = this.getParameter("jmfResourcePath");
        Dimension appletSize = this.getSize();
        appletHeight = appletSize.height;
        appletWidth = appletSize.width;
        surface = new Surface();
        jmfPanel = new JMFDiagnostics(this);
        toolBox = new ToolBox(this);
        leftPanel.setLayout(new BorderLayout());
        leftPanel.add(new AboutPanel(), BorderLayout.NORTH);
        mainDesktop.setDragMode(JDesktopPane.OUTLINE_DRAG_MODE);

        user = getCurrentUser();

        slidesPanel.add(firstButton);
        slidesPanel.add(backButton);
        slidesPanel.add(slideNoLabel);
        slidesPanel.add(nextButton);
        slidesPanel.add(lastButton);

        firstButton.addActionListener(this);
        firstButton.setActionCommand("first");

        nextButton.addActionListener(this);
        nextButton.setActionCommand("next");

        backButton.addActionListener(this);
        backButton.setActionCommand("back");

        lastButton.addActionListener(this);
        lastButton.setActionCommand("last");

        rightPanel.setLayout(new BorderLayout());

        mainDesktop.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        createSurfaceFrame();
        createAudienceFrame();
        createMediaFrame();





        //toolBox.setVisible(true);
        //addFrame(toolBox, 630, 10);

        this.setJMenuBar(menubar);
        buildMenu();
        add(statusBar, java.awt.BorderLayout.SOUTH);
        add(mainDesktop, java.awt.BorderLayout.CENTER);

        connect();

    }

    private void createSurfaceFrame() {
        JInternalFrame board = new JInternalFrame();//"Surface", true, true, true, true);
        final JTabbedPane pp = new JTabbedPane();
        pp.addTab("Slides", slidesPanel);
        pp.setBorder(BorderFactory.createLineBorder(Color.BLACK));

        JPanel sP = new JPanel();
        sP.setLayout(new BorderLayout());
        sP.add(surface, BorderLayout.CENTER);

        sP.add(pp, BorderLayout.SOUTH);

        board.getContentPane().setLayout(new BorderLayout());
        board.getContentPane().add(sP, BorderLayout.CENTER);
        //board.setUI(new NoBorderInternalFrameUI(board));
        board.setResizable(true);
        board.putClientProperty("JInternalFrame.isPalette", Boolean.TRUE);
        board.setSize(600, 500);
        //board.setLocation((appletWidth - board.getWidth()) / 2, 20);
        board.setLocation(300, 20);
        board.setVisible(true);
        addFrame(board);
    }

    private void createMediaFrame() {
        try {

            JInternalFrame mediaFrame = new JInternalFrame();
            mediaTP.setBorder(BorderFactory.createLineBorder(Color.BLACK));
            mediaTP.setUI(new javax.swing.plaf.metal.MetalTabbedPaneUI() {

                        protected void paintContentBorder(Graphics g, int tabPlacement, int selectedIndex) {
                            mediaTP.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));//10, to stand-out, reduce to whatever
                        }
                    });
            mediaTP.addTab("Voice/Video", jmfPanel);


            mediaFrame.getContentPane().setLayout(new BorderLayout());
            mediaFrame.getContentPane().add(mediaTP, BorderLayout.CENTER);
            //mediaFrame.setUI(new NoBorderInternalFrameUI(mediaFrame));
            mediaFrame.setResizable(true);
            mediaFrame.putClientProperty("JInternalFrame.isPalette", Boolean.TRUE);
            mediaFrame.setSize(250, 200);
            mediaFrame.setLocation(10, 20);
            mediaFrame.setVisible(true);
            addFrame(mediaFrame);
            jmfPanel.start();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void createAudienceFrame() {
        try {

            JInternalFrame audienceFrame = new JInternalFrame();
            UIManager.put("TabbedPane.selected", new Color(238, 238, 238));

            final JTabbedPane tP = new JTabbedPane();
            tP.setUI(new javax.swing.plaf.metal.MetalTabbedPaneUI() {

                        protected void paintContentBorder(Graphics g, int tabPlacement, int selectedIndex) {
                            tP.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));//10, to stand-out, reduce to whatever
                        }
                    });
            tP.setFont(new Font("Dialog", 0, 10));
            tP.addTab("Audience", audiencePanel);
            audienceFrame.getContentPane().setLayout(new BorderLayout());
            audienceFrame.getContentPane().add(tP, BorderLayout.CENTER);
            //mediaFrame.setUI(new NoBorderInternalFrameUI(mediaFrame));
            audienceFrame.setResizable(true);
            audienceFrame.putClientProperty("JInternalFrame.isPalette", Boolean.TRUE);
            audienceFrame.setSize(250, 200);
            audienceFrame.setLocation(50, 200);
            audienceFrame.setVisible(true);
            addFrame(audienceFrame);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void start() {

    }

    /**
   * gets the time message was received (send?)
   * @return String
   */
    public String getTime() {
        java.util.Date today;
        String result;
        java.text.SimpleDateFormat formatter;

        formatter = new java.text.SimpleDateFormat("dd-MM-yyyy-H:m:s",
                new java.util.Locale("en_US"));
        today = new java.util.Date();
        result = formatter.format(today);
        return result;

    }

    public void doPostConnectStuff() {

        setStatusText("Connected to host: " + host +
                " port: " + new Integer(port).toString(), new Color(0, 131, 0));
        connector.sentPacket(new CreateImagesPacket(contentBasePath));

        //   mf.surface.msg = "Waiting for slides from server...Please wait :)";
        surface.msg = "No slides detected yet.";

        surface.color = new Color(0, 131, 0);
        surface.repaint();



        //                                infoLabel.setText("PRESENTER: " + fullnames);
        connector.sentPacket(new UserPacket(user, PresentationConstants.NEW_USER));

        setStatusText("Connected to host: " + host +
                " port: " + new Integer(port).toString(), new Color(0, 131, 0));
        chatPanel =
                new ChatPanel(connector, user, PresentationConstants.PRESENTER);

        ChatFrame fr = new ChatFrame(chatPanel, user);
        try {
            fr.setLocation(10, 300);
            mainDesktop.add(fr, new Integer(1));
            fr.setSelected(true);
            connector.sentPacket(new ChatPacket(user, "*\n\n+++++++++++++++++++++++++++++\n\n" + user.toString() + " starts Presentation at " + getTime() + "\n\n+++++++++++++++++++++++++++++\n\n.",
                    "", PresentationConstants.VIEWER, PresentationConstants.SYSTEM_MESSAGE, contentBasePath));
        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }

    private void connect() {
        setStatusText("Connecting to " + host + ": " + port + " ...", Color.RED);
        Thread t = new Thread() {

                    public void run() {

                        connector = new Connector(host, port, PresenterFrame.this, contentBasePath, user);
                        connector.connect();

                    }
                };
        t.start();

    }

    public void addFrame(JInternalFrame fr) {
        try {
            fr.setSelected(true);
            mainDesktop.add(fr);

        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }

    private void buildMenu() {
        JMenu menu = new JMenu("File");
        menu.setFont(new Font("Dialog", 0, 10));
        //menu.add(createMenuItem("Open", "open"));
        menu.add(createMenuItem("Connect", "connect"));
        menu.addSeparator();
        menu.add(createMenuItem("Exit", "exit"));
        menubar.add(menu);
        menu =
                new JMenu("Help");
        menu.setFont(new Font("Dialog", 0, 10));

        menu.add(createMenuItem("About", "about"));

        menubar.add(menu);

    }

    /**
     * Create a menut item
     *
     * @param text :
     *            text of menu
     * @param action:
     *            action command
     * @return
     */
    public JMenuItem createMenuItem(String text, String action) {
        JMenuItem menuItem = new JMenuItem(text);
        menuItem.setFont(new Font("Dialog", 0, 10));
        menuItem.setActionCommand(action);
        menuItem.addActionListener(this);
        return menuItem;
    }

    private void generateImgs(String filename) {




    }

    public void setSlideMessage(String txt, Color color) {
        slideNoLabel.setForeground(color);
        slideNoLabel.setText(txt);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("open")) {

        }
        if (e.getActionCommand().equals("about")) {
            Utils.msg("AVOIR PROJECT\nReal Time Presentations, Beta Version\nBuild 1-" + Version.version);
        }

        if (e.getActionCommand().equals("connect")) {
            connect();
        }

        if (e.getActionCommand().equals("next")) {
            if (slideNo < surface.content.size() - 1) {
                if (surface != null) {
                    if (loadingDone && slideNo <= surface.content.size() - 1) {
                        slideNo++;
                        setSlideMessage("Slide " + (slideNo + 1) + " of " + surface.content.size(), Color.BLACK);
                        surface.pageNo = slideNo;
                        //  surface.repaint();
                        connector.broadcastSlide();
                        slideSelected =
                                true;
                    }

                }
            }
        }

        if (e.getActionCommand().equals("back")) {
            if (slideNo > 0) {
                if (surface != null) {
                    if (loadingDone && slideNo <= surface.content.size()) {
                        slideNo--;
                        setSlideMessage("Slide " + (slideNo + 1) + " of " + surface.content.size(), Color.BLACK);

                        surface.pageNo = slideNo;
                        //surface.repaint();
                        connector.broadcastSlide();
                        slideSelected =
                                true;
                    }

                }
            }
        }
        if (e.getActionCommand().equals("first")) {
            if (surface != null) {
                if (loadingDone && slideNo <= surface.content.size()) {
                    slideNo = 0;
                    setSlideMessage("Slide " + (slideNo + 1) + " of " + surface.content.size(), Color.BLACK);

                    surface.pageNo = slideNo;
                    //  surface.repaint();
                    connector.broadcastSlide();
                    slideSelected =
                            true;
                }

            }
        }


        if (e.getActionCommand().equals("last")) {
            if (surface != null) {
                if (loadingDone && slideNo <= surface.content.size()) {
                    slideNo = surface.content.size() - 1;
                    setSlideMessage("Slide " + (slideNo + 1) + " of " + surface.content.size(), Color.BLACK);

                    surface.pageNo = slideNo;
                    // surface.repaint();
                    connector.broadcastSlide();
                    slideSelected =
                            true;
                }

            }
        }
    }

    public JButton createButton() {
        JButton b = new JButton();
        b.setContentAreaFilled(false);
        b.setBorderPainted(false);
        return b;
    }

    public void addSlide(ImageIcon slide) {
        surface.content.addElement(slide);

    }

    public void setStatusText(String msg, Color color) {
        statusBar.setForeground(color);
        statusBar.setText(msg);
    }

    public ImageIcon getCurrentSlide() {
        ImageIcon img = null;
        Vector slides = surface.content;
        if (slides.size() > 0) {
            int index = slideNo;
            if (index == -1) {
                index = 0;
            }

            img = (ImageIcon) slides.elementAt(index);
            return img;

        }

        return new ImageIcon();
    }

    public int getCurrentSlideIndex() {
        return slideNo;
    }

    class AboutPanel extends JPanel {

        Image image = logoIcon.getImage();

        public AboutPanel() {
            this.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
            this.setBackground(Color.WHITE);
            setPreferredSize(new Dimension(300, 200));
        }

        public void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            int xx = (getWidth() - image.getWidth(this)) / 2;
            int yy = (getHeight() - image.getHeight(this)) / 2;

            g2.setColor(new Color(0, 131, 0));

            g2.drawImage(image, xx, yy, this);
        }
    }

    public void destroy() {
        connector.sentPacket(new QuitPacket());

        connector.sentPacket(new ChatPacket(user, user + " has stopped presentation.",
                "", PresentationConstants.VIEWER, PresentationConstants.SYSTEM_MESSAGE, contentBasePath));

    }
    // TODO overwrite start(), stop() and destroy() methods

}
