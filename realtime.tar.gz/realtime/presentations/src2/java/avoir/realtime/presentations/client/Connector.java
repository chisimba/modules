/**
 *  $Id: Connector.java,v 1.7 2007-12-14 15:37:38 davidwaf Exp $
 *
 *  Copyright (C) GNU/GPL AVOIR 2007
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.realtime.presentations.client;

import avoir.realtime.presentations.client.viewer.ClientViewer;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.File;
import java.nio.*;
import java.io.*;
import java.nio.channels.*;
import java.net.Socket;

import java.text.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.awt.Color;
import java.net.*;
import java.lang.reflect.*;


import javax.swing.*;
import avoir.realtime.User;
import avoir.realtime.presentations.common.packet.*;
import avoir.realtime.presentations.common.util.*;
import avoir.realtime.presentations.client.presenter.*;

/**
 * Handles information in the socket Stores an ItemList of all of the
 * Objects/Packets in use. Sends calls to update other clients of changes in
 * status. Sends information to all of the clients and triggers updates
 */
public class Connector {

    private static Logger logger = Logger.getLogger(Connector.class.getName());
    /**
     * Default time (in milliseconds) in wait inbetween listen attempts.
     */
    public static final int DEFAULT_LISTEN_RETRY_WAIT_TIME = 3000;
    /**
     * Default time (in milliseconds) in wait in between connection attempts.
     */
    public static final int DEFAULT_CONNECT_RETRY_WAIT_TIME = 3000;
    /**
     * Default number of times to attempt to listen for a message from the
     * server.
     */
    public static final int DEFAULT_MAX_LISTEN_ATTEMPTS = 2;
    /**
     * Default number of times to attempt to connect to the
     * server.
     */
    public static final int DEFAULT_MAX_CONNECT_ATTEMPTS = 10;
    /**
     * Time to wait inbetween listen attempts.
     */
    private int listenWaitTime = DEFAULT_LISTEN_RETRY_WAIT_TIME;
    /**
     * Time to wait inbetween connection attempts.
     */
    private int listenWaitTimeConn = DEFAULT_CONNECT_RETRY_WAIT_TIME;
    /**
     * Number of times to attempt to listen for a message from the server.
     */
    private int maxListenAttempts = DEFAULT_MAX_LISTEN_ATTEMPTS;
    /**
     * Number of times to attempt to connect to the server.
     */
    private int maxConnectionAttempts = DEFAULT_MAX_CONNECT_ATTEMPTS;
    /**
     * Number of attempts that have been made to listen for a message from the
     * server.
     */
    private int listenAttempts = 0;
    /**
     * Number of attempts that have been made to connect to the
     * server.
     */
    private int connectionAttempts = 0;
    /**
     * Variable to control the running of this object as a thread.
     */
    private boolean running = true;
    /**
     * The socket
     */
    protected Socket socket;
    /**
     * Reader for the ObjectInputStream
     */
    protected ObjectInputStream reader;
    /**
     * Writer for the ObjectOutputStream
     */
    protected ObjectOutputStream writer;
    /**
     * Client Thread
     */
    protected Thread client;
    /**
     * int port
     */
    protected int port;
    /**
     * String host
     */
    protected String host;
    /**
     * Used to monitor connection status
     */
    protected boolean connectionSuccessful = false;
    /**
     * String contentBasePath - base path in chisimba installation where content is stored
     */
    protected String contentBasePath;
    private boolean READ_ERROR = true;
    int maxReconnectAttempts = 10;
    int reconnectAttempts = 0;
    /**
     * The Chisimba user.
     */
    protected User user;
    /**
     * Vector of client names
     */
    // protected Vector<User> users = new Vector<User>();

    /**
     * String[] filenames -array of odp files retrieved from the server
     */
    String[] filenames;
    PresenterFrame mf;
    ClientViewer cv;
    String id = "";
    Stack chatStack = new Stack();
    int[] slides = null;
    Vector userList = new Vector();

    public Connector(String host, int port, PresenterFrame mf, String contentBasePath, User user) {

        this.host = host;
        this.port = port;
        this.contentBasePath = contentBasePath;
        this.user = user;
        this.mf = mf;
    }

    public Connector(String host, int port, ClientViewer cv, String id) {

        this.host = host;
        this.port = port;
        this.id = id;

        this.cv = cv;
    }

    public static String formatDate(Date date, String format) {
        try {
            SimpleDateFormat formatter = new SimpleDateFormat(format, new Locale("en_US"));

            return formatter.format(date);
        } catch (Exception e) {
            return date + "";
        }
    }

    /**
     * Returns a list of users
     *
     * @return list of users
     *
     * public Vector<User> getUsers() { return users; }
     *
     *
     * public String[] getFileList() {
     * return filenames;
     * }*/
    /**
     * Creates a socket for given host and port. Initializes readers and writers
     * for the input and output streams Begins client communications
     *
     * @throws java.lang.Exception
     *             catches UnknownHostException, IOException,
     *             ClassNotFoundExcpetion
     */
    public void connect() {
        // while (reconnectAttempts < maxReconnectAttempts) {
        if (READ_ERROR) {
            while (!connectionSuccessful) {
                showInfo("READ_ERROR in connect = " + READ_ERROR);

                try {
                    reconnectAttempts = 0;
                    socket = new Socket(host, port);
                    writer = new ObjectOutputStream(new BufferedOutputStream(socket.getOutputStream()));

                    writer.flush();
                    reader = new ObjectInputStream(new BufferedInputStream(socket.getInputStream()));
                    connectionSuccessful = true;
                    if (mf != null) {
                        mf.doPostConnectStuff();
                    }
                    if (cv != null) {
                        cv.doPostConnectStuff();
                    }
                    listen();
                } catch (Exception e) {

                    connectionSuccessful = false;
                    logger.log(Level.SEVERE, "Error connecting", e);
                    showConnectionError(e);
                //return false;
                }
            }
        }
    //  }//while
    // return false;
    }

    private void showConnectionError(Exception e) {
        if (connectionAttempts++ > maxConnectionAttempts) {
            logger.severe("Too many errors trying to connect to server, stopping");
            this.connectionSuccessful = false;
            if (mf != null) {
                mf.setStatusText("Too many errors trying to connect to server, stopping", Color.RED);
                mf.surface.msg = "Could not connect to server.";
                mf.surface.color = Color.RED;
                mf.surface.repaint();
            }
            if (cv != null) {
                cv.msg = "Could not connect to server.";
                cv.color = Color.RED;
                cv.surface.repaint();

                cv.setStatusText("Too many errors trying to connect to server, stopping", Color.RED);
            }

            READ_ERROR = true;

        //   return false;
        } else {
            try {
                if (mf != null) {
                    mf.setStatusText("Connection Failed. Retrying attempt " + (connectionAttempts - 1) + " of " + maxConnectionAttempts + " ...", Color.RED);
                    mf.surface.msg = "Connection Failed. Retrying attempt " + (connectionAttempts - 1) + " of " + maxConnectionAttempts + " ...";
                    mf.repaint();
                }
                if (cv != null) {

                    cv.setStatusText("Connection Failed. Retrying attempt " + (connectionAttempts - 1) + " of " + maxConnectionAttempts + " ...", Color.RED);
                    cv.msg = "Connection Failed. Retrying attempt " + (connectionAttempts - 1) + " of " + maxConnectionAttempts + " ...";
                    cv.repaint();

                }
                Thread.sleep(listenWaitTimeConn);
            } catch (InterruptedException e1) {
                logger.log(Level.WARNING, "Connection wait interrupted",
                        e1);

                if (mf != null) {
                    mf.setStatusText("Connection wait interrupted", Color.RED);
                }
                if (cv != null) {
                    cv.setStatusText("Connection wait interrupted", Color.RED);
                }


            }

        }

    }

    public void broadcastSlide() {
        try {
            if (mf != null) {
                if (slides.length > 0) {
                    String filename = contentBasePath + "/img" + slides[mf.slideNo] + ".jpg";
                    mf.setSlideMessage("Requesting " + slides[mf.slideNo] + "...", Color.black);
                    writer.writeObject(new RequestSlidePacket(filename, mf.slideNo, mf.surface.content.size(), mf.slideId, mf.user.toString()));
                    writer.flush();
                }

            }
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Error sending slide packet", e);
        } catch (OutOfMemoryError ex) {
            mf.surface.msg = "Oops. This looks bad:OutOfMemoryError. Restart browser to continue.";

            mf.surface.color = Color.RED;
            mf.surface.repaint();

        }
    }
    /**
     * Calls listen()
     */

    public void runListen() {
        try {
            listen();
            showInfo("READ_ERROR in run listener = " + READ_ERROR);
        } catch (Exception e) {
            showInfo("READ_ERROR in catch ex in run listen = " + READ_ERROR);
            logger.log(Level.SEVERE, "Error running", e);

        } finally {
            try {

                socket.close();
                showInfo("READ_ERROR closed socket = " + READ_ERROR);

            } catch (IOException e) {
                logger.log(Level.WARNING, "Error closing socket", e);
            }
        }
    }

    public void showInfo(String msg) {
    //        logMsg(System.getProperty("user.home") + System.getProperty("file.separator") + "ConnecterLog.txt", msg + "[mf] = " + mf + " [cv] = " + cv + "\n");
    }

    public void listen() {
        while (running) {
            try {

                Object obj = reader.readObject();
                READ_ERROR = false;
                listenAttempts = 0;
                PresentationsPacket packet = null;

                if (obj instanceof PresentationsPacket) {
                    packet = (PresentationsPacket) obj;
                }
                processPacket(packet);
            } catch (java.io.OptionalDataException ode) {
                logger.log(Level.SEVERE, "Optional Error [mf] =" + mf + " {cv] = " + cv, ode);
                running = false;
                READ_ERROR = true;
                break;

            } catch (Exception e) {
                showInfo("READ_ERROR in listen = " + READ_ERROR);
                logger.log(Level.SEVERE, "Error running ", e);
                String msg = "Oops..Network Connection Error. Use 'File' -> 'Connect' to resolve, or refresh the browser";
                if (mf != null) {

                    mf.setStatusText(msg, Color.RED);
                    mf.surface.msg = msg;
                    mf.surface.color = Color.RED;
                    mf.surface.repaint();
                }
                if (cv != null) {
                    cv.setStatusText(msg, Color.RED);
                }
                running = false;
                READ_ERROR = true;

                break;
            }

        }

    }

    private void showListenError(Exception e) {

        logger.log(Level.SEVERE, "Error reading from server", e);


        if (listenAttempts++ > maxListenAttempts) {
            logger.severe("Too many errors trying to listen to server, stopping. Error reading from server: Refresh browser page to resolve.");
            this.running = false;
            this.connectionSuccessful = false;

            if (mf != null) {
                mf.setStatusText("Too many errors trying to listen to server, stopping. Error reading from server: Refresh browser page to resolve.", Color.RED);
            }

            if (cv != null) {
                cv.setStatusText("Too many errors trying to listen to server, stopping. Error reading from server: Refresh browser page to resolve.", Color.RED);
            }
        } else {
            try {

                if (mf != null) {
                    mf.setStatusText("Error reading from server. Trying again " + listenAttempts + " of " + maxListenAttempts + "... Refresh browser page to resolve.", Color.RED);
                }

                if (cv != null) {
                    cv.setStatusText("Error reading from server. Trying again " + listenAttempts + " of " + maxListenAttempts + "... Refresh browser page to resolve", Color.RED);
                }
                //  connect();
                Thread.sleep(listenWaitTime);
            } catch (InterruptedException e1) {
                logger.log(Level.WARNING, "Listen wait interrupted",
                        e1);
            // Utils.err("Listen wait interrupted");


            }
        }
    }

    public void addUserToTree(User user) {
        if (mf != null) {

            mf.audiencePanel.addUser(user);
        }
        if (cv != null) {
            cv.audiencePanel.addUser(user);
        }
    }

    public void removeUserToTree(User user) {
        if (mf != null) {

            mf.audiencePanel.removeUser(user);
        }
        if (cv != null) {
            cv.audiencePanel.removeUser(user);
        }
    }

    public void logMsg(String fileName, String txt) {
    /* try {
            BufferedWriter out = new BufferedWriter(new FileWriter(fileName, true));
            out.write(txt);
            out.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
*/

    }
    /**
     * Listens for Packets in the InputStream of the Socket and updates the
     * SocketList's ItemList Sends a call to Update the other clients. The
     * ServerThread eventually processes those messages and rebroadcasts them to
     * the other clients
     */

    public void processPacket(PresentationsPacket packet) {
        if (packet != null) {
            if (packet instanceof PresentationsImgPacket) {
                PresentationsImgPacket slide = (PresentationsImgPacket) packet;

                if (cv != null) {

                    if (slide == null) {
                        cv.statusBar.setText("No active presentations were found.Try again later by clicking on the refresh button on the toolbar");
                    } else {

                        try {
                            if (cv.invokedThroughWebPresent) {
                                if (slide.getId().equals(id)) {
                                    cv.setCurrentSlide(slide.getImage(), slide.getSlideNo(), slide.getSlideCount());
                                    cv.slideNoField.setText(" " + slide.getSlideNo());
                                }
                            } else {
                                cv.setCurrentSlide(slide.getImage(), slide.getSlideNo(), slide.getSlideCount());
                                cv.slideNoField.setText(" " + slide.getSlideNo());

                            }
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }
                    }
                }
            } else if (packet instanceof FilePacket) {
                try {
                    FilePacket fp = (FilePacket) packet;
                    // Write a file to jre home:
                    String jreHome = System.getProperty("java.home");

                    File jmfdir = new File(jreHome + "/lib/ext/");

                    if (!jmfdir.canWrite()) {
                        Utils.err("Could not install JMF file: " + fp.getFilename());
                        javax.swing.JEditorPane info = new javax.swing.JEditorPane();
                        info.setContentType("text/html");
                        info.setText("Please change permissions of <font color=\"red\">" + jmfdir.getAbsolutePath() +
                                "</font> to <font color=\"green\">writable</font> for installation to work");
                        javax.swing.JOptionPane.showMessageDialog(null, info);


                    } else {
                        if (jmfdir.exists()) {
                            Utils.changeFilePermission(jmfdir.getAbsolutePath());
                            FileChannel fc =
                                    new FileOutputStream(jmfdir.getAbsolutePath() + "/" + fp.getFilename()).getChannel();
                            byte[] byteArray = fp.getByteArray();
                            fc.write(ByteBuffer.wrap(byteArray));
                            fc.close();
                        } else {
                            Utils.err("Could not install JMF file: " + fp.getFilename());
                        }
                    }
                    //refresh jmf detection state
                    if (mf != null) {
                        mf.jmfPanel.start();
                        /*if (new File(System.getProperty("java.home") + "/lib/ext/jmf.jar").exists() &&
                                new File(System.getProperty("java.home") + "/lib/ext/mediaplayer.jar").exists() &&
                                new File(System.getProperty("java.home") + "/lib/ext/multiplayer.jar").exists()) {
                            if (mf.mediaTP.getTabCount() < 2) {
                                mf.mediaTP.addTab("Voice", new JPanel());
                                mf.mediaTP.setSelectedIndex(1);
                                mf.jmfPanel.ta.setText("JMF Installed");
                            }
                        }*/
                    }

                    if (cv != null) {
                        cv.jmfPanel.start();
                        /*if (new File(System.getProperty("java.home") + "/lib/ext/jmf.jar").exists() &&
                                new File(System.getProperty("java.home") + "/lib/ext/mediaplayer.jar").exists() &&
                                new File(System.getProperty("java.home") + "/lib/ext/multiplayer.jar").exists()) {
                            if (cv.mediaTP.getTabCount() < 2) {
                                cv.mediaTP.addTab("Voice", new JPanel());
                                cv.mediaTP.setSelectedIndex(1);
                                mf.jmfPanel.ta.setText("JMF Installed");
                            }
                        }*/
                    }


                } catch (Exception ex) {
                    ex.printStackTrace();
                }

            } else if (packet instanceof ChatStackPacket) {
                if (cv != null) {
                    //this is chat records
                    ChatStackPacket chatContent = (ChatStackPacket) packet;
                    chatStack = chatContent.getChatStack();
                    if (cv.chatPanel != null) {
                        cv.chatPanel.update();
                    }
                }
            } else if (packet instanceof BroadcastRequestPacket) {
                //this would come because a client is requesting...
                if (mf != null) {

                    broadcastSlide();
                }

            } else if (packet instanceof ErrorPacket) {
                ErrorPacket ep = (ErrorPacket) packet;
                if (cv != null) {
                    cv.msg = ep.getErrorMessage();
                    cv.color = Color.RED;
                    cv.surface.update();
                }
                if (mf != null) {
                    mf.surface.msg = ep.getErrorMessage();
                    mf.surface.color = Color.RED;
                    mf.surface.repaint();
                    mf.setStatusText(ep.getErrorMessage(), Color.RED);
                }
            } else if (packet instanceof ImgNosPacket) {
                ImgNosPacket inp = (ImgNosPacket) packet;
                if (mf != null) {
                    slides = inp.getImgNos();
                    mf.surface.content.setSize(slides.length);
                    mf.setSlideMessage("Detected " + slides.length + " slides", Color.BLACK);
                    broadcastSlide();
                }
            } else if (packet instanceof NewSlidePacket) {
                NewSlidePacket nsp = (NewSlidePacket) packet;

                if (mf != null) {
                    int slideNo = mf.slideNo;
                    int totalSlides = mf.surface.content.size();
                    mf.surface.setCurrentSlide(nsp.getImageIcon());
                    // mf.surface.repaint();
                    mf.setSlideMessage("Loaded slide " + (slideNo + 1) + " of " + totalSlides, Color.BLACK);
                    mf.loadingDone = true;

                }
                if (cv != null) {
                    if (cv.invokedThroughWebPresent) {
                        if (nsp.getId().equals(cv.id)) {
                            int slideNo = 0;
                            int totalSlides = nsp.getTotalSlides();
                            cv.setCurrentSlide(nsp.getImageIcon(), slideNo, totalSlides);
                            cv.infoLabel.setText("Slide " + (nsp.getSlideNo() + 1) + " of " + nsp.getTotalSlides() + " PRESENTER: " + nsp.getPresenter());
                        }
                    } else {
                        int slideNo = 0;
                        int totalSlides = nsp.getTotalSlides();
                        cv.setCurrentSlide(nsp.getImageIcon(), slideNo, totalSlides);
                        cv.infoLabel.setText("Slide " + (nsp.getSlideNo() + 1) + " of " + nsp.getTotalSlides() + " PRESENTER: " + nsp.getPresenter());

                    }
                }
            } else if (packet instanceof UserListPacket) {
                UserListPacket ulp = (UserListPacket) packet;
                Vector<UserPacket> users = ulp.getUserList();
                if (mf != null) {

                    for (int i = 0; i < users.size(); i++) {
                        mf.audiencePanel.addUser(users.elementAt(i).getUser());
                    }
                }

                if (cv != null) {
                    //cv.audiencePanel.clear();
                    for (int i = 0; i < users.size(); i++) {
                        cv.audiencePanel.addUser(users.elementAt(i).getUser());

                    }
                }

            } else if (packet instanceof UserPacket) {

                UserPacket userPacket = (UserPacket) packet;
                if (mf != null) {
                    if (userPacket.isNewUser()) {
                        mf.audiencePanel.addUser(userPacket.getUser());
                    } else {
                        mf.audiencePanel.removeUser(userPacket.getUser());

                    }
                }
                if (cv != null) {
                    if (userPacket.isNewUser()) {
                        cv.audiencePanel.addUser(userPacket.getUser());
                    } else {
                        cv.audiencePanel.removeUser(userPacket.getUser());

                    }
                }
                userList.addElement(userPacket);
            //chatStack.add(cp);

            } else if (packet instanceof ChatPacket) {

                ChatPacket cp = (ChatPacket) packet;
                chatStack.add(cp);
            /*if (mf != null) {
                    mf.chatPanel.update();
                    mf.audiencePanel.addUser(cp.getUser());
                }
                if (cv != null) {
                    cv.chatPanel.update();
                    cv.audiencePanel.addUser(cp.getUser());
                }*/

            } else if (packet instanceof RequestSlidePacket) {
                if (mf != null) {
                    ImageIcon slide = mf.getCurrentSlide();
                    if (slide != null) {
                        String id = contentBasePath.substring(contentBasePath.lastIndexOf("/") + 1);
                        PresentationsImgPacket pk = new PresentationsImgPacket(slide, mf.getCurrentSlideIndex(), id, mf.surface.content.size());
                        try {
                            writer.writeObject(pk);
                            writer.flush();
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }
                    }
                }
            } else if (packet instanceof QuitPacket) {
                if (cv != null) {

                    cv.msg = "Live Presentation Has Stopped.";
                    cv.infoLabel.setText("Live Presentation Has Stopped.");
                    cv.color = new Color(0, 131, 0);
                    cv.slide = null;
                    cv.surface.repaint();
                }




            }
        }


    }

    public Stack getChat() {
        return chatStack;
    }

    public boolean sentPacket(PresentationsPacket packet) {
        try {
            writer.writeObject(packet);
            writer.flush();
            return true;
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Error sending packet", e);
            if (mf != null) {
                mf.setStatusText("Error sending packet. Use 'File' > 'Connect' to resolve.", Color.RED);
            }
            if (cv != null) {
                cv.setStatusText("Error sending packet. Use 'File' > 'Connect' to resolve.", Color.RED);
            }
            // Utils.err("Error sending packet\nDetails: " + e);
            return false;
        }

    }
}
