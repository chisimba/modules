/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package avoir.realtime.presentations.common.packet;
import avoir.realtime.User;
/**
 *
 * @author dwafula
 */
public class UserPacket implements PresentationsPacket {

    User user;
    boolean newUser = false;

    public UserPacket(User user, boolean newUser) {
        this.newUser=newUser;
        this.user=user;
        
    }

    public boolean isNewUser() {
        return newUser;
    }

    public User getUser(){
        return user;
    }

    @Override
    public String toString() {
        return user.toString();
    }
}

