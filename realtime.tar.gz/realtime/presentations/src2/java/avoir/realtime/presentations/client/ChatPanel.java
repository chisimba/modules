/**
 * 	$Id: ChatPanel.java,v 1.1 2007-12-14 15:37:22 davidwaf Exp $
 *
 *  Copyright (C) GNU/GPL AVOIR 2007
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *1d a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.realtime.presentations.client;

import java.awt.event.ActionListener;
import java.util.Stack;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.Dimension;
import java.awt.BorderLayout;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Color;
import java.awt.Font;
import javax.swing.BorderFactory;
import avoir.realtime.User;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.JPanel;
import javax.swing.JLabel;

import avoir.realtime.presentations.common.packet.ChatPacket;
import avoir.realtime.presentations.common.util.*;
import avoir.realtime.presentations.common.util.PresentationConstants;
import java.util.Hashtable;

import java.awt.font.FontRenderContext;
import java.awt.font.LineBreakMeasurer;
import java.awt.font.TextAttribute;
import java.awt.font.TextLayout;
import java.text.AttributedCharacterIterator;
import java.text.AttributedString;

/**
 * Window that diplays a chat session
 */
public class ChatPanel extends JPanel implements ActionListener {

    private JTextField chatIn;
    private JTextArea chatShow;
    private JButton chatSubmit;
    private JScrollPane chatScroll;
    private JPanel chatInputPanel;
    public Connector sl;
    private User usr;
    private int chatSize = 0;
    private MessagePanel messagePanel = new MessagePanel();
    private LineBreakMeasurer lineMeasurer;
    JLabel infoLabel = new JLabel();
    boolean firstTime = true;
    // index of the first character in the paragraph.

    private int paragraphStart;

    // index of the first character after the end of the paragraph.

    int yValue = 10;
    private int paragraphEnd;
    private static final Hashtable<TextAttribute, Object> map =
            new Hashtable<TextAttribute, Object>();
    static {
        map.put(TextAttribute.FAMILY, "System");
        map.put(TextAttribute.SIZE, new Float(12.0));
    }
    boolean presenter = false;

    /**
   * Constructor
   * @param sl SocketList
   * @param usr User
   */
    public ChatPanel(Connector sl, User usr, boolean presenter) {
        this.sl = sl;
        this.usr = usr;
        this.presenter = presenter;
        init();
    }

    public ChatPanel() {

        init();
    }

    public void setUser(User usr) {

        this.usr = usr;

    }

    public void setConnector(Connector sl) {
        this.sl = sl;

        init();
    }

    private void init() {

        chatIn = new JTextField();
        chatShow = new JTextArea();
        chatSubmit = new JButton("Send");
        chatScroll = new JScrollPane();
        chatInputPanel = new JPanel();

        chatSubmit.addActionListener(this);

        chatIn.setEditable(true);
        //chatIn.setColumns(20);
        chatIn.setText("Default Chat Text");
        chatIn.addActionListener(this);

        chatShow.setEditable(false);
        chatShow.setColumns(15);
        chatShow.setLineWrap(true);
        chatShow.setWrapStyleWord(true);

        chatScroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
        //messagePanel.setPreferredSize(new Dimension(getWidth(), 100));
        chatScroll.setViewportView(messagePanel);
        //chatInputPanel.add(chatIn);

        //chatInputPanel.add(chatSubmit);

        this.setLayout(new BorderLayout());// new java.awt.GridLayout(2, 0));
        infoLabel.setForeground(Color.ORANGE);
        infoLabel.setBorder(BorderFactory.createEtchedBorder());
        this.add(infoLabel, BorderLayout.NORTH);
        this.add(chatScroll, BorderLayout.CENTER);
        this.add(chatIn, BorderLayout.SOUTH);
    //setPreferredSize(new Dimension(300, 150));
    }

    /**
   * Event handler for the chat room
   * @param ae ActionEvent
   */
    public void actionPerformed(java.awt.event.ActionEvent ae) {
        //  messagePanel.repaint();
        if (sl != null) {
            firstTime = false;
            String text = chatIn.getText();
            if (sl.cv != null) {

                sl.sentPacket(new ChatPacket(usr, text, getTime(), presenter, PresentationConstants.USER_MESSAGE, sl.cv.contentBasePath));
            }
            if (sl.mf != null) {

                sl.sentPacket(new ChatPacket(usr, text, getTime(), presenter, PresentationConstants.USER_MESSAGE, sl.mf.contentBasePath));
            }
            chatIn.setText("");

        }
    //send chat to server
    }

    /**
   * gets the time message was received (send?)
   * @return String
   */
    public String getTime() {
        Date today;
        String result;
        SimpleDateFormat formatter;

        formatter = new SimpleDateFormat("H:m:s",
                new java.util.Locale("en_US"));
        today = new Date();
        result = formatter.format(today);
        return result;

    }

    /**
   * Updates the contents of the chat window
   */
    public void update() {

        if (sl != null) {
            movePanel(0, 1, sl.getChat().size());
            if (messagePanel != null) {
                messagePanel.repaint();
            }
        }
    }

    /**
   * scrolls the message panel to latest message
   * @param xmove int
   * @param ymove int
   * @param size int
   */
    protected void movePanel(int xmove, int ymove, int size) {
        java.awt.Point pt = new java.awt.Point(0, size * 19);
        chatScroll.getViewport().setViewPosition(pt);
        chatScroll.repaint();
        if (messagePanel != null) {
            messagePanel.repaint();
        }
    }

    /**
   * Use this class to display the messages
   * */
    class MessagePanel
            extends JPanel {

        Color color = Color.BLACK;
        Font font = new Font("System", 0, 12);

        public MessagePanel() {
            setBackground(Color.white);

        }
        /**
     * Do actual painting here
     * @param g Graphics
     */

        public void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (sl != null) {
                Stack chatStack = sl.getChat();
                Graphics2D g2 = (Graphics2D) g;
                yValue = 10;
                String s = null;
                if (firstTime) {

                }
                for (int i = 0; i < chatStack.size(); i++) {
                    ChatPacket p = (ChatPacket) chatStack.get(i);

                    String txt = "[" + p.getTime() + "] <" + p.getUser().getUserId() + "> " +
                            p.getContent();
                    if (p.isSystemMessage()) {

                        font = new Font("System", 1, 12);
                        color = new Color(0, 131, 0);
                        txt = p.getContent();
                        if (!txt.startsWith("*")) {

                            infoLabel.setText(txt);
                            if (p.getUser().isActive()) {
                               // sl.addUserToTree(p.getUser());
                            } else {
                               // sl.removeUserToTree(p.getUser());
                            }
                        }
                    //g2.setColor(color);
                        //g2.setFont(font);
                        //drawText(g2, txt);
                    } else {
                        //infoLabel.setText("");
                        if (p.isPresenter()) {
                            color = new Color(0, 131, 0);
                            font = new Font("System", 1, 12);
                        } else {
                            color = Color.BLACK;
                        }
                        g2.setColor(color);
                        g2.setFont(font);
                        drawText(g2, txt);
                    }
                }
                chatSize = chatStack.size();

                this.setPreferredSize(new Dimension(200, chatStack.size() * 22));
                this.revalidate();
            }
        }

        private void drawText(Graphics2D g2d, String text) {
            if (text == null) {
                return;
            }
            AttributedString mText = new AttributedString(text,
                    map);

            // Create a new LineBreakMeasurer from the paragraph.
            AttributedCharacterIterator paragraph = mText.getIterator();
            paragraphStart = paragraph.getBeginIndex();
            paragraphEnd = paragraph.getEndIndex();
            FontRenderContext frc = g2d.getFontRenderContext();
            lineMeasurer = new LineBreakMeasurer(paragraph, frc);

            // Set break width to width of Component.
            float breakWidth = (float) getSize().width;
            float drawPosY = 0;
            // Set position to the index of the first character in the paragraph.
            lineMeasurer.setPosition(paragraphStart);

            // Get lines until the entire paragraph has been displayed.
            while (lineMeasurer.getPosition() < paragraphEnd) {

                // Retrieve next layout. A cleverer program would also cache
                // these layouts until the component is re-sized.
                TextLayout layout = lineMeasurer.nextLayout(breakWidth);
                // Compute pen x position. If the paragraph is right-to-left we
                // will align the TextLayouts to the right edge of the panel.
                // Note: this won't occur for the English text in this sample.
                // Note: drawPosX is always where the LEFT of the text is placed.
                if (layout != null) {
                    float drawPosX = layout.isLeftToRight()
                            ? 0 : breakWidth - layout.getAdvance();

                    // Move y-coordinate by the ascent of the layout.
                    drawPosY += layout.getAscent();

                    // Draw the TextLayout at (drawPosX, drawPosY).
                    layout.draw(g2d, drawPosX, yValue);//drawPosY);

                    // Move y-coordinate in preparation for next layout.
                    drawPosY += layout.getDescent() + layout.getLeading();
                    yValue += 20;
                }
            }
        }
        }
}
