package avoir.realtime.presentations.client.presenter;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.event.TreeModelEvent;
import javax.swing.event.TreeModelListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.MutableTreeNode;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;
import javax.swing.tree.*;
import avoir.realtime.presentations.common.util.*;
import avoir.realtime.presentations.common.packet.UserPacket;
import java.util.*;
import avoir.realtime.*;

public class DynamicTree extends JPanel {

    public DefaultMutableTreeNode rootNode;
    public DefaultTreeModel treeModel;
    protected JTree tree;
    private Toolkit toolkit = Toolkit.getDefaultToolkit();
    ImageIcon folderIcon = Utils.createImageIcon("/icons/folder.png", "");
    ImageIcon greenFolderIcon = Utils.createImageIcon("/icons/folder_green.png", "");

    public DynamicTree() {
        super(new GridLayout(1, 0));
        setPreferredSize(new Dimension(240, 300));
        init();
    }

    private void init() {
       
        rootNode = new DefaultMutableTreeNode(new User(UserLevel.GUEST,"Audience","Audience"));
        treeModel = new DefaultTreeModel(rootNode);
        treeModel.addTreeModelListener(new MyTreeModelListener());

        tree = new JTree(treeModel);
        tree.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
        tree.setShowsRootHandles(true);

        tree.setCellRenderer(new MyRenderer(folderIcon, greenFolderIcon));


        tree.addMouseListener(new MouseAdapter() {

                    public void mouseClicked(MouseEvent e) {
                        if (e.getClickCount() == 2) {
                            DefaultMutableTreeNode node = null;
                            TreePath parentPath = tree.getSelectionPath();
                            node = (DefaultMutableTreeNode) (parentPath.getLastPathComponent());

                            if (node == null) {
                            // mf.cmsMenuItem.setEnabled(false);
                            } else {
                                node = (DefaultMutableTreeNode) (parentPath.getLastPathComponent());

                                String selectedNode = (String) node.getUserObject();

                            }
                        }
                    }
                });

        JScrollPane scrollPane = new JScrollPane(tree);
        add(scrollPane);
    }

    /** Remove all nodes except the root node. */
    public void clear() {
        rootNode.removeAllChildren();
        treeModel.reload();
    }

    public void removeUser(User user) {
        DefaultMutableTreeNode node = searchNode(user);
        removeNode(node);
    }

    public void addUser(User user) {
        DefaultMutableTreeNode node = searchNode(user);
        //  System.out.println("Search: "+node);
        if (node == null) {
            addObject(user);
        }
    }

    /**
     * This method takes the node string and
     * traverses the tree till it finds the node
     * matching the string. If the match is found 
     * the node is returned else null is returned
     * 
     * @param nodeStr node string to search for
     * @return tree node 
     */
    public DefaultMutableTreeNode searchNode(User nodeStr) {
        DefaultMutableTreeNode node = null;

        //Get the enumeration
        Enumeration xenum = rootNode.breadthFirstEnumeration();

        //iterate through the enumeration
        while (xenum.hasMoreElements()) {
            //get the node
            node = (DefaultMutableTreeNode) xenum.nextElement();
            if (node != null) {
                //match the string with the user-object of the node

                User cN = (User) node.getUserObject();
                if (nodeStr.toString().equals(cN.toString())) {
                    //tree node with string found
                    return node;
                }
            }
        }

        //tree node with string node found return null
        return null;
    }

    /**
     * This method removes the passed tree node from the tree
     * and selects appropiate node
     * 
     * @param selNode node to be removed
     */
    public void removeNode(DefaultMutableTreeNode selNode) {
        if (selNode != null) {
            //get the parent of the selected node
            MutableTreeNode parent = (MutableTreeNode) (selNode.getParent());

            // if the parent is not null
            if (parent != null) {
                //get the sibling node to be selected after removing the
                //selected node
                MutableTreeNode toBeSelNode = getSibling(selNode);

                //if there are no siblings select the parent node after removing the node
                if (toBeSelNode == null) {
                    toBeSelNode = parent;
                }

                //make the node visible by scroll to it
               /* TreeNode[] nodes = treeModel.getPathToRoot(toBeSelNode);
                TreePath path = new TreePath(nodes); 
                tree.scrollPathToVisible(path); 
                tree.setSelectionPath(path);
             */
                //remove the node from the parent
                treeModel.removeNodeFromParent(selNode);
            }
        }
    }

    /**
     * This method returns the previous sibling node 
     * if there is no previous sibling it returns the next sibling
     * if there are no siblings it returns null
     * 
     * @param selNode selected node
     * @return previous or next sibling, or parent if no sibling
     */
    private MutableTreeNode getSibling(DefaultMutableTreeNode selNode) {
        //get previous sibling
        MutableTreeNode sibling = (MutableTreeNode) selNode.getPreviousSibling();

        if (sibling == null) {
            //if previous sibling is null, get the next sibling
            sibling = (MutableTreeNode) selNode.getNextSibling();
        }

        return sibling;
    }
    /** Remove the currently selected node. */

    public void removeCurrentNode() {
        TreePath currentSelection = tree.getSelectionPath();

        if (currentSelection != null) {
            DefaultMutableTreeNode currentNode = (DefaultMutableTreeNode) (currentSelection.getLastPathComponent());
            MutableTreeNode parent = (MutableTreeNode) (currentNode.getParent());

            if (parent != null) {
                treeModel.removeNodeFromParent(currentNode);

                return;
            }
        }

        // Either there was no selection, or the root was selected.
        toolkit.beep();
    }

    /** Add child to the currently selected node. */
    private DefaultMutableTreeNode addObject(Object child) {
        DefaultMutableTreeNode parentNode = null;
        TreePath parentPath = tree.getSelectionPath();

        if (parentPath == null) {
            parentNode = rootNode;
        } else {
            parentNode = (DefaultMutableTreeNode) (parentPath.getLastPathComponent());
        }

        return addObject(parentNode, child, true);
    }

    private DefaultMutableTreeNode addObject(DefaultMutableTreeNode parent,
            Object child) {
        return addObject(parent, child, false);
    }

    private DefaultMutableTreeNode addObject(DefaultMutableTreeNode parent,
            Object child, boolean shouldBeVisible) {
        DefaultMutableTreeNode childNode = new DefaultMutableTreeNode(child);

        if (parent == null) {
            parent = rootNode;
        }

        treeModel.insertNodeInto(childNode, parent, parent.getChildCount());

        // Make sure the user can see the lovely new node.
        if (shouldBeVisible) {
            tree.scrollPathToVisible(new TreePath(childNode.getPath()));
        }

        return childNode;
    }

    class MyTreeModelListener implements TreeModelListener {

        public void treeNodesChanged(TreeModelEvent e) {
            DefaultMutableTreeNode node;
            node = (DefaultMutableTreeNode) (e.getTreePath().getLastPathComponent());

            /*
                         * If the event lists children, then the changed node is the child
                         * of the node we've already gotten. Otherwise, the changed node and
                         * the specified node are the same.
                         */
            try {
                int index = e.getChildIndices()[0];
                node = (DefaultMutableTreeNode) (node.getChildAt(index));
            } catch (NullPointerException exc) {
            }

            System.out.println("The user has finished editing the node.");
            System.out.println("New value: " + node.getUserObject());
        }

        public void treeNodesInserted(TreeModelEvent e) {
        }

        public void treeNodesRemoved(TreeModelEvent e) {
        }

        public void treeStructureChanged(TreeModelEvent e) {
        }
    }

    class MyRenderer extends DefaultTreeCellRenderer {

        Icon folderIcon;
        Icon greenFolderIcon;

        public MyRenderer(Icon icon1, Icon icon2) {
            folderIcon = icon1;
            greenFolderIcon = icon2;
        }

        public Component getTreeCellRendererComponent(JTree tree,
                Object value,
                boolean sel,
                boolean expanded,
                boolean leaf,
                int row,
                boolean hasFocus) {

            super.getTreeCellRendererComponent(tree, value, sel,
                    expanded, leaf, row,
                    hasFocus);
            if (leaf) {
                setIcon(folderIcon);

            } else {
                setIcon(greenFolderIcon);
            }

            return this;
        }
    }
}
