/*
 * CommandPacket.java
 *
 * Created on October 29, 2007, 11:47 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package avoir.realtime.presentations.common.packet;

/**
 *
 * @author dwafula
 */
public class CommandPacket implements PresentationsPacket {
    
    String cmd;
    /** Creates a new instance of CommandPacket */
    public CommandPacket(String cmd) {
        this.cmd=cmd;
    }
    public String getCommand(){
        return cmd;
    }
    
}
