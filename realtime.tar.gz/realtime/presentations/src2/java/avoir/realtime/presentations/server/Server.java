/**
 * 	$Id: Server.java,v 1.4 2007-12-14 15:38:27 davidwaf Exp $
 * 
 *  Copyright (C) GNU/GPL AVOIR 2007
 * 
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.realtime.presentations.server;

import java.util.logging.Level;
import java.util.logging.Logger;
import java.io.*;
import java.net.*;
import java.util.Stack;
import java.nio.channels.*;
import java.nio.*;
import java.net.*;
import java.util.Vector;

import avoir.realtime.presentations.common.util.PresentationConstants;
import avoir.realtime.presentations.common.packet.*;
import javax.swing.ImageIcon;
/**
 * The server for the Realtime Presentation applications. Serves as the main
 * class for the project
 */

public class Server {

    private static Logger logger = Logger.getLogger(Server.class.getName());
    private static ClientList clients = new ClientList();
    private static Stack chatStack = new Stack();
    private static Stack userStack = new Stack();
    NewSlidePacket currentSlide = null;
    String chatLogFilename = "ChatLog.txt";

    /**
	 * Main method for running the whiteboard server.
	 * 
	 * @param argv
	 *            String array of arguments.
	 */
    public Server(int port) {
        try {
            ServerSocket serverSocket = null;
            boolean listening = true;

            try {
                serverSocket = new ServerSocket(port);
                System.out.println("Server running ...");
            } catch (IOException e) {
                System.err.println("Could not listen on port: " + port);
                System.exit(-1);
            }

            while (listening) {
                new ServerThread(serverSocket.accept()).start();
            }

            serverSocket.close();
        } catch (Exception ex) {
            System.out.println("Error: ");
            ex.printStackTrace();
        }

    }

    public static void main(String[] argv) {
        double ver = Double.parseDouble(System.getProperty("java.version").substring(0, 3));

        if (ver < 1.5) {
            System.out.println("Current version is " + ver + ". You need java ver 1.5 or later to run the server");
            System.exit(0);
        }
        if (argv.length > 1) {
            throw new IllegalArgumentException("Syntax: Server [<port>]");
        }
        logger.info("Presentations server starting..." + "\n");
        int port = argv.length == 0 ? PresentationConstants.DEFAULT_SERVER_PORT
                : Integer.parseInt(argv[0]);

        new Server(port);
    /*try {
            ServerListener listener = new ServerListener(port, slide);
            new Thread(listener).start();
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error spawning listener thread", e);
        }*/
    }

    class ServerThread extends Thread {

        private Socket socket = null;

        public ServerThread(Socket socket) {
            super("ServerThread");
            this.socket = socket;
        }

        public void run() {

            try {
                ObjectOutputStream out = new ObjectOutputStream(new BufferedOutputStream(socket.getOutputStream()));
                out.flush();
                ObjectInputStream in = new ObjectInputStream(new BufferedInputStream(socket.getInputStream()));
                processMsgs(in, out);
            } catch (Exception e) {
                logger.log(Level.SEVERE, "Error in Server ", e);
            } finally {
                logger.fine("Server  disconnected from " + socket.getInetAddress() + "\n");
                try {
                    socket.close();
                } catch (IOException e) {
                    logger.log(Level.WARNING, "Error closing socket", e);
                }
            }
        }

        void processMsgs(ObjectInputStream objectIn, final ObjectOutputStream objectOut) {
            try {

                while (true) {
                    Object obj = null;
                    PresentationsPacket packet = null;

                    obj = objectIn.readObject();

                    if (obj instanceof PresentationsPacket) {
                        packet = (PresentationsPacket) obj;
                    }
                    if (packet != null) {

                        if (packet instanceof PresentationsImgPacket) {
                            PresentationsImgPacket pr = (PresentationsImgPacket) packet;
                            broadcastMsg(pr);
                        } else if (packet instanceof UserPacket) {
                            UserPacket userPacket = (UserPacket) packet;
                            try {

                                synchronized (clients) {
                                    if (userPacket.isNewUser()) {
                                        clients.addElement(objectOut, userPacket);
                                       broadcastMsg(new UserListPacket(clients.users));
                                    } else {
                                        clients.removeElement(objectOut);
                                    }
                                }
                                //users.addElement(userPacket);

                                //  objectOut.writeObject(new UserListPacket(users));
                            //objectOut.flush();    
                             //   System.out.println("Users: " + users.size());

                                broadcastMsg(userPacket);
                            } catch (Exception e) {
                                logger.log(Level.SEVERE, "Error in dispatch", e);
                                clients.removeElement(objectOut);
                            }
                        } else if (packet instanceof ChatPacket) {
                            ChatPacket p = (ChatPacket) packet;
                            //System.out.println(p.getUser() + " " + p.getContent() + " status: " + p.getUser().isActive());
                            chatStack.add(packet);
                            broadcastMsg(packet);

                            logChat(chatLogFilename, p.toString() + "\n");

                        } else if (packet instanceof QuitPacket) {
                            broadcastMsg(packet);
                            chatStack.clear();
                        } else if (packet instanceof ErrorPacket) {
                            broadcastMsg(packet);
                        } else if (packet instanceof CreateImagesPacket) {
                            final CreateImagesPacket p = (CreateImagesPacket) packet;
                            // createImages(p.getPath(), objectOut);
                            chatLogFilename = p.getPath() + "/chat/ChatLog.txt";
                            int[] imgNos = getImageFileNames(p.getPath(), objectOut);
                            if (imgNos != null) {
                                objectOut.writeObject(new ImgNosPacket(imgNos));
                                objectOut.flush();
                            }
                            //also write back any users you might find:
                            for (int i = 0; i < clients.size(); i++) {
                                UserPacket user = clients.nameAt(i);
                                objectOut.writeObject(user);
                                objectOut.flush();
                            }
                            //start logging:

                            File f = new File(p.getPath() + System.getProperty("file.separator") + "chat");
                            f.mkdir();

                        } else if (packet instanceof RequestSlidePacket) {
                            RequestSlidePacket p = (RequestSlidePacket) packet;
                            currentSlide = new NewSlidePacket(new javax.swing.ImageIcon(java.awt.Toolkit.getDefaultToolkit().
                                    createImage(p.getImgName())), p.getSlideNo(), p.getTotalSlides(), p.getId(), p.getPresenter());
                            broadcastMsg(currentSlide);
                        } else if (packet instanceof RequestFilePacket) {
                            RequestFilePacket rfp = (RequestFilePacket) packet;
                            if (new File(rfp.getFilePath()).exists()) {
                                FileChannel fc = new FileInputStream(rfp.getFilePath()).getChannel();

                                ByteBuffer buff = ByteBuffer.allocate((int) fc.size());
                                fc.read(buff);
                                if (buff.hasArray()) {
                                    byte[] byteArray = buff.array();
                                    fc.close();

                                    objectOut.writeObject(new FilePacket(byteArray, rfp.getFileName()));
                                    objectOut.flush();

                                } else {
                                    System.out.println("Has Array failed");
                                }
                            } else {
                            //
                            }


                        } else if (packet instanceof RequestContentPacket) {
                            RequestContentPacket p = (RequestContentPacket) packet;

                            objectOut.writeObject(new ChatStackPacket(chatStack));
                            objectOut.flush();
                            //Not best for now, but we braodcast a request..there will be a problem if there are two concurent
                        //presentations
                            String id = p.getId();
                            //broadcastMsg(new BroadcastRequestPacket(id));
                            //System.out.println("Current Slide: "+currentSlide);
                            if (currentSlide != null) {
                                //System.out.println("current id: "+currentSlide.getId()+" request id = "+id);
                                //if (currentSlide.getId().equals(id)) {
                                objectOut.writeObject(currentSlide);
                                objectOut.flush();

                            //}
                            }



                        } else {
                            logger.warning("Server received unrecognised packet\n");
                        }
                    }
                }
            } catch (Exception ex) {

                //objectOut.writeObject(new ChatPacket(usr, chatLogFilename, chatLogFilename, presenter, systemMessage, chatLogFilename));
                //objectOut.flush();
                clients.removeElement(objectOut);
                logger.log(Level.WARNING, "Error processing messages ", ex);

            }
        }

        /**
         * Log the chat
         * @param fileName
         * @param txt
         */
        public void logChat(String fileName, String txt) {
            try {
                BufferedWriter out = new BufferedWriter(new FileWriter(fileName, true));
                out.write(txt);
                out.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        /**
         * gets the jpg  file names generated from the presentation
         * @param contentPath
         * @param objectOut
         * @return
         */
        public int[] getImageFileNames(String contentPath, ObjectOutputStream objectOut) {
            File dir = new File(contentPath);
            String[] list = dir.list();


            if (list != null) {

                java.util.Arrays.sort(list);
                Vector newList = new Vector();
                int totalSlides = 0;
                int c = 0;
                for (int i = 0; i < list.length; i++) {
                    if (list[i].endsWith(".jpg")) {

                        newList.addElement(list[i]);
                        totalSlides++;
                        c++;
                    }
                }
                int[] imgNos = new int[newList.size()];
                for (int i = 0; i < newList.size(); i++) {
                    String fn = (String) newList.elementAt(i);

                    if (fn != null) {
                        for (int j = 0; j < fn.length(); j++) {
                            if (Character.isDigit(fn.charAt(j))) {
                                int imgNo = Integer.parseInt(fn.substring(fn.indexOf(fn.charAt(j)), fn.indexOf(".jpg")));
                                imgNos[i] = imgNo;
                                break;
                            }
                        }
                    }
                }
                java.util.Arrays.sort(imgNos);
                return imgNos;

            }
            return null;
        }

        /**
         * broadcasts the packet to all clients
         * @param packet
         */
        private void broadcastMsg(PresentationsPacket packet) {
            for (int i = 0; i < clients.size(); i++) {
                ObjectOutputStream out = (ObjectOutputStream) clients.elementAt(i);
                try {
                    out.writeObject(packet);
                    out.flush();
                } catch (IOException e) {
                    logger.log(Level.SEVERE, "Error broadcasting in Server ", e);
                }

            }
        }
    }
}