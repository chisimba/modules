/**
 *  $Id: ServerThread.java,v 1.5 2007-12-12 10:53:03 davidwaf Exp $
 *
 *  Copyright (C) GNU/GPL AVOIR 2007
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.realtime.presentations.server;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.*;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Enumeration;
import java.util.Stack;
import java.util.Vector;
import java.util.jar.JarFile;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.zip.ZipEntry;

import javax.swing.ImageIcon;
import avoir.realtime.presentations.common.packet.*;
import avoir.realtime.presentations.common.util.*;
import java.nio.*;
import java.nio.channels.*;
import avoir.realtime.*;

/*import com.artofsolving.jodconverter.openoffice.connection.*;
import com.artofsolving.jodconverter.DocumentConverter;
import com.artofsolving.jodconverter.openoffice.converter.OpenOfficeDocumentConverter;
import java.net.ConnectException;
*/
/**
 * Handles communications for the server, to and from the clients Processes
 * packets from client actions and broadcasts these updates
 */
@SuppressWarnings("serial")
public class ServerThread extends Thread {

    private static Logger logger = Logger.getLogger(ServerThread.class.getName());
    private static String tName;
    private Socket socket;
    private static Vector slide;
    private static Vector slideList = new Vector();
    private static ClientList clients = new ClientList();
    private static Vector startTime = new Vector();
    PresentationsImgPacket imgPacket = null;
    private static Vector ids = new Vector();
    private static Stack chatStack = new Stack();
    String currentSlide = null;
    private static final int BSIZE = 1024;
    String filename = "ChatLog.txt";

    /**
     * Constructor accepts connections
     *
     * @param socket
     *            The socket
     */
    public ServerThread(Socket socket, Vector slide) {
        tName = getName();
        logger.finest("Server " + tName + " accepted connection from " + socket.getInetAddress() + "\n");
        this.socket = socket;
        this.slide = slide;
    //filename=getTime()+"_"+tName+".txt";

    }

    /**
     * Run method initializes Object input and output Streams Calls dispatch
     * method which calls process messsages which processes incoming packets The
     * information carried by these packets is rebroadcasted to all of the
     * clients
     */
    public void run() {
        try {

            ObjectOutputStream out = new ObjectOutputStream(new BufferedOutputStream(socket.getOutputStream()));
            out.flush();

            ObjectInputStream in = new ObjectInputStream(new BufferedInputStream(socket.getInputStream()));
            // clients.addElement(out, null);
            dispatch(in, out);

        } catch (Exception e) {
            slideList.clear();
            logger.log(Level.SEVERE, "Error in Server " + tName, e);
        } finally {
            logger.fine("Server " + tName + " disconnected from " + socket.getInetAddress() + "\n");
            try {
                socket.close();
            } catch (IOException e) {
                logger.log(Level.WARNING, "Error closing socket", e);
            }
        }
    }

    /**
   * gets the time message was received (send?)
   * @return String
   */
    public String getTime() {
        java.util.Date today;
        String result;
        java.text.SimpleDateFormat formatter;

        formatter = new java.text.SimpleDateFormat("dd-MM-yyyy-H:m:s",
                new java.util.Locale("en_US"));
        today = new java.util.Date();
        result = formatter.format(today);
        return result;

    }

    @SuppressWarnings("unchecked")
    void dispatch( ObjectInputStream oIn,  ObjectOutputStream oOut)
            throws IOException, ClassNotFoundException {
        try {
            synchronized (clients) {
            // oOut.writeObject(new InitPacket(list.clone(),
                // (Stack<String>)windowStack.clone(),
                // (Stack<String>)windowTitleStack.clone(),curWindow));
              // PresentationsPacket p=(PresentationsPacket)oIn.readObject();

            }
            processMsgs(oIn, oOut);
        } catch ( Exception e) {
            logger.log(Level.SEVERE, "Error in dispatch", e);
        } finally {
        //       clients.removeElement(oOut);
        }
    }

    void processMsgs( ObjectInputStream objectIn, final ObjectOutputStream objectOut)
            throws IOException, ClassNotFoundException {
        try {

            while (true) {
                Object obj = null;
                PresentationsPacket packet = null;

                obj = objectIn.readObject();

                if (obj instanceof PresentationsPacket) {
                    packet = (PresentationsPacket) obj;
                }
                if (packet != null) {

                    if (packet instanceof PresentationsImgPacket) {
                        PresentationsImgPacket pr = (PresentationsImgPacket) packet;
                        broadcastMsg(pr);
                    } else if (packet instanceof UserPacket) {
                        UserPacket userPacket = (UserPacket) packet;
                        try {

                            synchronized (clients) {
                                if (userPacket.isNewUser()) {
                                    clients.addElement(objectOut, userPacket);
                                } else {
                                    clients.removeElement(objectOut);
                                }
                            }
                        } catch (Exception e) {
                            logger.log(Level.SEVERE, "Error in dispatch", e);
                            clients.removeElement(objectOut);
                        }
                    } else if (packet instanceof ChatPacket) {
                        ChatPacket p = (ChatPacket) packet;
                        chatStack.add(packet);
                        broadcastMsg(packet);
                        
                        logChat(p.getLogFilePath() + "/chat/ChatLog.txt", p.toString() + "\n");
                        
                    } else if (packet instanceof QuitPacket) {
                        broadcastMsg(packet);
                        //clear the chat
                        //todo: before clearing, make sure chat log is saved 
                        chatStack.clear();
                        currentSlide = null;
                    } else if (packet instanceof ErrorPacket) {
                        broadcastMsg(packet);
                    } else if (packet instanceof CreateImagesPacket) {
                        final CreateImagesPacket p = (CreateImagesPacket) packet;
                        // createImages(p.getPath(), objectOut);
                        int[] imgNos = getImageFileNames(p.getPath(), objectOut);
                        if (imgNos != null) {
                            objectOut.writeObject(new ImgNosPacket(imgNos));
                            objectOut.flush();
                        }
                        //also write back any users you might find:
                        for (int i = 0; i < clients.size(); i++) {
                            UserPacket user = clients.nameAt(i);
                            objectOut.writeObject(user);
                            objectOut.flush();
                        }
                        //start logging:

                        File f = new File(p.getPath() + System.getProperty("file.separator") + "chat");
                        f.mkdir();
                        filename = p.getPath() + System.getProperty("file.separator") +
                                "chat" + System.getProperty("file.separator") + "ChatLog.txt";


                    } else if (packet instanceof RequestSlidePacket) {
                        RequestSlidePacket p = (RequestSlidePacket) packet;
                        NewSlidePacket nsp = new NewSlidePacket(new javax.swing.ImageIcon(java.awt.Toolkit.getDefaultToolkit().
                                createImage(p.getImgName())), p.getSlideNo(), p.getTotalSlides(), p.getId(), p.getPresenter());
                        currentSlide = p.getImgName();
                        broadcastMsg(nsp);
                    } else if (packet instanceof RequestFilePacket) {
                        RequestFilePacket rfp = (RequestFilePacket) packet;
                        FileChannel fc = new FileInputStream(rfp.getFilePath()).getChannel();

                        ByteBuffer buff = ByteBuffer.allocate((int) fc.size());
                        fc.read(buff);
                        if (buff.hasArray()) {
                            byte[] byteArray = buff.array();
                            fc.close();

                            objectOut.writeObject(new FilePacket(byteArray, rfp.getFileName()));
                            objectOut.flush();

                        } else {
                            System.out.println("Has Array failed");
                        }

                    } else if (packet instanceof RecordPacket) {
                        RecordPacket p = (RecordPacket) packet;
                        boolean result = saveRecording(p.getFilePath(), p.getRecords());
                    //then send back the outcome
                        //  objectOut.writeObject(new CommandPacket(result?"SUCCESS":"FAIL"));
                        //  objectOut.flush();

                    } else if (packet instanceof RequestContentPacket) {
                        RequestContentPacket p = (RequestContentPacket) packet;
                        System.out.println("Client Reg");
                        //String thumbNailContentPath = p.getId();
                        //String basePath = thumbNailContentPath.substring(0, thumbNailContentPath.indexOf("webpresent_thumbnails"));

                        //thumbNailContentPath.substring(thumbNailContentPath.lastIndexOf("webpresent_thumbnails/") + 22);
                        //first check if the presentation had been held before
                        //String recordPath = basePath + "/webpresent/" + id + "/" + id;
                        //String imagesPath = basePath + "/webpresent/" + id;

                        //send out any chat records that might be existing

                        objectOut.writeObject(new ChatStackPacket(chatStack));
                        objectOut.flush();
                        //Not best for now, but we braodcast a request..there will be a problem if there are two concurent
                        //presentations
                        String id = p.getId();
                        broadcastMsg(new BroadcastRequestPacket(id));




                    } else {
                        logger.warning("Server " + tName + " received unrecognised packet\n");
                    }
                }
            }
        } catch (Exception ex) {
            objectOut.writeObject(new ErrorPacket(ex.getMessage()));
            objectOut.flush();
            logger.log(Level.WARNING, "Error processing messages ", ex);

        }
    }

    public int[] getImageFileNames(String contentPath, ObjectOutputStream objectOut) {
        File dir = new File(contentPath);
        ids.clear();
        ids.addElement(contentPath.substring(contentPath.lastIndexOf("/") + 1));
        slideList.clear();
        String[] list = dir.list();


        if (list != null) {

            java.util.Arrays.sort(list);
            Vector newList = new Vector();
            int totalSlides = 0;
            int c = 0;
            for (int i = 0; i < list.length; i++) {
                if (list[i].endsWith(".jpg")) {

                    newList.addElement(list[i]);
                    totalSlides++;
                    c++;
                }
            }
            int[] imgNos = new int[newList.size()];
            for (int i = 0; i < newList.size(); i++) {
                String fn = (String) newList.elementAt(i);

                if (fn != null) {
                    for (int j = 0; j < fn.length(); j++) {
                        if (Character.isDigit(fn.charAt(j))) {
                            int imgNo = Integer.parseInt(fn.substring(fn.indexOf(fn.charAt(j)), fn.indexOf(".jpg")));
                            imgNos[i] = imgNo;
                            break;
                        }
                    }
                }
            }
            java.util.Arrays.sort(imgNos);
            return imgNos;

        }
        return null;
    }

    public void logChat(String fileName, String txt) {
        try {
            BufferedWriter out = new BufferedWriter(new FileWriter(fileName, true));
            out.write(txt);
            out.close();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
    /**
     * Generate jpg images from the presentation using jodcoverter API.
     * @param filename
     */

    private void generateImages(String filename) {
    /*  File inputFile = new File(filename);
        int dot = filename.lastIndexOf(".");
        String fn = filename.substring(0, dot);
        File outputFile = new File(fn + ".jpg");
        // connect to an OpenOffice.org instance running on port 8100  
        OpenOfficeConnection connection = new SocketOpenOfficeConnection(8100);
        try {
            connection.connect();
        } catch (java.net.ConnectException ex) {
            Utils.err("Cannot connect to open office");
            return;
        }
        // convert  
        DocumentConverter converter = new OpenOfficeDocumentConverter(connection);
        converter.convert(inputFile, outputFile);

        // close the connection  
        connection.disconnect();
       */
    }

    static void broadcastMsg(PresentationsPacket packet) {
        for (int i = 0; i < clients.size(); i++) {
            ObjectOutputStream out = (ObjectOutputStream) clients.elementAt(i);
            try {
                out.writeObject(packet);
                out.flush();
            } catch (IOException e) {
                logger.log(Level.SEVERE, "Error broadcasting in Server " + tName, e);
            }

        }
    }

    public Vector readRecording(String filename) {
        Vector rec = new Vector();
        try {
            ObjectInputStream in = new ObjectInputStream(new FileInputStream(filename));
            rec =
                    (Vector) in.readObject();
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return rec;
    }

    public boolean saveRecording(String filePath, Object record) {
        try {
            String filename = filePath.substring(filePath.lastIndexOf("webpresent/") + 11);
            String fl = filePath + "/" + filename;
            //  Create a stream for writing.
            FileOutputStream fos = new FileOutputStream(fl);
            //  Next, create an object that can write to that file.
            ObjectOutputStream outStream =
                    new ObjectOutputStream(fos);

            //  Save each object.
            outStream.writeObject(record);

            //  Finally, we call the flush() method for our object, which
            //forces the data to
            //  get written to the stream:
            outStream.flush();
            return true;
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }
}
