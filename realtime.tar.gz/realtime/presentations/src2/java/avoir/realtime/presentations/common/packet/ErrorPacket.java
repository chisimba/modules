package avoir.realtime.presentations.common.packet;

public class ErrorPacket implements PresentationsPacket {
	String error;

	public ErrorPacket(String error) {
		this.error = error;
	}

	public String getErrorMessage() {
		return error;
	}
}
