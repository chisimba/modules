/*
 * ToolBox.java
 *
 * Created on November 7, 2007, 4:20 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */
package avoir.realtime.presentations.client.presenter;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import avoir.realtime.presentations.common.util.*;
/**
 *
 * @author dwafula
 */

public class ToolBox extends JToolBar {

    /** Creates a new instance of ToolBox */
    ImageIcon penIcon = Utils.createImageIcon("/icons/pentool.png", "");
    ImageIcon undoIcon = Utils.createImageIcon("/icons/undo.png", "");
    PresenterFrame pf;
    ButtonGroup bg = new ButtonGroup();

    public ToolBox(PresenterFrame pf) {
        setOrientation(JToolBar.VERTICAL);
       add(createJButton(penIcon, "Free Hand", "pen", true));
        add(createJButton(undoIcon, "Un Do", "undo", true));
    }

    private JButton createJButton(Icon icon, String tooltip, String action,
            boolean addBg) {
        JButton button = new JButton(icon);
        if (addBg) {
            bg.add(button);
        }
        button.setToolTipText(tooltip);
        button.setActionCommand(action);
        button.setBorderPainted(false);
        button.addActionListener(pf);

        return button;
    }
}
