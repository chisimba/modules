/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package avoir.realtime.presentations.common.packet;

import java.util.Vector;
/**
 *
 * @author dwafula
 */

public class UserListPacket implements PresentationsPacket{

    Vector<UserPacket> users;

    public UserListPacket(Vector<UserPacket> users) {
        this.users = users;
    }

    public Vector<UserPacket> getUserList() {
        return users;
    }
}
