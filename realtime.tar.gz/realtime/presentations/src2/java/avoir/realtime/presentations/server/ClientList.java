/**
 * 	$Id: ClientList.java,v 1.3 2007-12-12 10:53:03 davidwaf Exp $
 *
 *  Copyright (C) GNU/GPL AVOIR 2007
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.realtime.presentations.server;

import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Vector;
import avoir.realtime.presentations.common.packet.*;


/**
 * List of clients using the realtime tools in this session
 */
@SuppressWarnings("serial")
public class ClientList implements Serializable {
    /**
     * Vector to store the ObjectOutputStream used by each client
     */
    protected Vector<ObjectOutputStream> streams = new Vector<ObjectOutputStream>();
    
    /**
     * Vector to store the names of each of the clients
     */
    protected Vector<UserPacket> users = new Vector<UserPacket>();
    
    /**
     * Add a new client and the ObjectOutputStream
     *
     * @param user
     *            User
     * @param stream
     *            the ObjectOutputStream
     */
    public synchronized void addElement(ObjectOutputStream stream, UserPacket user) {
        streams.addElement(stream);
        users.addElement(user);
        
    }
    
    /**
     * Remove the client and stream
     *
     * @param stream
     *            ObjectOutputStream
     */
    public synchronized void removeElement(ObjectOutputStream stream) {
        int id = streams.indexOf(stream);
        if (id != -1) {
            users.removeElementAt(id);
        }
        streams.removeElement(stream);
    }
    
    /**
     * Returns the size of the stream Vector
     *
     * @return int
     */
    public synchronized int size() {
        return streams.size();
    }
    
    /**
     * Returns the stream at the specified index
     *
     * @param i
     *            index
     * @return stream
     */
    public synchronized ObjectOutputStream elementAt(int i) {
        return streams.elementAt(i);
    }
    
    /**
     * Returns the name at the specified index
     *
     * @param i
     *            index
     * @return name
     */
    public synchronized UserPacket nameAt(int i) {
        return users.elementAt(i);
    }
    
    /**
     * returns the name associated with the stream
     *
     * @param stream
     *            ObjectOutputStream
     * @return name of client
     */
    public synchronized String getName(ObjectOutputStream stream) {
        int id = streams.indexOf(stream);
        return (id >= 0) ? users.elementAt(id).getUser().toString() : null;
    }
    

}