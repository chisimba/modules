/*
 * RecordPacket.java
 *
 * Created on October 31, 2007, 4:23 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package avoir.realtime.presentations.common.packet;
import java.util.Vector;
/**
 *
 * @author dwafula
 */
public class RecordPacket implements PresentationsPacket{
    Vector records;
    String filePath;
    /** Creates a new instance of RecordPacket */
    public RecordPacket(Vector records,String filePath) {
        this.records=records;
        this.filePath=filePath;
    }
    
    public String getFilePath(){
        return filePath;
    }
    public Vector getRecords(){
        return records;
    }
}
