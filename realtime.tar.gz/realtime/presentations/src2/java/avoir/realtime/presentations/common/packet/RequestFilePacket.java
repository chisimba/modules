/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package avoir.realtime.presentations.common.packet;

/**
 *
 * @author dwafula
 */
public class RequestFilePacket implements PresentationsPacket {

    String filename;
    String path;

    public RequestFilePacket(String path, String filename) {
        this.filename = filename;
        this.path = path;
    }

    public String getFileName() {
        return filename;
    }

    public String getFilePath() {
        return path;
    }
}
