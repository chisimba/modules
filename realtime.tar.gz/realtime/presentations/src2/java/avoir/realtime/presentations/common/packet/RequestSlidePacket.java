/*
 * RequestSlidePacket.java
 *
 * Created on October 22, 2007, 2:59 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */
package avoir.realtime.presentations.common.packet;

/**
 *
 * @author dwafula
 */
public class RequestSlidePacket implements PresentationsPacket {

    public String imgName;
    public int slideNo;
    public int totalSlides;
    String id;
    String presenter;
    /** Creates a new instance of RequestSlidePacket */

    public RequestSlidePacket(String imgName,int slideNo,int totalSlides,String id,String presenter) {
        this.imgName = imgName;
        this.slideNo=slideNo;
        this.totalSlides=totalSlides;
        this.id=id;
        this.presenter=presenter;
    }
    
    public String getPresenter(){
        return presenter;
    }
    public String getId(){
        return id;
    }

    public int getSlideNo(){
        return slideNo;
    }
    public int getTotalSlides(){
        return totalSlides;
    }
    public String getImgName() {
        return imgName;
    }
}
