/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package avoir.realtime.presentations.client.viewer;

import avoir.realtime.presentations.common.util.Utils;
import avoir.realtime.presentations.common.packet.*;
import avoir.realtime.presentations.client.presenter.PresenterFrame;
/**
 *
 * @author dwafula
 */

public class JMFDisplay {

    public static void showMediaFrame(ClientViewer cv) {

        avoir.realtime.video.transmitter.engine.CaptureUtil util = new avoir.realtime.video.transmitter.engine.CaptureUtil();
        javax.media.Player player = util.transmitLive();

        avoir.realtime.video.transmitter.gui.JMFrame fr = new avoir.realtime.video.transmitter.gui.JMFrame(player, "");
        fr.setVisible(true);
        cv.addFrame(fr);

    }

    public static void showMediaFrame(PresenterFrame mf) {

        avoir.realtime.video.transmitter.engine.CaptureUtil util = new avoir.realtime.video.transmitter.engine.CaptureUtil();
        javax.media.Player player = util.transmitLive();

        avoir.realtime.video.transmitter.gui.JMFrame fr = new avoir.realtime.video.transmitter.gui.JMFrame(player, "");
        fr.setVisible(true);
        mf.addFrame(fr);

    }

}
