
import java.util.Random;

public class Coin {

    private double radius;
    private double thickness;
    private int value;
    Random r = new Random();

    public Coin(double aRadius, double aThickness, int aValue) {
        radius = aRadius;
        thickness = aThickness;
        value = aValue;


    }

    public String flip() {
        String result = "";
        int side = Math.abs(r.nextInt() % 2);
        if(side == 0){
            result="Head";
        }else{
            result="Tail";
        }
        return result +","+ radius +"," +thickness +","+ value;

    }
    
   
    
    
    
}
