


/**
 *
 * @author developer
 */
public class TestCoin {

    public static void main(String[] args) {
        Coin c = new Coin(12, 5, 50);
        System.out.println("The side returned is: " + c.flip());


    }
}
