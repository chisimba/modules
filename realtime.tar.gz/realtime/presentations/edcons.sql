-- MySQL dump 10.11
--
-- Host: localhost    Database: edcons
-- ------------------------------------------------------
-- Server version	5.0.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `edcons_users`
--

DROP TABLE IF EXISTS `edcons_users`;
CREATE TABLE `edcons_users` (
  `username` varchar(128) NOT NULL,
  `password` varchar(128) default NULL,
  `surname` varchar(128) default NULL,
  `othernames` varchar(128) default NULL,
  `email` varchar(128) default NULL,
  `reg_date` date default NULL,
  PRIMARY KEY  (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `edcons_users`
--

LOCK TABLES `edcons_users` WRITE;
/*!40000 ALTER TABLE `edcons_users` DISABLE KEYS */;
INSERT INTO `edcons_users` VALUES ('admin','95cc6b4ac5abdeadc74b73a8ba7200d9','Adminstrative','User','admin',NULL);
/*!40000 ALTER TABLE `edcons_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `left_blocks`
--

DROP TABLE IF EXISTS `left_blocks`;
CREATE TABLE `left_blocks` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(128) default NULL,
  `content` varchar(255) default NULL,
  `link` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `left_blocks`
--

LOCK TABLES `left_blocks` WRITE;
/*!40000 ALTER TABLE `left_blocks` DISABLE KEYS */;
/*!40000 ALTER TABLE `left_blocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `right_blocks`
--

DROP TABLE IF EXISTS `right_blocks`;
CREATE TABLE `right_blocks` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(128) default NULL,
  `content` varchar(255) default NULL,
  `link` varchar(255) default NULL,
  `block_order` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `right_blocks`
--

LOCK TABLES `right_blocks` WRITE;
/*!40000 ALTER TABLE `right_blocks` DISABLE KEYS */;
INSERT INTO `right_blocks` VALUES (4,'Training and Internship','','',4),(5,'Products and Services','','',2),(6,'Engineering Services','','',1);
/*!40000 ALTER TABLE `right_blocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `right_content_blocks`
--

DROP TABLE IF EXISTS `right_content_blocks`;
CREATE TABLE `right_content_blocks` (
  `id` int(11) NOT NULL auto_increment,
  `parent_block` int(11) default NULL,
  `title` varchar(128) default NULL,
  `content` text,
  PRIMARY KEY  (`id`),
  KEY `parent_block` (`parent_block`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `right_content_blocks`
--

LOCK TABLES `right_content_blocks` WRITE;
/*!40000 ALTER TABLE `right_content_blocks` DISABLE KEYS */;

/*!40000 ALTER TABLE `right_content_blocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `session`
--

DROP TABLE IF EXISTS `session`;
CREATE TABLE `session` (
  `user` varchar(128) NOT NULL,
  PRIMARY KEY  (`user`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `session`
--

LOCK TABLES `session` WRITE;
/*!40000 ALTER TABLE `session` DISABLE KEYS */;
INSERT INTO `session` VALUES ('admin'),('dwaf');
/*!40000 ALTER TABLE `session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_properties`
--

DROP TABLE IF EXISTS `site_properties`;
CREATE TABLE `site_properties` (
  `site_key` varchar(20) default NULL,
  `site_value` varchar(255) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `site_properties`
--

LOCK TABLES `site_properties` WRITE;
/*!40000 ALTER TABLE `site_properties` DISABLE KEYS */;
INSERT INTO `site_properties` VALUES ('site_name','Edcons K Ltd'),('prelogin_title','EDCONS K LTD is a Civil and Structural Engineering Company');
/*!40000 ALTER TABLE `site_properties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `splash_screen_stories`
--

DROP TABLE IF EXISTS `splash_screen_stories`;
CREATE TABLE `splash_screen_stories` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(128) default NULL,
  `content` text,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `splash_screen_stories`
--

LOCK TABLES `splash_screen_stories` WRITE;
/*!40000 ALTER TABLE `splash_screen_stories` DISABLE KEYS */;
INSERT INTO `splash_screen_stories` VALUES (29,'About','<div style=\"text-align: left;\">EDCONS (K) LTD is a Civil and Structural Engineering company formed and incorporated in Kenya. The company comprises of two directors; Mr. Wasike W. Godwin and Eng. Alex Mureithi Maina and a team of highly dedicated staff.Thecompany fully capitalizes on modern software in its operations. Key on its objectives is economical designs, efficiency and good engineering practice that lead to safe and strong structures that stand the test of time.<br></div><span style=\"font-weight: bold; text-decoration: underline;\"><br></span><span style=\"font-weight: bold;\">Services: </span><br><ul style=\"font-weight: bold;\"><li>Design.</li><li>Project Supervision.</li><li>Feasibility Studies.</li><li>Engineering Evaluation and Assessment.</li><li>Training and Internship.</li><li>Software Agents.</li><li>Draughting, Printing and Plotting Services.</li><li>Knowledge Base.</li></ul>');
/*!40000 ALTER TABLE `splash_screen_stories` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2007-12-28  8:33:41
