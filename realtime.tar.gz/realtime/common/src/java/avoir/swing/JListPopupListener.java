/**
 * $Id: JListPopupListener.java,v 1.1 2007/04/02 15:41:53 adrian Exp $
 *
 * Copyright (C) GNU/GPL AVOIR 2007
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA
 */
package avoir.swing;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.logging.Logger;

import javax.swing.JList;
import javax.swing.JPopupMenu;

/**
 * PopupListener that displays a popup menu when popup trigger is triggered on 
 * a List.
 * 
 * @author mohamed
 */
public class JListPopupListener extends MouseAdapter {

    private static Logger logger = Logger.getLogger(JListPopupListener.class
            .getName());

    private JPopupMenu popup;

    private JList list;

    /**
     * Constructs a new instance of this class which will monitor popup trigger 
     * events on the passed list, and then popup the passed menu.
     * 
     * @param list List to monitor.
     * @param popup Menu to popup.
     */
    public JListPopupListener(JList list, JPopupMenu popup) {
        this.list = list;
        this.popup = popup;
    }

    public void mousePressed(MouseEvent event) {
        maybeShowPopup(event);
    }

    public void mouseReleased(MouseEvent event) {
        maybeShowPopup(event);
    }

    /**
     * Determines whether the event is a popup event and whether something has been 
     * selected in the list, if so then display popup.
     * 
     * @param event Event that occurred.
     */
    private void maybeShowPopup(MouseEvent event) {
        if (event.isPopupTrigger() && list.getSelectedValue() != null) {
            popup.show(event.getComponent(), event.getX(), event.getY());
        }
    }
}
