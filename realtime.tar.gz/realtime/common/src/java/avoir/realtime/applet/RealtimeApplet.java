/**
<<<<<<< RealtimeApplet.java
 *  $Id: RealtimeApplet.java,v 1.2 2007/03/09 13:00:20 adrian Exp $
=======
 *  $Id: RealtimeApplet.java,v 1.3 2007-12-12 10:36:44 davidwaf Exp $
>>>>>>> 1.3
 *
 *  Copyright (C) GNU/GPL AVOIR 2007
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.realtime.applet;

import java.awt.Color;
import java.util.Random;

import javax.swing.JApplet;

import avoir.realtime.User;
import avoir.realtime.UserLevel;
import avoir.util.AppletUtils;

/**
 * Base class containing functionality common to all realtime applets.
 * 
 * @author adrian
 */
public abstract class RealtimeApplet extends JApplet {

    /**
     * Applet parameter for the user level.
     */
    private static final String PARAM_USER_LEVEL = "userLevel";
    /**
     * Applet parameter for the fullnames.
     */
    private static final String PARAM_USER_NAME = "userName";

    /**
     * Applet parameter for the user name.
     */
    private static final String PARAM_FULL_NAME = "fullname";

    /**
     * Parameter for the background color.
     */
    private static final String PARAM_BACKGROUND_COLOR = "backgroundColor";
    /**
     * Applet background colour (white by default).
     */
    protected Color backgroundColor = Color.WHITE;

    /**
     * Gets the currently logged in user from the values set in the applet 
     * parameters. If the user name has not been set then the user name is set 
     * to the value "Guest" appended by a pseudo-random number. If the user 
     * level has not been set then the level is set to GUEST.
     * 
     * @return The currently logged in user (or a default guest user if the 
     * user applet parameters are not set).
     */
    protected User getCurrentUser() {
        String userName = getParameter(PARAM_USER_NAME);
        String fullname=getParameter(PARAM_FULL_NAME);
        if (userName == null) { //not logging on through KEWL for dev, so give random user name
            userName = "Guest" + new Random().nextInt(100);
            fullname=userName;
        }
        String levelString = getParameter(PARAM_USER_LEVEL);
        UserLevel userLevel = UserLevel.GUEST; //assume guest unless set differently in applet param
        if (levelString != null) {
            userLevel = UserLevel.valueOf(levelString.toUpperCase());
        }
        return new User(userLevel,fullname, userName);
    }

    /**
     * Initialises values used by child classes.
     */
    public void init() {
        backgroundColor = AppletUtils.parseHTMLColor(AppletUtils.getParameter(this, RealtimeApplet.PARAM_BACKGROUND_COLOR, "#FFFFFF"));
    }
}
