/**
 *  $Id: HttpRetriever.java,v 1.1 2007/03/08 14:03:10 adrian Exp $
 *
 *  Copyright (C) GNU/GPL AVOIR 2007
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.realtime.http;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Class that retrieves the contents of a URL by doing a simple GET request.
 * 
 * @author adrian
 */
public class HttpRetriever {

    private static Logger logger = Logger.getLogger(HttpRetriever.class
            .getName());

    //TODO: this might not work if the user is behind a proxy server, this article describes changes
    //which might be needed to get this to work: http://thecoadletter.com/article/0,1410,29783,00.html

    /**
     * Retrieves the contents of the passed HTTP URL as a text String.
     *  
     * @param urlToRetrieve An HTTP URL.
     * @return The contents of the URL.
     * @throws IOException If an error occurs retrieving the URL.
     */
    public static String getText(URL urlToRetrieve) throws IOException {
        logger.finest("Retrieving " + urlToRetrieve);
        HttpURLConnection connection = (HttpURLConnection) urlToRetrieve
                .openConnection();
        InputStream inputStream = connection.getInputStream();
        InputStreamReader bufferedInput = new InputStreamReader(inputStream);
        BufferedReader bufferedReader = new BufferedReader(bufferedInput);
        StringBuffer response = new StringBuffer();
        String line = null;
        while ((line = bufferedReader.readLine()) != null) {
            response.append(line);
        }
        connection.disconnect();
        return response.toString();
    }

    /**
     * Downloads a file over HTTP from the passed source URL and saves it the 
     * passed destination file.
     * 
     * @param sourceURL HTTP URL of file to download.
     * @param destination Destination file.
     * @throws IOException If an error occurs downloading or saving the file.
     */
    public static void downloadFile(URL sourceURL, File destination)
            throws IOException {
        logger.finest("Fetching file " + sourceURL);
        InputStream in = null;
        OutputStream out = null;
        try {
            out = new BufferedOutputStream(new FileOutputStream(destination));
            HttpURLConnection connection = (HttpURLConnection) sourceURL.openConnection();
            in = connection.getInputStream();
            byte[] buffer = new byte[1024];
            int numRead;
            while ((numRead = in.read(buffer)) != -1) {
                out.write(buffer, 0, numRead);
            }
            connection.disconnect();
        } finally {
            try {
                if (in != null) {
                    in.close();
                }
                if (out != null) {
                    out.close();
                }
            } catch (IOException e) {
                logger.log(Level.WARNING, "Error closing streams", e);
            }
        }
    }
    
    /**
     * Downloads a file over HTTP from the passed source URL and saves it the 
     * passed destination folder, keeping the original file name.
     * 
     * @param sourceURL HTTP URL of file to download.
     * @param destinationFolder Destination folder.
     * @throws IOException If an error occurs downloading or saving the file.
     */
    public static void downloadFileToFolder(URL sourceURL, File destinationFolder) throws IOException {
        if(!destinationFolder.isDirectory()) {
            throw new IOException(destinationFolder.getAbsolutePath() + " is not a folder");
        }
        //create a file out of url so we can get file name
        File file = new File(sourceURL.toString());
        File fileToDownload = new File(destinationFolder, file.getName());
        downloadFile(sourceURL, fileToDownload);
    }

}
