/**
 *  $Id: AppletUtils.java,v 1.2 2007/03/08 14:03:49 adrian Exp $
 *
 *  Copyright (C) GNU/GPL AVOIR 2007
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.util;

import java.applet.Applet;
import java.awt.Color;

/**
 * Utility functions for Applets.
 * 
 * @author adrian
 */
public class AppletUtils {
    
    /**
     * Gets the value of a required applet parameter.
     *  
     * @param applet The applet holding the parameter.
     * @param parameterName The parameter name.
     * @return The value of the parameter.
     * @throws IllegalStateException If the parameter has not been set.
     */
    public static String getRequiredParameter(Applet applet, String parameterName) {
        String returnValue = applet.getParameter(parameterName);
        if (returnValue == null) {
            throw new IllegalStateException(parameterName
                    + " parameter must be set");
        }
        return returnValue;
    }
    
    /**
     * Gets the value of an applet parameter, if it hasn't been set then return the default value.
     *  
     * @param applet The applet holding the parameter.
     * @param parameterName The parameter name.
     * @param defaultValue The default value if the parameter is not set
     * @return The value of the parameter.
     */
    public static String getParameter(Applet applet, String parameterName, String defaultValue) {
        String returnValue = applet.getParameter(parameterName);
        if (returnValue == null) {
            return defaultValue;
        }
        return returnValue;
    }
    
    /**
     * Converts a string in standard HTML hex color format (e.g., "#ffcc33") to a valid Java 
     * color value.
     * 
     * @param colorString Must be a standard HTML hex color format string (starting with # and
     * followed by 6 characters representing color values.
     * 
     * @return The java Color object, or Color.Black if the color string is invalid.
     */
    public static Color parseHTMLColor(String colorString) {
        int r, g, b;
        // Convert a string in the standard HTML "#RRBBGG" format to a valid
        // color value, if possible.
        if (colorString.length() == 7 && colorString.charAt(0) == '#') {
            r = Integer.parseInt(colorString.substring(1,3),16);
            g = Integer.parseInt(colorString.substring(3,5),16);
            b = Integer.parseInt(colorString.substring(5,7),16);
            return(new Color(r, g, b));
        }
        // Otherwise, default to black.
        return(Color.black);
    }

}
