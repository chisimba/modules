/**
 *  $Id: FileUtils.java,v 1.3 2007/02/15 08:56:37 adrian Exp $
 *
 *  Copyright (C) GNU/GPL AVOIR 2007
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.util;

import java.io.File;
import java.io.FileFilter;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.apache.commons.io.filefilter.FileFileFilter;

/**
 * Useful file utility methods.
 */
public class FileUtils extends org.apache.commons.io.FileUtils {

    /**
     * Returns an ordered list of Files denoting the Files in the passed folder. The 
     * ascending parameter controls the order of this List. If ascending is set to 
     * true then the files will be ordered from oldest to newest. If ascending is is 
     * set to false then the files will be ordered from newest to oldest. If the 
     * passed folder is not a directory, this method will return null. Sub-folders and 
     * files within sub-folders are ignored. 
     * 
     * @param folder The folder to find files in.
     * @param ascending Whether to sort the files by age ascending or descending.
     * @return A list of files ordered by age in the passed folder, or null if the 
     * folder is not actually a folder or an IO error occurs.
     */
    public static List<File> listFilesOrderedByAge(File folder, boolean ascending) {
        if (!folder.isDirectory()) {
            return null;
        }
        //return null;
        FileFilter filter = (FileFilter) FileFileFilter.FILE;
        List<File> files = Arrays.asList(folder.listFiles(filter));
        Collections.sort(files, new FileLastModifiedComparator(ascending));
        return files;
    }
}
