/**
 *  $Id: FileLastModifiedComparator.java,v 1.1 2007/02/14 10:20:30 adrian Exp $
 *
 *  Copyright (C) GNU/GPL AVOIR 2007
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.util;

import java.io.File;
import java.util.Comparator;

/**
 * A Comparator implementation that compares files based on their last modified attribute.
 */
public class FileLastModifiedComparator implements Comparator<File> {

    private boolean ascending;
    
    /**
     * Constructs a new instance of this Comparator. The ascending parameter controls 
     * the comparison so that, if true, an older file is considered "less" than a 
     * younger file (and vice versa).
     * 
     * @param ascending Whether the files should be compared in ascending order.
     */
    public FileLastModifiedComparator(boolean ascending) {
	this.ascending = ascending;
    }
    
    /* (non-Javadoc)
     * @see java.util.Comparator#compare(java.lang.Object, java.lang.Object)
     */
    public int compare(File file1, File file2) {
	if (ascending) {
	    return (int)( file1.lastModified() - file2.lastModified());
	} else {
	    return (int)( file2.lastModified() - file1.lastModified());
	}
    }

}
