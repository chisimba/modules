/**
 *  $Id: FileLastModifiedComparatorTest.java,v 1.4 2007/02/14 11:05:51 adrian Exp $
 *
 *  Copyright (C) GNU/GPL AVOIR 2007
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.logging.Logger;

import org.junit.Test;

/**
 * Test case for the FileLastModifiedComparator class.
 */
public class FileLastModifiedComparatorTest extends BaseFileUtilTest {

    private static Logger logger = Logger
	    .getLogger(FileLastModifiedComparatorTest.class.getName());

    /**
     * Tests that older files are considered "less" than newer files when sorted in 
     * ascending order.
     */
    @Test
    public void testAscending() {
	FileLastModifiedComparator comparator = new FileLastModifiedComparator(
		true);
	int result = comparator.compare(olderFile, oldFile);
	assertTrue("olderFile should be < oldFile", result < 0);
	result = comparator.compare(oldFile, olderFile);
	assertTrue("oldFile should be > olderFile", result > 0);
    }

    /**
     * Tests that older files are considered "greater" than newer files when sorted in 
     * descending order.
     */
    @Test
    public void testDescending() {
	FileLastModifiedComparator comparator = new FileLastModifiedComparator(
		false);
	int result = comparator.compare(oldestFile, oldFile);
	assertTrue("oldestFile should be < oldFile", result > 0);
	result = comparator.compare(oldFile, oldestFile);
	assertTrue("oldFile should be < oldFile", result < 0);
    }

    /**
     * Tests the the same file is considered equal by the comparator.
     */
    @Test
    public void testEqual() {
	FileLastModifiedComparator comparator = new FileLastModifiedComparator(
		true);
	int result = comparator.compare(oldFile, oldFile);
	assertEquals(0, result);
    }
}
