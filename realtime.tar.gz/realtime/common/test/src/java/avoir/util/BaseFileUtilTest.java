/**
 *  $Id: BaseFileUtilTest.java,v 1.3 2007/02/15 08:56:29 adrian Exp $
 *
 *  Copyright (C) GNU/GPL AVOIR 2007
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.util;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import avoir.test.utils.TestUtils;

/**
 * Base class for tests which test file-util related classes.  
 */
public class BaseFileUtilTest {

    /**
     * Folder holding data files used by the tests.
     */
    protected static File dataFolder = null;

    /**
     * A temporary folder which can be used to hold temporary files used by tests.
     */
    protected static File tempFolder = null;

    /**
     * Another temporary folder which should be kept empty for use by some tests.
     */
    protected static File tempFolder2 = null;

    protected static File oldFile;

    protected static File olderFile;

    protected static File oldestFile;

    /**
     * Prepares the test data by backing up the files used in file ordering tests, 
     * and then touching them so last modified dates are in order regardless of 
     * CVS checkout file creation etc.
     * 
     * @throws Exception If an error occurs preparing the test data.
     */
    @BeforeClass
    public static void prepareTestData() throws Exception {
	dataFolder = new File(TestUtils.getCommonTestDataFolder(),
		"avoir/util/FileUtilsTest");
	assertNotNull(dataFolder);
	oldFile = new File(dataFolder, "file_utils_test_old.txt");
	assertTrue(oldFile.exists());
	olderFile = new File(dataFolder, "file_utils_test_older.txt");
	assertTrue(olderFile.exists());
	oldestFile = new File(dataFolder, "file_utils_test_oldest.txt");
	assertTrue(oldestFile.exists());

	tempFolder = new File(dataFolder, "temp");
	tempFolder.mkdirs();

	tempFolder2 = new File(dataFolder, "temp2");
	tempFolder2.mkdir();
	assertTrue(tempFolder2.getAbsolutePath() + " not a folder", tempFolder2
		.isDirectory());

	//copy original files from checkout over to tmp folder so we can move them
	//back when test is finished (so they aren't marked as modified every 
	//time tests run)
	FileUtils.copyFileToDirectory(oldestFile, tempFolder);
	FileUtils.copyFileToDirectory(olderFile, tempFolder);
	FileUtils.copyFileToDirectory(oldFile, tempFolder);

	//now touch the files in the data folder so they are aged as expected
	//(this is necessary as cvs co changes last modified dates)
	FileUtils.touch(oldestFile);
	Thread.sleep(1000);
	FileUtils.touch(olderFile);
	Thread.sleep(1000);
	FileUtils.touch(oldFile);
    }

    /**
     * Undoes the changes performed in prepareTestData()
     * 
     * @throws IOException If an error occurs cleaning up the test data.
     */
    @AfterClass
    public static void cleanupTestData() throws IOException {
	//copy files back to data folder so CVS doesn't realise they were changed
	FileUtils.copyFileToDirectory(new File(tempFolder, oldestFile.getName()), dataFolder);
	FileUtils.copyFileToDirectory(new File(tempFolder, olderFile.getName()), dataFolder);
	FileUtils.copyFileToDirectory(new File(tempFolder, oldFile.getName()), dataFolder);
	FileUtils.deleteDirectory(tempFolder);
	FileUtils.deleteDirectory(tempFolder2);
    }

    /**
     * Put here to keep ant build happy as it tries to run this class due to 
     * file name matching test pattern.
     */
    @Ignore("Useless test method, just here to keep ant test happy")
    @Test
    public void testNothing() {
    }

}
