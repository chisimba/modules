/**
 *  $Id: FileUtilsTest.java,v 1.4 2007/02/15 08:56:37 adrian Exp $
 *
 *  Copyright (C) GNU/GPL AVOIR 2007
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.util.List;
import java.util.logging.Logger;

import org.junit.Test;

/**
 * Test case for the FileUtils class.
 */
public class FileUtilsTest extends BaseFileUtilTest {

    private static Logger logger = Logger.getLogger(FileUtilsTest.class
	    .getName());

    /**
     * Tests that trying to list the files within a file (i.e. not a folder) 
     * returns null.
     */
    @Test
    public void testListFilesOrderedByAge_NotAFolder() {
	File file = new File(dataFolder, "file_utils_test_old.txt");
	assertTrue(file.exists());
	assertNull(FileUtils.listFilesOrderedByAge(file, true));
    }

    /**
     * Tests that files are returned from oldest to newest when sorted in 
     * ascending order.
     */
    @Test
    public void testListFilesOrderedByAge_Ascending() {
	List files = FileUtils.listFilesOrderedByAge(dataFolder, true);
	assertEquals(3, files.size());
	assertEquals(oldestFile, files.get(0));
	assertEquals(olderFile, files.get(1));
	assertEquals(oldFile, files.get(2));
    }

    /**
     * Tests that files are returned from newest to oldest when sorted in 
     * descending order.
     */
    @Test
    public void testListFilesOrderedByAge_Descending() {
	List files = FileUtils.listFilesOrderedByAge(dataFolder, false);
	assertEquals(3, files.size());
	assertEquals(oldFile, files.get(0));
	assertEquals(olderFile, files.get(1));
	assertEquals(oldestFile, files.get(2));
    }
    
    /**
     * Tests that listing files in an empty folder returns no files.
     */
    @Test
    public void testListFilesOrderedByAge_EmptyFolder() {
	List files = FileUtils.listFilesOrderedByAge(tempFolder2, true);
	assertEquals(0, files.size());
    }

}
