/**
 *  $Id: AppletUtilsTest.java,v 1.1 2007/03/08 14:03:59 adrian Exp $
 *
 *  Copyright (C) GNU/GPL AVOIR 2007
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.util;

import static org.junit.Assert.assertEquals;

import java.awt.Color;

import org.junit.Test;

/**
 * Test case for the AppletUtils class.
 * 
 * @author adrian
 */
public class AppletUtilsTest {
    
    /**
     * Test parsing an HTML color string to a Java Color.
     */
    @Test
    public void testParseHTMLColor() {
        Color color = AppletUtils.parseHTMLColor("#01099e");
        assertEquals(new Color(1, 9, 158), color);
        //same color, just different case for hex code
        color = AppletUtils.parseHTMLColor("#01099E");
        assertEquals(new Color(1, 9, 158), color);
    }

    /**
     * Tests parsing the HTML color string for white to a Java Color.
     */
    @Test
    public void testParseHTMLColor_White() {
        Color color = AppletUtils.parseHTMLColor("#FFFFFF");
        assertEquals(Color.WHITE, color);
    }
    
    /**
     * Tests parsing the HTML color string for red to a Java Color.
     */
    @Test
    public void testParseHTMLColor_Red() {
        Color color = AppletUtils.parseHTMLColor("#FF0000");
        assertEquals(Color.RED, color);
    }

    /**
     * Test parsing a string that is 8 characters long, default color 
     * should be returned.
     */
    @Test
    public void testParseHTMLColor_StringTooLong() {
        Color color = AppletUtils.parseHTMLColor("#FF00000");
        assertEquals(Color.BLACK, color);
    }

    /**
     * Test parsing a string that is 6 characters long, default color
     * should be returned.
     */
    @Test
    public void testParseHTMLColor_StringTooShort() {
        Color color = AppletUtils.parseHTMLColor("#FF000");
        assertEquals(Color.BLACK, color);
    }

    /**
     * Tests parsing a string that doesn't start with {@link #clone()}, default 
     * color should be returned.
     */
    @Test
    public void testParseHTMLColor_InvalidStartCharacter() {
        Color color = AppletUtils.parseHTMLColor("!FF0000");
        assertEquals(Color.BLACK, color);
    }

    /**
     * Tests that parsing an invalid hex string throws a NumberFormatException
     */
    @Test(expected=NumberFormatException.class)
    public void testParseHTMLColor_InvalidHex() {
        AppletUtils.parseHTMLColor("#FF00ZZ");
    }
    
}
