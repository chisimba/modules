/**
 *  $Id: TestProperties.java,v 1.2 2007/02/26 14:52:52 adrian Exp $
 *
 *  Copyright (C) GNU/GPL AVOIR 2007
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.test.utils;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Holds the properties set in test.properties (which must be located somewhere 
 * on the class path). 
 */
public class TestProperties extends Properties {

    private static final long serialVersionUID = -6832537001694742999L;

    /**
     * Name of the file on the classpath holding the properties.
     */
    private static String PROPERTY_FILE_NAME = "test.properties";

    /**
     * Singleton instance of this class.
     */
    private static TestProperties instance = new TestProperties();

    /**
     * Creates an instance of this class. 
     *
     * @throws RuntimeException If a file called test.properties cannot be found  
     * on the classpath.
     */
    private TestProperties() {
	try {
	    InputStream input = ClassLoader
		    .getSystemResourceAsStream(PROPERTY_FILE_NAME);
	    if (input == null) {
		throw new RuntimeException(
			"Could not find a file named test.properties on the classpath");
	    }
	    this.load(input);
	} catch (IOException e) {
	    throw new RuntimeException(e);
	}
    }

    /**
     * Gets the singleton instance of this class. If an error occurred during 
     * initialisation this instance will be null.
     * 
     * @return The one and only instance of this class.
     */
    public static TestProperties getInstance() {
	return instance;
    }

    /**
     * Searches for the property with the specified key in this property list. 
     * If the key is not found in this property list, the default property list,
     * and its defaults, recursively, are then checked. If the property cannot 
     * be found a RuntimeException is thrown.
     * 
     * @param key The property key.
     * @return The value in this property list with the specified key value.
     * @throws RuntimeException If the property cannot be found;
     */
    public String getRequiredProperty(String key) {
        String value = getProperty(key);
        if (value==null) {
            throw new RuntimeException("Missing property '"
                    + key + "' in " + PROPERTY_FILE_NAME);
        }
        return value;
    }
    
    /**
     * Searches for the property with the specified key in this property list. 
     * If the key is not found in this property list, the default property list,
     * and its defaults, recursively, are then checked. The method returns null 
     * if the property is not found.
     * 
     * @param key The property key.
     * @return The value in this property list with the specified key value, or 
     * null if it cannot be found.
     */
    public Boolean getBooleanProperty(String key) {
	String returnValue = getProperty(key);
	if (returnValue != null) {
	    return new Boolean(returnValue);
	}
	return null;
    }
}
