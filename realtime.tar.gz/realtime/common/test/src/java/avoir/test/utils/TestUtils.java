/**
 *  $Id: TestUtils.java,v 1.1 2007/02/14 10:20:30 adrian Exp $
 *
 *  Copyright (C) GNU/GPL AVOIR 2007
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package avoir.test.utils;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.logging.Logger;

/**
 * Provides various utility functions that can be used across tests.
 *
 */
public class TestUtils {
    
    private static Logger logger = Logger.getLogger(TestUtils.class.getName());
    
    /**
     * Folder for holding test data, should be relative to sub-project folder.
     */
    private static final String DATA_FOLDER = "test/data";

    /**
     * Retrieves the test data folder. This is needed as a utility method as 
     * the location of this folder differs depending on the path used to run 
     * the tests (typically this is different when run from inside an IDE to 
     * when run from the command line using Ant etc.)
     * 
     * @param subPath The name of the sub-project folder.
     * @return The data folder if it could be located.
     * @throws FileNotFoundException If the data folder cannot be found.
     */
    private static File getDataFolder(String subPath) throws FileNotFoundException {
	//1st look for folder relative to where we are run from
	File file = new File(subPath + "/" + DATA_FOLDER);
	StringBuffer searchedPaths = new StringBuffer();
	if (file.exists()) {
	    return file;
	} else {
	    searchedPaths.append(file.getAbsolutePath());
	    //2nd try look from one folder up
	    file = new File("../" + subPath + "/" + DATA_FOLDER);
	    if (file.exists()) {
		return file;
	    } else {
		searchedPaths.append("," + file.getAbsolutePath());
		throw new FileNotFoundException("Could not find data folder, " +
				"looked in: " + searchedPaths);
	    }
	}
    }
    
    /**
     * Retrieves the test data folder under the voice sub-project.
     * 
     * return The test data folder for the voice sub-project.
     * @throws FileNotFoundException If the test data folder cannot be found.
     */
    public static File getVoiceTestDataFolder() throws FileNotFoundException {
	return getDataFolder("voice");
    }
    
    /**
     * Retrieves the test data folder under the common sub-project.
     * 
     * return The test data folder for the common sub-project.
     * @throws FileNotFoundException If the test data folder cannot be found.
     */
    public static File getCommonTestDataFolder() throws FileNotFoundException {
	return getDataFolder("common");
    }
    
}
