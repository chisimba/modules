/**
* $Id: UserTest.java,v 1.3 2007/04/05 12:10:36 mohamed Exp $
*
* Copyright (C) GNU/GPL AVOIR 2007
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA
*/
package avoir.realtime;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

/**
 * @author mohamed
 */
public class UserTest {
 // test equals
    @Test
    // 2 users, the same, are they equal\
    public void testEquals(){
        User user1 = new User(UserLevel.LECTURER, "student", "2001", false);
        User user2 = new User(UserLevel.LECTURER, "student", "2001", false);
        assertTrue(user1.equals(user2));
    }
     
    @Test
    // 2 users, the same except first name, shouldnt be equal
    public void testEquals_differentFirstName(){
        User user1 = new User(UserLevel.LECTURER, "lecturer", "2001", false);
        User user2 = new User(UserLevel.LECTURER, "student", "2001", false);
        assertFalse(user1.equals(user2));        
    }
    
    @Test
    //as above but with different level
    public void testEquals_differentLevel(){
        User user1 = new User(UserLevel.LECTURER, "student", "2001", false);
        User user2 = new User(UserLevel.STUDENT, "student", "2001", false);
        assertFalse(user1.equals(user2));        
    }
    
    @Test
    //as above but with different id
    public void testEquals_differentId(){
        User user1 = new User(UserLevel.LECTURER, "student", "01", false);
        User user2 = new User(UserLevel.LECTURER, "student", "2001", false);
        assertFalse(user1.equals(user2));        
    }
    @Test
    //as above with with different token -> should be equal
    public void testEquals_differentToken(){
        User user1 = new User(UserLevel.LECTURER, "student", "2001", false);
        User user2 = new User(UserLevel.LECTURER, "student", "2001", true);
        assertTrue(user1.equals(user2));        
    }
    @Test
    //compare with null - > not equal
    public void testEquals_null(){
        User user1 = new User(UserLevel.LECTURER, "student", "2001", false);
        assertFalse(user1.equals(null));
    }
    @Test
    //compare with String -> not equals
    public void testEquals_String(){
        User user1 = new User(UserLevel.LECTURER, "student", "2001", false);
        String user2 = "string";
        assertFalse(user1.equals(user2));
    }
}
