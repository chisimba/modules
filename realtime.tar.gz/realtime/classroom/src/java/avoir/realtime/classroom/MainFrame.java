/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package avoir.realtime.classroom;

import javax.swing.*;
import javax.swing.event.*;

import java.awt.*;
import java.awt.event.*;

//import avoir.realtime.presentations.client.presenter.PresenterFrame;
/**
 *
 * @author dwafula
 */

public class MainFrame extends JApplet implements ActionListener {

    JDesktopPane desktop = new JDesktopPane();
    //  PresenterFrame presenterFrame=new PresenterFrame();

    public void init() {
        setLayout(new BorderLayout());
        add(desktop, BorderLayout.CENTER);

        //check for availability of presentations lib
        boolean presentationsAvailable = false;
        try {
            Class.forName("avoir.realtime.presentations.client.presenter.PresenterFrame");
            presentationsAvailable = true;
        } catch (Exception ex) {//Throwable throwable2) {
            ex.printStackTrace();
        }
        if (presentationsAvailable) {
            avoir.realtime.presentations.client.presenter.PresenterFrame presenterFrame = new avoir.realtime.presentations.client.presenter.PresenterFrame();
           
            addFrame(presenterFrame.createAudienceFrame());
           
            addFrame(presenterFrame.createSurfaceFrame());
        }
        //detect any video stuff
                                boolean jmfAvailable = false;
                        boolean realtimeVideoAvailable = false;
                        // Check for basic JMF classes.
                        try {
                            System.out.println("jmf testing...");
                            Class.forName("javax.media.Player");
                            jmfAvailable = true;
                        } catch (Exception ex) {//Throwable throwable2) {
                            ex.printStackTrace();
                            //setStatusText("JMF not found", Color.BLACK);
                        }

                        //check for realtime vid
                        try {
                            System.out.println("vid testing...");
                            Class.forName("avoir.realtime.video.transmitter.engine.CaptureUtil");
                            realtimeVideoAvailable = true;
                        } catch (Exception ex) {//Throwable throwable2) {
                            ex.printStackTrace();
                        }

                        if (realtimeVideoAvailable && jmfAvailable) {
                            JMFDisplay.showMediaFrame(this);
                        } else {
                            int n = JOptionPane.showConfirmDialog(null, "Could not detect realtime audio/video libraries.\n" + "" +
                                    "Do you want to install now? ", "JMF Libraries", JOptionPane.YES_NO_OPTION);
                            if (n == JOptionPane.YES_OPTION) {
                                //installJMF();
                            }
                        }
    }

    public void addFrame(JInternalFrame fr) {
        try {
            fr.setSelected(true);
            desktop.add(fr);

        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }

    public void actionPerformed(ActionEvent e) {

    }
}
