/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package avoir.realtime.classroom;
/**
 *
 * @author dwafula
 */

public class JMFDisplay {

 
    public static void showMediaFrame(MainFrame mf) {

        avoir.realtime.video.transmitter.engine.CaptureUtil util = new avoir.realtime.video.transmitter.engine.CaptureUtil();
        javax.media.Player player = util.transmitLive();

        avoir.realtime.video.transmitter.gui.JMFrame fr = new avoir.realtime.video.transmitter.gui.JMFrame(player, "");
        fr.setVisible(true);
        mf.addFrame(fr);

    }

}
