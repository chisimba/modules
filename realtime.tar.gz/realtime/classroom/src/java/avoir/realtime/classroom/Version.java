
            package avoir.realtime.classroom;

            public class Version{

            public static String version="20080123";

            }
        