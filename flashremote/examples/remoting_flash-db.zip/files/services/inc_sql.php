<?php
########################
# SQL parameters
########################
// Here You must define a user, password and host to match your needs. 
// Debug flag outputs full error messages when installing
define ("USERNAME","root");
define ("PASSWORD","");
define ("HOSTNAME","localhost");
define ("DATABASE","Catalog");
?>